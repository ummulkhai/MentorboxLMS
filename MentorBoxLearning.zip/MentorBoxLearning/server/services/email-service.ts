import nodemailer from 'nodemailer';
import { User } from '@shared/schema';
import { log } from '../vite';

// Interface for contact form data
export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

// Create a transporter for sending emails
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'filelndummul@gmail.com', // Your Gmail address
    pass: process.env.EMAIL_PASSWORD // This should be an app password, not your regular password
  }
});

// Format date for email
const formatDate = (date: Date): string => {
  return new Date(date).toLocaleString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Welcome email template
export const sendWelcomeEmail = async (user: User): Promise<boolean> => {
  try {
    const mailOptions = {
      from: 'filelndummul@gmail.com',
      to: user.email,
      subject: '🎉 Welcome to MentorBox LMS!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4a6cf7; text-align: center;">Welcome to MentorBox LMS! 🎓</h2>
          <div style="padding: 20px 0; border-top: 1px solid #e0e0e0; border-bottom: 1px solid #e0e0e0;">
            <p>Hello <strong>${user.name}</strong>,</p>
            <p>Thank you for joining MentorBox LMS! We're excited to have you on board. Your learning journey starts now!</p>
            <p>Here's how to get started:</p>
            <ol>
              <li>Log in to your account using your username: <strong>${user.username}</strong></li>
              <li>Browse through the available courses and enroll in the ones that interest you</li>
              <li>Access your enrolled courses from your dashboard</li>
              <li>Track your progress and complete course activities</li>
            </ol>
            <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
          </div>
          <div style="margin-top: 20px; text-align: center;">
            <a href="${process.env.APP_URL || 'https://localhost:5000'}" style="background-color: #4a6cf7; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Go to Your Dashboard</a>
          </div>
          <p style="margin-top: 20px; font-size: 14px; color: #666; text-align: center;">Account created on: ${formatDate(user.createdAt)}</p>
          <p style="font-size: 12px; color: #999; text-align: center; margin-top: 20px;">© ${new Date().getFullYear()} MentorBox LMS. All rights reserved.</p>
        </div>
      `
    };

    await transporter.sendMail(mailOptions);
    log(`Welcome email sent to ${user.email}`, 'email');
    return true;
  } catch (error) {
    console.error('Error sending welcome email:', error);
    log(`Failed to send welcome email to ${user.email}: ${error}`, 'email');
    return false;
  }
};

// Send contact form data to admin
export const sendContactFormEmail = async (data: ContactFormData): Promise<boolean> => {
  try {
    const mailOptions = {
      from: 'filelndummul@gmail.com',
      to: 'filelndummul@gmail.com', // Admin email
      replyTo: data.email, // Reply-To set to the sender's email
      subject: `📬 Contact Form: ${data.subject}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4a6cf7; text-align: center;">New Contact Form Submission 📝</h2>
          <div style="padding: 20px 0; border-top: 1px solid #e0e0e0; border-bottom: 1px solid #e0e0e0;">
            <h3>Contact Details:</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Name:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${data.name}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Email:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><a href="mailto:${data.email}">${data.email}</a></td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Subject:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${data.subject}</td>
              </tr>
            </table>
            
            <h3>Message:</h3>
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px;">
              <p style="white-space: pre-line;">${data.message}</p>
            </div>
          </div>
          <p style="margin-top: 20px; font-size: 14px; color: #666; text-align: center;">
            Submitted on: ${formatDate(new Date())}
          </p>
          <p style="font-size: 12px; color: #999; text-align: center; margin-top: 20px;">
            © ${new Date().getFullYear()} MentorBox LMS. All rights reserved.
          </p>
        </div>
      `
    };

    // Also send an auto-reply to the person who submitted the form
    const autoReplyOptions = {
      from: 'filelndummul@gmail.com',
      to: data.email,
      subject: 'Thank you for contacting MentorBox LMS',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4a6cf7; text-align: center;">Thank You for Contacting Us! 📬</h2>
          <div style="padding: 20px 0; border-top: 1px solid #e0e0e0; border-bottom: 1px solid #e0e0e0;">
            <p>Hello <strong>${data.name}</strong>,</p>
            <p>Thank you for reaching out to MentorBox LMS! We have received your message and appreciate your interest in our platform.</p>
            <p>Our team will review your inquiry and get back to you as soon as possible. Please allow us 1-2 business days to respond.</p>
            <p>For your reference, here's a copy of your message:</p>
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
              <p><strong>Subject:</strong> ${data.subject}</p>
              <p style="white-space: pre-line;"><strong>Message:</strong><br>${data.message}</p>
            </div>
            <p>If you have any urgent matters, please don't hesitate to call our support team.</p>
          </div>
          <p style="font-size: 12px; color: #999; text-align: center; margin-top: 20px;">© ${new Date().getFullYear()} MentorBox LMS. All rights reserved.</p>
        </div>
      `
    };

    // Send both emails
    await transporter.sendMail(mailOptions);
    await transporter.sendMail(autoReplyOptions);
    
    log(`Contact form submission from ${data.email} processed successfully`, 'email');
    return true;
  } catch (error) {
    console.error('Error processing contact form:', error);
    log(`Failed to process contact form from ${data.email}: ${error}`, 'email');
    return false;
  }
};

// Admin notification email about new user registration
export const sendAdminNotification = async (user: User): Promise<boolean> => {
  try {
    const mailOptions = {
      from: 'filelndummul@gmail.com',
      to: 'filelndummul@gmail.com', // Admin email
      subject: '🆕 New User Registration on MentorBox',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4a6cf7; text-align: center;">New User Registration 📝</h2>
          <div style="padding: 20px 0; border-top: 1px solid #e0e0e0; border-bottom: 1px solid #e0e0e0;">
            <p>A new user has registered on MentorBox LMS.</p>
            <h3>User Details:</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Name:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${user.name}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Email:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${user.email}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Username:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${user.username}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Role:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${user.role}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;"><strong>Registration Date:</strong></td>
                <td style="padding: 8px; border-bottom: 1px solid #e0e0e0;">${formatDate(user.createdAt)}</td>
              </tr>
              <tr>
                <td style="padding: 8px;"><strong>User ID:</strong></td>
                <td style="padding: 8px;">${user.id}</td>
              </tr>
            </table>
          </div>
          <div style="margin-top: 20px; text-align: center;">
            <a href="${process.env.APP_URL || 'https://localhost:5000'}/admin/users" style="background-color: #4a6cf7; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">View User in Admin Panel</a>
          </div>
          <p style="font-size: 12px; color: #999; text-align: center; margin-top: 20px;">© ${new Date().getFullYear()} MentorBox LMS. All rights reserved.</p>
        </div>
      `
    };

    await transporter.sendMail(mailOptions);
    log(`Admin notification email sent about new user: ${user.email}`, 'email');
    return true;
  } catch (error) {
    console.error('Error sending admin notification:', error);
    log(`Failed to send admin notification about user ${user.email}: ${error}`, 'email');
    return false;
  }
};