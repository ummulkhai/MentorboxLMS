import { 
  User, InsertUser, Course, InsertCourse, 
  CourseMaterial, InsertCourseMaterial, 
  CourseModule, InsertCourseModule,
  UserCourse, InsertUserCourse,
  SelfLearningMaterial, InsertSelfLearningMaterial,
  Fact, InsertFact,
  UserBookmark, InsertUserBookmark,
  Quiz, InsertQuiz,
  QuizQuestion, InsertQuizQuestion,
  QuizAttempt, InsertQuizAttempt,
  QuizAnswer, InsertQuizAnswer
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(id: number, role: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Course module operations
  getCourseModules(courseId: number): Promise<CourseModule[]>;
  createCourseModule(module: InsertCourseModule): Promise<CourseModule>;
  
  // Course material operations
  getCourseMaterials(courseId: number): Promise<CourseMaterial[]>;
  createCourseMaterial(material: InsertCourseMaterial): Promise<CourseMaterial>;
  
  // User course operations
  getUserCourses(userId: number): Promise<Course[]>;
  getUserEnrolledCourses(userId: number): Promise<Course[]>;
  recordCourseAccess(userId: number, courseId: number): Promise<void>;
  getCourseProgress(userId: number, courseId: number): Promise<number>;
  updateCourseProgress(userId: number, courseId: number, progress: number): Promise<void>;
  getUpcomingClasses(userId: number): Promise<any[]>;
  
  // Enrollment management
  getAllEnrollments(): Promise<any[]>;
  createEnrollment(userId: number, courseId: number): Promise<UserCourse>;
  removeEnrollment(enrollmentId: number): Promise<void>;
  
  // Self-learning materials operations
  getSelfLearningMaterials(): Promise<SelfLearningMaterial[]>;
  createSelfLearningMaterial(material: InsertSelfLearningMaterial): Promise<SelfLearningMaterial>;
  
  // Facts operations
  getFacts(): Promise<Fact[]>;
  createFact(fact: InsertFact): Promise<Fact>;
  
  // Bookmark operations
  getUserBookmarks(userId: number): Promise<any[]>;
  addBookmark(userId: number, materialId: number): Promise<UserBookmark>;
  removeBookmark(bookmarkId: number): Promise<void>;
  
  // Quiz operations
  getQuizzes(courseId?: number): Promise<Quiz[]>;
  getQuiz(id: number): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: number, quiz: Partial<InsertQuiz>): Promise<Quiz | undefined>;
  
  // Quiz questions operations
  getQuizQuestions(quizId: number): Promise<QuizQuestion[]>;
  getQuizQuestion(id: number): Promise<QuizQuestion | undefined>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  updateQuizQuestion(id: number, question: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined>;
  
  // Quiz attempts operations
  getQuizAttempts(quizId: number, userId?: number): Promise<QuizAttempt[]>;
  getQuizAttempt(id: number): Promise<QuizAttempt | undefined>;
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  completeQuizAttempt(id: number, score: number, passed: boolean): Promise<QuizAttempt | undefined>;
  
  // Quiz answers operations
  getQuizAnswers(attemptId: number): Promise<QuizAnswer[]>;
  createQuizAnswer(answer: InsertQuizAnswer): Promise<QuizAnswer>;
  gradeQuizAnswer(id: number, isCorrect: boolean, pointsEarned: number, feedback?: string): Promise<QuizAnswer | undefined>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private courseModules: Map<number, CourseModule>;
  private courseMaterials: Map<number, CourseMaterial>;
  private userCourses: Map<number, UserCourse>;
  private selfLearningMaterials: Map<number, SelfLearningMaterial>;
  private facts: Map<number, Fact>;
  private userBookmarks: Map<number, UserBookmark>;
  
  // Quiz related maps
  private quizzes: Map<number, Quiz>;
  private quizQuestions: Map<number, QuizQuestion>;
  private quizAttempts: Map<number, QuizAttempt>;
  private quizAnswers: Map<number, QuizAnswer>;
  
  sessionStore: session.Store;
  
  private userId: number = 1;
  private courseId: number = 1;
  private moduleId: number = 1;
  private materialId: number = 1;
  private userCourseId: number = 1;
  private selfLearningId: number = 1;
  private factId: number = 1;
  private bookmarkId: number = 1;
  private quizId: number = 1;
  private quizQuestionId: number = 1;
  private quizAttemptId: number = 1;
  private quizAnswerId: number = 1;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.courseModules = new Map();
    this.courseMaterials = new Map();
    this.userCourses = new Map();
    this.selfLearningMaterials = new Map();
    this.facts = new Map();
    this.userBookmarks = new Map();
    
    // Initialize quiz maps
    this.quizzes = new Map();
    this.quizQuestions = new Map();
    this.quizAttempts = new Map();
    this.quizAnswers = new Map();
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    }) as session.Store;
    
    // Initialize some sample data
    this.initSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const timestamp = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: timestamp,
      role: insertUser.role || "student" // Ensure role is never undefined
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserRole(id: number, role: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, role };
    this.users.set(id, updatedUser);
    console.log(`Updated user ${id} role to ${role} in memory storage`);
    
    return updatedUser;
  }
  
  // Course operations
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.courseId++;
    const course: Course = { 
      ...insertCourse, 
      id,
      // Ensure required fields are present
      type: insertCourse.type || "online",
      timezone: insertCourse.timezone || "EST",
      isEditable: insertCourse.isEditable === undefined ? true : insertCourse.isEditable
    };
    this.courses.set(id, course);
    return course;
  }
  
  // Course module operations
  async getCourseModules(courseId: number): Promise<CourseModule[]> {
    return Array.from(this.courseModules.values())
      .filter(module => module.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }
  
  async createCourseModule(insertModule: InsertCourseModule): Promise<CourseModule> {
    const id = this.moduleId++;
    const module: CourseModule = { ...insertModule, id };
    this.courseModules.set(id, module);
    return module;
  }
  
  // Course material operations
  async getCourseMaterials(courseId: number): Promise<CourseMaterial[]> {
    return Array.from(this.courseMaterials.values())
      .filter(material => material.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }
  
  async createCourseMaterial(insertMaterial: InsertCourseMaterial): Promise<CourseMaterial> {
    const id = this.materialId++;
    // Ensure moduleId is handled correctly (null instead of undefined)
    const material: CourseMaterial = { 
      ...insertMaterial, 
      id,
      moduleId: insertMaterial.moduleId === undefined ? null : insertMaterial.moduleId,
      createdAt: new Date(),
      description: insertMaterial.description || null,
      category: insertMaterial.category || "other"
    };
    this.courseMaterials.set(id, material);
    return material;
  }
  
  // User course operations
  async getUserCourses(userId: number): Promise<Course[]> {
    const userCourseIds = Array.from(this.userCourses.values())
      .filter(uc => uc.userId === userId)
      .map(uc => uc.courseId);
    
    return Array.from(this.courses.values())
      .filter(course => userCourseIds.includes(course.id));
  }
  
  async recordCourseAccess(userId: number, courseId: number): Promise<void> {
    const existingEntry = Array.from(this.userCourses.values())
      .find(uc => uc.userId === userId && uc.courseId === courseId);
    
    if (existingEntry) {
      // Update last accessed timestamp
      const updatedEntry: UserCourse = {
        ...existingEntry,
        lastAccessed: new Date()
      };
      this.userCourses.set(existingEntry.id, updatedEntry);
    } else {
      // Create new entry
      const id = this.userCourseId++;
      const newEntry: UserCourse = {
        id,
        userId,
        courseId,
        progress: 0,
        lastAccessed: new Date(),
        enrolled: true,
        enrollmentDate: new Date()
      };
      this.userCourses.set(id, newEntry);
    }
  }
  
  async getCourseProgress(userId: number, courseId: number): Promise<number> {
    const entry = Array.from(this.userCourses.values())
      .find(uc => uc.userId === userId && uc.courseId === courseId);
    
    return entry ? entry.progress : 0;
  }
  
  async updateCourseProgress(userId: number, courseId: number, progress: number): Promise<void> {
    const entry = Array.from(this.userCourses.values())
      .find(uc => uc.userId === userId && uc.courseId === courseId);
    
    if (entry) {
      const updatedEntry: UserCourse = {
        ...entry,
        progress,
        lastAccessed: new Date()
      };
      this.userCourses.set(entry.id, updatedEntry);
    } else {
      // Create new entry
      const id = this.userCourseId++;
      const newEntry: UserCourse = {
        id,
        userId,
        courseId,
        progress,
        lastAccessed: new Date(),
        enrolled: true,
        enrollmentDate: new Date()
      };
      this.userCourses.set(id, newEntry);
    }
  }
  
  async getUpcomingClasses(userId: number): Promise<any[]> {
    const userCourses = await this.getUserCourses(userId);
    const now = new Date();
    
    // Get upcoming classes from user courses
    const upcomingClasses = userCourses
      .filter(course => new Date(course.endDate) >= now)
      .map(course => {
        // Generate upcoming class sessions based on the course
        const courseModules = Array.from(this.courseModules.values())
          .filter(module => module.courseId === course.id);
        
        return courseModules.map((module, index) => {
          // Calculate class date (just for demo - in real app would use actual scheduled dates)
          const startDate = new Date(course.startDate);
          const classDate = new Date(startDate);
          classDate.setDate(startDate.getDate() + index);
          
          return {
            id: module.id,
            title: `${course.title}: ${module.title}`,
            date: classDate,
            timeStart: course.timeStart,
            timeEnd: course.timeEnd,
            timezone: course.timezone,
            type: course.type,
            icon: index % 3 === 0 ? 'chalkboard-teacher' : index % 3 === 1 ? 'video' : 'users'
          };
        });
      })
      .flat()
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .slice(0, 5); // Get only the next 5 upcoming classes
    
    return upcomingClasses;
  }
  
  // Self-learning materials operations
  async getSelfLearningMaterials(): Promise<SelfLearningMaterial[]> {
    return Array.from(this.selfLearningMaterials.values());
  }
  
  async createSelfLearningMaterial(insertMaterial: InsertSelfLearningMaterial): Promise<SelfLearningMaterial> {
    const id = this.selfLearningId++;
    const material: SelfLearningMaterial = { ...insertMaterial, id };
    this.selfLearningMaterials.set(id, material);
    return material;
  }
  
  // Facts operations
  async getFacts(): Promise<Fact[]> {
    return Array.from(this.facts.values());
  }
  
  async createFact(insertFact: InsertFact): Promise<Fact> {
    const id = this.factId++;
    const fact: Fact = { 
      ...insertFact, 
      id,
      category: insertFact.category === undefined ? null : insertFact.category
    };
    this.facts.set(id, fact);
    return fact;
  }
  
  // User operations extensions
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Enrollment operations
  async getAllEnrollments(): Promise<any[]> {
    const enrollments = Array.from(this.userCourses.values())
      .filter(uc => uc.enrolled === true);
    
    const result = [];
    
    for (const enrollment of enrollments) {
      const user = await this.getUser(enrollment.userId);
      const course = await this.getCourse(enrollment.courseId);
      
      if (user && course) {
        result.push({
          id: enrollment.id,
          user,
          course,
          progress: enrollment.progress,
          lastAccessed: enrollment.lastAccessed,
          enrollmentDate: enrollment.enrollmentDate
        });
      }
    }
    
    return result;
  }
  
  async createEnrollment(userId: number, courseId: number): Promise<UserCourse> {
    // Check if enrollment already exists
    const existingEntry = Array.from(this.userCourses.values())
      .find(uc => uc.userId === userId && uc.courseId === courseId);
    
    if (existingEntry) {
      // Update if exists but marked as not enrolled
      if (!existingEntry.enrolled) {
        const updatedEntry: UserCourse = {
          ...existingEntry,
          enrolled: true,
          enrollmentDate: new Date()
        };
        this.userCourses.set(existingEntry.id, updatedEntry);
        return updatedEntry;
      }
      return existingEntry;
    }
    
    // Create new enrollment
    const id = this.userCourseId++;
    const enrollment: UserCourse = {
      id,
      userId,
      courseId,
      progress: 0,
      lastAccessed: null,
      enrolled: true,
      enrollmentDate: new Date()
    };
    
    this.userCourses.set(id, enrollment);
    return enrollment;
  }
  
  async removeEnrollment(enrollmentId: number): Promise<void> {
    const enrollment = this.userCourses.get(enrollmentId);
    
    if (enrollment) {
      const updatedEnrollment: UserCourse = {
        ...enrollment,
        enrolled: false
      };
      this.userCourses.set(enrollmentId, updatedEnrollment);
    }
  }
  
  async getUserEnrolledCourses(userId: number): Promise<Course[]> {
    const userCourseIds = Array.from(this.userCourses.values())
      .filter(uc => uc.userId === userId && uc.enrolled === true)
      .map(uc => uc.courseId);
    
    return Array.from(this.courses.values())
      .filter(course => userCourseIds.includes(course.id));
  }
  
  // Bookmark operations
  async getUserBookmarks(userId: number): Promise<any[]> {
    const bookmarks = Array.from(this.userBookmarks.values())
      .filter(bookmark => bookmark.userId === userId);
      
    const result = [];
    
    for (const bookmark of bookmarks) {
      const material = this.courseMaterials.get(bookmark.materialId);
      if (material) {
        result.push({
          id: bookmark.id,
          material,
          createdAt: bookmark.createdAt
        });
      }
    }
    
    return result;
  }
  
  async addBookmark(userId: number, materialId: number): Promise<UserBookmark> {
    // Check if bookmark already exists
    const existingBookmark = Array.from(this.userBookmarks.values())
      .find(b => b.userId === userId && b.materialId === materialId);
    
    if (existingBookmark) {
      return existingBookmark;
    }
    
    const id = this.bookmarkId++;
    const bookmark: UserBookmark = {
      id,
      userId,
      materialId,
      createdAt: new Date()
    };
    
    this.userBookmarks.set(id, bookmark);
    return bookmark;
  }
  
  async removeBookmark(bookmarkId: number): Promise<void> {
    this.userBookmarks.delete(bookmarkId);
  }
  
  // Quiz operations
  async getQuizzes(courseId?: number): Promise<Quiz[]> {
    const quizzes = Array.from(this.quizzes.values());
    if (courseId !== undefined) {
      return quizzes.filter(quiz => quiz.courseId === courseId);
    }
    return quizzes;
  }
  
  async getQuiz(id: number): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }
  
  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = this.quizId++;
    const now = new Date();
    const quiz: Quiz = {
      ...insertQuiz,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }
  
  async updateQuiz(id: number, quizData: Partial<InsertQuiz>): Promise<Quiz | undefined> {
    const quiz = this.quizzes.get(id);
    if (!quiz) {
      return undefined;
    }
    
    const updatedQuiz: Quiz = {
      ...quiz,
      ...quizData,
      updatedAt: new Date()
    };
    this.quizzes.set(id, updatedQuiz);
    return updatedQuiz;
  }
  
  // Quiz question operations
  async getQuizQuestions(quizId: number): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values())
      .filter(question => question.quizId === quizId)
      .sort((a, b) => a.order - b.order);
  }
  
  async getQuizQuestion(id: number): Promise<QuizQuestion | undefined> {
    return this.quizQuestions.get(id);
  }
  
  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const id = this.quizQuestionId++;
    const question: QuizQuestion = {
      ...insertQuestion,
      id
    };
    this.quizQuestions.set(id, question);
    return question;
  }
  
  async updateQuizQuestion(id: number, questionData: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined> {
    const question = this.quizQuestions.get(id);
    if (!question) {
      return undefined;
    }
    
    const updatedQuestion: QuizQuestion = {
      ...question,
      ...questionData
    };
    this.quizQuestions.set(id, updatedQuestion);
    return updatedQuestion;
  }
  
  // Quiz attempt operations
  async getQuizAttempts(quizId: number, userId?: number): Promise<QuizAttempt[]> {
    let attempts = Array.from(this.quizAttempts.values())
      .filter(attempt => attempt.quizId === quizId);
    
    if (userId !== undefined) {
      attempts = attempts.filter(attempt => attempt.userId === userId);
    }
    
    return attempts.sort((a, b) => 
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
  }
  
  async getQuizAttempt(id: number): Promise<QuizAttempt | undefined> {
    return this.quizAttempts.get(id);
  }
  
  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = this.quizAttemptId++;
    const now = new Date();
    
    // Get the attempt number
    const previousAttempts = Array.from(this.quizAttempts.values())
      .filter(a => a.quizId === insertAttempt.quizId && a.userId === insertAttempt.userId);
    
    const attemptNumber = previousAttempts.length + 1;
    
    const attempt: QuizAttempt = {
      ...insertAttempt,
      id,
      startedAt: now,
      completedAt: null,
      score: null,
      passed: null,
      timeSpent: null,
      attemptNumber
    };
    
    this.quizAttempts.set(id, attempt);
    return attempt;
  }
  
  async completeQuizAttempt(id: number, score: number, passed: boolean): Promise<QuizAttempt | undefined> {
    const attempt = this.quizAttempts.get(id);
    if (!attempt) {
      return undefined;
    }
    
    const now = new Date();
    const timeSpent = Math.floor((now.getTime() - new Date(attempt.startedAt).getTime()) / 1000); // in seconds
    
    const completedAttempt: QuizAttempt = {
      ...attempt,
      completedAt: now,
      score,
      passed,
      timeSpent: timeSpent.toString() // Convert to string
    };
    
    this.quizAttempts.set(id, completedAttempt);
    return completedAttempt;
  }
  
  // Quiz answer operations
  async getQuizAnswers(attemptId: number): Promise<QuizAnswer[]> {
    return Array.from(this.quizAnswers.values())
      .filter(answer => answer.attemptId === attemptId);
  }
  
  async createQuizAnswer(insertAnswer: InsertQuizAnswer): Promise<QuizAnswer> {
    const id = this.quizAnswerId++;
    const answer: QuizAnswer = {
      ...insertAnswer,
      id,
      gradedAt: null,
      gradedBy: null,
      feedback: null
    };
    this.quizAnswers.set(id, answer);
    return answer;
  }
  
  async gradeQuizAnswer(id: number, isCorrect: boolean, pointsEarned: number, feedback?: string): Promise<QuizAnswer | undefined> {
    const answer = this.quizAnswers.get(id);
    if (!answer) {
      return undefined;
    }
    
    const gradedAnswer: QuizAnswer = {
      ...answer,
      isCorrect,
      pointsEarned: pointsEarned.toString(), // Convert to string
      gradedAt: new Date(),
      feedback: feedback || null
    };
    
    this.quizAnswers.set(id, gradedAnswer);
    return gradedAnswer;
  }
  
  // Initialize sample data for demo
  private async initSampleData() {
    // Create sample instructor
    const instructor = await this.createUser({
      username: "instructor",
      password: "$2b$10$8r0h5hQQ9H8Q9Z9l8X9zOuM7J8X9l8X9zOuM7J8X9l8X9zOuM7J8.salt", // "password"
      name: "John Instructor",
      email: "instructor@mentorbox.com",
      role: "instructor"
    });
    
    // Create sample courses
    const digitalMarketing = await this.createCourse({
      title: "Digital Marketing Masterclass",
      description: "Master the fundamentals of digital marketing and build effective campaigns.",
      accessPassword: "dm2025",
      startDate: new Date("2025-03-07"),
      endDate: new Date("2025-03-11"),
      timeStart: "10:00 AM",
      timeEnd: "12:00 PM",
      timezone: "EST",
      type: "online",
      thumbnail: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=450&q=80",
      instructorId: instructor.id,
      category: "Marketing"
    });
    
    const contentCreator = await this.createCourse({
      title: "Content Creator Class",
      description: "Learn to create compelling content for various digital platforms.",
      accessPassword: "cc2025",
      startDate: new Date("2025-03-07"),
      endDate: new Date("2025-03-11"),
      timeStart: "2:00 PM",
      timeEnd: "4:00 PM",
      timezone: "EST",
      type: "online",
      thumbnail: "https://images.unsplash.com/photo-1522542550221-31fd19575a2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=450&q=80",
      instructorId: instructor.id,
      category: "Content Creation"
    });
    
    const dataAnalytics = await this.createCourse({
      title: "Data Analytics Workshop",
      description: "Harness the power of data to make informed business decisions.",
      accessPassword: "da2025",
      startDate: new Date("2025-04-12"),
      endDate: new Date("2025-04-16"),
      timeStart: "9:00 AM",
      timeEnd: "5:00 PM",
      timezone: "EST",
      type: "offline",
      thumbnail: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=450&q=80",
      instructorId: instructor.id,
      category: "Analytics"
    });
    
    // Create modules for Digital Marketing course
    const dmModule1 = await this.createCourseModule({
      courseId: digitalMarketing.id,
      title: "Introduction to Digital Marketing",
      order: 1
    });
    
    const dmModule2 = await this.createCourseModule({
      courseId: digitalMarketing.id,
      title: "SEO Fundamentals",
      order: 2
    });
    
    const dmModule3 = await this.createCourseModule({
      courseId: digitalMarketing.id,
      title: "Keyword Research",
      order: 3
    });
    
    const dmModule4 = await this.createCourseModule({
      courseId: digitalMarketing.id,
      title: "On-Page Optimization",
      order: 4
    });
    
    const dmModule5 = await this.createCourseModule({
      courseId: digitalMarketing.id,
      title: "Link Building Strategies",
      order: 5
    });
    
    // Create materials for Digital Marketing modules
    await this.createCourseMaterial({
      courseId: digitalMarketing.id,
      moduleId: dmModule1.id,
      title: "Introduction to Digital Marketing Video",
      type: "video",
      url: "https://www.youtube.com/embed/e8PvG_tGh0U",
      order: 1
    });
    
    await this.createCourseMaterial({
      courseId: digitalMarketing.id,
      moduleId: dmModule1.id,
      title: "Digital Marketing Overview Slides",
      type: "ppt",
      url: "/uploads/sample-presentation.pptx",
      order: 2
    });
    
    await this.createCourseMaterial({
      courseId: digitalMarketing.id,
      moduleId: dmModule2.id,
      title: "SEO Fundamentals Video",
      type: "video",
      url: "https://www.youtube.com/embed/hFJMi9KH4Wo",
      order: 1
    });
    
    await this.createCourseMaterial({
      courseId: digitalMarketing.id,
      moduleId: dmModule2.id,
      title: "SEO Fundamentals Guide",
      type: "pdf",
      url: "/uploads/sample-pdf.pdf",
      order: 2
    });
    
    await this.createCourseMaterial({
      courseId: digitalMarketing.id,
      moduleId: dmModule2.id,
      title: "Keyword Research Template",
      type: "excel",
      url: "/uploads/sample-excel.xlsx",
      order: 3
    });
    
    // Create modules for Content Creator course
    const ccModule1 = await this.createCourseModule({
      courseId: contentCreator.id,
      title: "Content Creation Basics",
      order: 1
    });
    
    const ccModule2 = await this.createCourseModule({
      courseId: contentCreator.id,
      title: "Video Production Techniques",
      order: 2
    });
    
    const ccModule3 = await this.createCourseModule({
      courseId: contentCreator.id,
      title: "Content Distribution Strategies",
      order: 3
    });
    
    // Create sample self-learning materials
    await this.createSelfLearningMaterial({
      title: "SEO Fundamentals",
      description: "Master the basics of search engine optimization to improve your site's visibility.",
      type: "reading",
      url: "/self-learning/seo-fundamentals",
      duration: "20 min read",
      category: "Digital Marketing",
      icon: "book"
    });
    
    await this.createSelfLearningMaterial({
      title: "Video Editing Basics",
      description: "Learn essential video editing techniques for creating engaging content.",
      type: "video",
      url: "/self-learning/video-editing-basics",
      duration: "45 min video",
      category: "Content Creator",
      icon: "play"
    });
    
    await this.createSelfLearningMaterial({
      title: "Analytics Quiz",
      description: "Test your knowledge of data analytics concepts with this interactive quiz.",
      type: "quiz",
      url: "/self-learning/analytics-quiz",
      duration: "Interactive",
      category: "Data Analytics",
      icon: "puzzle-piece"
    });
    
    // Create sample facts
    await this.createFact({
      content: "Content creators who post consistently (at least 3 times per week) see 2.5x more engagement than those who post sporadically.",
      category: "Content Creation"
    });
    
    await this.createFact({
      content: "Companies that blog receive 97% more links to their website compared to those that don't.",
      category: "Digital Marketing"
    });
    
    await this.createFact({
      content: "The average ROI for email marketing is $42 for every $1 spent, making it one of the most effective marketing channels.",
      category: "Digital Marketing"
    });
    
    await this.createFact({
      content: "Videos under 2 minutes long get the most engagement, with an average retention rate of 70%.",
      category: "Content Creation"
    });
    
    await this.createFact({
      content: "Data-driven organizations are 23 times more likely to acquire customers than their competitors.",
      category: "Analytics"
    });
  }
}

// We're now using the DatabaseStorage implementation
import { DatabaseStorage } from "./database-storage";
export const storage = new DatabaseStorage();
