import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  courseAccessSchema, CourseMaterial, 
  insertQuizSchema, insertQuizQuestionSchema,
  InsertQuizAnswer
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import multer from "multer";
import path from "path";
import fs from "fs";
import { sendWelcomeEmail, sendAdminNotification, sendContactFormEmail, ContactFormData } from "./services/email-service";
import { log } from "./vite";

// Configure file upload storage
const uploadDir = path.resolve(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const upload = multer({ 
  storage: fileStorage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
  fileFilter: (req, file, cb) => {
    // Allow videos, pdfs, images, and common document formats
    const allowedTypes = [
      'video/mp4', 'video/webm', 'video/quicktime',
      'application/pdf', 
      'image/jpeg', 'image/png', 'image/gif',
      'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file type'));
    }
  }
});

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
};

// Middleware to check if user is an instructor
const isInstructor = (req: Request, res: Response, next: Function) => {
  console.log("isInstructor check - user:", req.user?.username, "role:", req.user?.role);
  if (req.isAuthenticated() && req.user && (req.user.role === "instructor" || req.user.role === "admin")) {
    console.log("isInstructor check passed");
    return next();
  }
  console.log("isInstructor check failed");
  res.status(403).json({ message: "Not authorized. Instructor role required." });
};

// Middleware to check if user is an admin
const isAdmin = (req: Request, res: Response, next: Function) => {
  console.log("isAdmin check - user:", req.user?.username, "role:", req.user?.role);
  if (req.isAuthenticated() && req.user && req.user.role === "admin") {
    console.log("isAdmin check passed");
    return next();
  }
  console.log("isAdmin check failed");
  res.status(403).json({ message: "Not authorized. Admin role required." });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Test route for email functionality (admin only)
  app.get("/api/test-email", isAdmin, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // Test admin notification
      const adminResult = await sendAdminNotification(req.user);
      
      // Test welcome email to the current user
      const welcomeResult = await sendWelcomeEmail(req.user);
      
      log('Email test completed', 'email');
      
      res.json({ 
        success: true, 
        adminEmailSent: adminResult, 
        welcomeEmailSent: welcomeResult,
        message: "Email test completed. Check the logs for details."
      });
    } catch (error) {
      console.error('Email test error:', error);
      log(`Email test error: ${error}`, 'email');
      res.status(500).json({ 
        success: false, 
        message: "Email test failed. Check the logs for details."
      });
    }
  });

  // Serve uploaded files
  app.use('/uploads', isAuthenticated, express.static(uploadDir));

  // Course routes
  app.get("/api/courses", isAuthenticated, async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });
  
  // Course creation endpoint moved below to avoid duplication

  app.get("/api/courses/:id", isAuthenticated, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.post("/api/courses/access", isAuthenticated, async (req, res) => {
    try {
      const { courseId, password } = courseAccessSchema.parse(req.body);
      
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      if (course.accessPassword !== password) {
        return res.status(403).json({ message: "Incorrect password" });
      }
      
      // Record that this user has accessed the course
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      await storage.recordCourseAccess(req.user.id, courseId);
      
      res.json({ success: true });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to verify course access" });
    }
  });

  app.get("/api/courses/:id/modules", isAuthenticated, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const modules = await storage.getCourseModules(courseId);
      res.json(modules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course modules" });
    }
  });

  app.get("/api/courses/:id/materials", isAuthenticated, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const materials = await storage.getCourseMaterials(courseId);
      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course materials" });
    }
  });

  app.get("/api/courses/:id/progress", isAuthenticated, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const progress = await storage.getCourseProgress(req.user.id, courseId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course progress" });
    }
  });

  app.post("/api/courses/:id/progress", isAuthenticated, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const { progress } = req.body;
      
      if (typeof progress !== 'number' || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Invalid progress value" });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      await storage.updateCourseProgress(req.user.id, courseId, progress);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update course progress" });
    }
  });

  app.get("/api/courses/upcoming", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Since we don't have any courses yet for the user, return empty array
      // Later when courses are added, this will work properly
      res.json([]);
      
      // Commented out until we have courses in the database
      // const upcomingClasses = await storage.getUpcomingClasses(req.user.id);
      // res.json(upcomingClasses);
    } catch (error) {
      console.error("Error fetching upcoming classes:", error);
      res.status(500).json({ message: "Failed to fetch upcoming classes" });
    }
  });

  // Self-learning materials routes
  app.get("/api/self-learning", isAuthenticated, async (req, res) => {
    try {
      const materials = await storage.getSelfLearningMaterials();
      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch self-learning materials" });
    }
  });

  // Facts routes
  app.get("/api/facts", isAuthenticated, async (req, res) => {
    try {
      const facts = await storage.getFacts();
      res.json(facts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch facts" });
    }
  });

  // Quiz-related routes
  // Get all quizzes or quizzes for a specific course
  app.get("/api/quizzes", isAuthenticated, async (req, res) => {
    try {
      const courseId = req.query.courseId ? parseInt(req.query.courseId as string) : undefined;
      const quizzes = await storage.getQuizzes(courseId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  // Get a specific quiz
  app.get("/api/quizzes/:id", isAuthenticated, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      const quiz = await storage.getQuiz(quizId);
      
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      
      res.json(quiz);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quiz" });
    }
  });

  // Create a new quiz
  app.post("/api/quizzes", isInstructor, async (req, res) => {
    try {
      const quizData = insertQuizSchema.parse(req.body);
      const quiz = await storage.createQuiz(quizData);
      res.status(201).json(quiz);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create quiz" });
    }
  });

  // Update a quiz
  app.patch("/api/quizzes/:id", isInstructor, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      const quizData = req.body;
      
      const updatedQuiz = await storage.updateQuiz(quizId, quizData);
      
      if (!updatedQuiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      
      res.json(updatedQuiz);
    } catch (error) {
      res.status(500).json({ message: "Failed to update quiz" });
    }
  });

  // Get questions for a quiz
  app.get("/api/quizzes/:id/questions", isAuthenticated, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      const questions = await storage.getQuizQuestions(quizId);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quiz questions" });
    }
  });

  // Create a new question for a quiz
  app.post("/api/quizzes/:id/questions", isInstructor, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      
      // Ensure quiz exists
      const quiz = await storage.getQuiz(quizId);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      
      const questionData = insertQuizQuestionSchema.parse({
        ...req.body,
        quizId
      });
      
      const question = await storage.createQuizQuestion(questionData);
      res.status(201).json(question);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create quiz question" });
    }
  });

  // Update a quiz question
  app.patch("/api/quiz-questions/:id", isInstructor, async (req, res) => {
    try {
      const questionId = parseInt(req.params.id);
      const questionData = req.body;
      
      const updatedQuestion = await storage.updateQuizQuestion(questionId, questionData);
      
      if (!updatedQuestion) {
        return res.status(404).json({ message: "Question not found" });
      }
      
      res.json(updatedQuestion);
    } catch (error) {
      res.status(500).json({ message: "Failed to update question" });
    }
  });

  // Get attempts for a quiz (admin/instructor) or user's attempts (student)
  app.get("/api/quizzes/:id/attempts", isAuthenticated, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      
      // If student, only get their own attempts
      if (req.user?.role === "student") {
        const attempts = await storage.getQuizAttempts(quizId, req.user.id);
        return res.json(attempts);
      }
      
      // For instructors and admins, get all attempts
      const attempts = await storage.getQuizAttempts(quizId);
      res.json(attempts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quiz attempts" });
    }
  });

  // Start a new quiz attempt
  app.post("/api/quizzes/:id/attempts", isAuthenticated, async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Ensure quiz exists
      const quiz = await storage.getQuiz(quizId);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      
      // Check if user has reached attempt limit
      if (quiz.attemptsAllowed !== null) {
        const attempts = await storage.getQuizAttempts(quizId, userId);
        if (attempts.length >= quiz.attemptsAllowed) {
          return res.status(403).json({ message: "Maximum attempts reached" });
        }
      }
      
      // Create new attempt
      const attempts = await storage.getQuizAttempts(quizId, userId);
      const attemptNumber = attempts.length + 1;
      
      const attempt = await storage.createQuizAttempt({
        quizId,
        userId,
        attemptNumber
      });
      
      res.status(201).json(attempt);
    } catch (error) {
      res.status(500).json({ message: "Failed to create quiz attempt" });
    }
  });

  // Complete a quiz attempt
  app.post("/api/quiz-attempts/:id/complete", isAuthenticated, async (req, res) => {
    try {
      const attemptId = parseInt(req.params.id);
      const { score, passed } = req.body;
      
      // Ensure score is a number between 0 and 100
      if (typeof score !== 'number' || score < 0 || score > 100) {
        return res.status(400).json({ message: "Score must be a number between 0 and 100" });
      }
      
      // Ensure passed is a boolean
      if (typeof passed !== 'boolean') {
        return res.status(400).json({ message: "Passed must be a boolean" });
      }
      
      const completedAttempt = await storage.completeQuizAttempt(attemptId, score, passed);
      
      if (!completedAttempt) {
        return res.status(404).json({ message: "Attempt not found" });
      }
      
      res.json(completedAttempt);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete quiz attempt" });
    }
  });

  // Submit an answer for a quiz question
  app.post("/api/quiz-attempts/:id/answers", isAuthenticated, async (req, res) => {
    try {
      const attemptId = parseInt(req.params.id);
      const { questionId, userAnswer } = req.body;
      
      if (!questionId || !userAnswer) {
        return res.status(400).json({ message: "Question ID and user answer are required" });
      }
      
      // Ensure attempt exists
      const attempt = await storage.getQuizAttempt(attemptId);
      if (!attempt) {
        return res.status(404).json({ message: "Attempt not found" });
      }
      
      // Ensure question exists
      const question = await storage.getQuizQuestion(questionId);
      if (!question) {
        return res.status(404).json({ message: "Question not found" });
      }
      
      // Create answer
      const answerData: InsertQuizAnswer = {
        attemptId,
        questionId,
        userAnswer
      };
      
      // For multiple choice or true/false, we can auto-grade
      if (question.questionType === "multiple_choice" || question.questionType === "true_false") {
        const isCorrect = JSON.stringify(userAnswer) === JSON.stringify(question.correctAnswer);
        answerData.isCorrect = isCorrect;
        answerData.pointsEarned = isCorrect ? question.points.toString() : "0";
      }
      
      const answer = await storage.createQuizAnswer(answerData);
      res.status(201).json(answer);
    } catch (error) {
      res.status(500).json({ message: "Failed to submit answer" });
    }
  });

  // Grade a quiz answer (for instructor/admin)
  app.post("/api/quiz-answers/:id/grade", isInstructor, async (req, res) => {
    try {
      const answerId = parseInt(req.params.id);
      const { isCorrect, pointsEarned, feedback } = req.body;
      
      if (typeof isCorrect !== 'boolean') {
        return res.status(400).json({ message: "isCorrect must be a boolean" });
      }
      
      if (typeof pointsEarned !== 'number' || pointsEarned < 0) {
        return res.status(400).json({ message: "pointsEarned must be a non-negative number" });
      }
      
      const gradedAnswer = await storage.gradeQuizAnswer(answerId, isCorrect, pointsEarned, feedback);
      
      if (!gradedAnswer) {
        return res.status(404).json({ message: "Answer not found" });
      }
      
      res.json(gradedAnswer);
    } catch (error) {
      res.status(500).json({ message: "Failed to grade answer" });
    }
  });
  
  // Enrollment management routes
  app.get("/api/enrollments", isInstructor, async (req, res) => {
    try {
      // Get all user_courses with enrolled=true and include user and course details
      const userCourses = await storage.getAllEnrollments();
      res.json(userCourses);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });
  
  app.post("/api/enrollments", isInstructor, async (req, res) => {
    try {
      const { userId, courseId } = req.body;
      
      if (!userId || !courseId) {
        return res.status(400).json({ message: "User ID and Course ID are required" });
      }
      
      // Create a new enrollment
      const enrollment = await storage.createEnrollment(parseInt(userId), parseInt(courseId));
      res.status(201).json(enrollment);
    } catch (error) {
      console.error("Error creating enrollment:", error);
      res.status(500).json({ message: "Failed to create enrollment" });
    }
  });
  
  app.delete("/api/enrollments/:id", isInstructor, async (req, res) => {
    try {
      const enrollmentId = parseInt(req.params.id);
      
      // Remove the enrollment
      await storage.removeEnrollment(enrollmentId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing enrollment:", error);
      res.status(500).json({ message: "Failed to remove enrollment" });
    }
  });
  
  // Student-specific routes
  app.get("/api/courses/enrolled", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get only courses that the student is enrolled in
      const courses = await storage.getUserEnrolledCourses(req.user.id);
      res.json(courses);
    } catch (error) {
      console.error("Error fetching enrolled courses:", error);
      res.status(500).json({ message: "Failed to fetch enrolled courses" });
    }
  });
  
  app.get("/api/courses/schedule", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const upcomingClasses = await storage.getUpcomingClasses(req.user.id);
      res.json(upcomingClasses);
    } catch (error) {
      console.error("Error fetching class schedule:", error);
      res.status(500).json({ message: "Failed to fetch class schedule" });
    }
  });
  
  app.get("/api/materials/videos", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get enrolled courses first
      const courses = await storage.getUserEnrolledCourses(req.user.id);
      if (!courses || courses.length === 0) {
        return res.json([]);
      }
      
      // Then get all video materials from those courses
      let allVideos: CourseMaterial[] = [];
      for (const course of courses) {
        const materials = await storage.getCourseMaterials(course.id);
        const videos = materials.filter(material => 
          material.type.toLowerCase().includes('video') || 
          material.url.includes('youtube') || 
          material.url.includes('drive.google.com/file')
        );
        allVideos = [...allVideos, ...videos];
      }
      
      res.json(allVideos);
    } catch (error) {
      console.error("Error fetching video materials:", error);
      res.status(500).json({ message: "Failed to fetch video materials" });
    }
  });
  
  // User profile updates
  app.patch("/api/user/profile", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Not implemented yet - placeholder for future implementation
      res.json(req.user);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });
  
  app.patch("/api/user/password", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Not implemented yet - placeholder for future implementation
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating password:", error);
      res.status(500).json({ message: "Failed to update password" });
    }
  });
  
  // Get all users (needed for enrollment management)
  app.get("/api/users", isInstructor, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Instructor routes for content management
  app.post("/api/courses", isInstructor, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Process form data and ensure all fields are properly formatted
      let courseData = { ...req.body };
      
      // Ensure isEditable is a boolean
      courseData.isEditable = courseData.isEditable === true || courseData.isEditable === "true";
      
      // Convert string dates to Date objects for database storage
      try {
        if (typeof courseData.startDate === 'string') {
          courseData.startDate = new Date(courseData.startDate);
        }
        
        if (typeof courseData.endDate === 'string') {
          courseData.endDate = new Date(courseData.endDate);
        }
      } catch (dateError) {
        console.error('Error parsing dates:', dateError);
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      // Set the instructor ID
      courseData.instructorId = req.user.id;
      
      console.log('Creating course with data:', courseData);
      
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error('Error creating course:', error);
      res.status(500).json({ message: "Failed to create course" });
    }
  });
  
  // Module creation API endpoint
  app.post("/api/modules", isInstructor, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const module = await storage.createCourseModule(req.body);
      res.status(201).json(module);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create module" });
    }
  });
  
  // Materials creation via Google Drive or Canva or other external URL
  app.post("/api/materials", isInstructor, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate and prepare course material data
      let materialData = {
        ...req.body,
        // Set default order if not provided
        order: req.body.order || 1
      };
      
      // Handle moduleId properly
      if (materialData.moduleId === '' || materialData.moduleId === undefined) {
        materialData.moduleId = null;
      } else if (typeof materialData.moduleId === 'string') {
        materialData.moduleId = parseInt(materialData.moduleId);
      }
      
      // For Canva links, ensure we have the proper embed URL format
      if (materialData.url && materialData.url.includes('canva.com')) {
        // If it's a view link, convert to embed link
        if (materialData.url.includes('/view/')) {
          materialData.url = materialData.url.replace('/view/', '/embed/');
        }
        // If it doesn't already have /embed/ format, add it
        else if (!materialData.url.includes('/embed/')) {
          const canvaId = materialData.url.split('/').pop();
          if (canvaId) {
            materialData.url = `https://www.canva.com/design/${canvaId}/embed`;
          }
        }
      }
      
      // For Google Drive links, ensure we have the proper embed URL format
      if (materialData.url && materialData.url.includes('drive.google.com')) {
        // Convert view links to embed links
        if (materialData.url.includes('/view')) {
          materialData.url = materialData.url.replace('/view', '/preview');
        }
      }
      
      console.log('Creating course material with data:', materialData);
      
      const material = await storage.createCourseMaterial(materialData);
      res.status(201).json(material);
    } catch (error) {
      console.error('Error creating course material:', error);
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create material", error: error instanceof Error ? error.message : String(error) });
    }
  });
  
  // File upload API endpoint
  app.post("/api/upload", isInstructor, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Get file details for logging
      const { originalname, mimetype, size, filename } = req.file;
      console.log('File uploaded:', { originalname, mimetype, size, filename });
      
      const fileUrl = `/uploads/${req.file.filename}`;
      res.status(201).json({ 
        url: fileUrl,
        filename: originalname,
        type: mimetype,
        size: size
      });
    } catch (error) {
      console.error('Error uploading file:', error);
      res.status(500).json({ 
        message: "Failed to upload file", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post("/api/courses/:id/modules", isInstructor, async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      
      // Process module data
      let moduleData = {
        ...req.body,
        courseId
      };
      
      // Ensure order is valid and has a default
      if (moduleData.order === undefined || moduleData.order === '') {
        moduleData.order = 1;
      } else if (typeof moduleData.order === 'string') {
        moduleData.order = parseInt(moduleData.order);
      }
      
      console.log('Creating module with data:', moduleData);
      
      const module = await storage.createCourseModule(moduleData);
      res.status(201).json(module);
    } catch (error) {
      console.error('Error creating module:', error);
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ 
        message: "Failed to create course module", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.post("/api/courses/:id/materials", isInstructor, upload.single('file'), async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      
      // Check if this is a file upload or an external URL
      let url;
      
      if (req.file) {
        // File was uploaded
        url = `/uploads/${req.file.filename}`;
      } else if (req.body.url) {
        // External URL was provided
        url = req.body.url;
        
        // For Canva links, ensure we have the proper embed URL format
        if (url.includes('canva.com')) {
          // If it's a view link, convert to embed link
          if (url.includes('/view/')) {
            url = url.replace('/view/', '/embed/');
          }
          // If it doesn't already have /embed/ format, add it
          else if (!url.includes('/embed/')) {
            const canvaId = url.split('/').pop();
            if (canvaId) {
              url = `https://www.canva.com/design/${canvaId}/embed`;
            }
          }
        }
        
        // For Google Drive links, ensure we have the proper embed URL format
        if (url.includes('drive.google.com')) {
          // Convert view links to embed links
          if (url.includes('/view')) {
            url = url.replace('/view', '/preview');
          }
        }
      } else {
        return res.status(400).json({ message: "Either file or URL must be provided" });
      }
      
      // Get order value, default to 1 if not provided
      const order = req.body.order ? parseInt(req.body.order) : 1;
      
      // Handle moduleId properly
      let moduleId = null;
      if (req.body.moduleId) {
        if (req.body.moduleId === 'null' || req.body.moduleId === '') {
          moduleId = null;
        } else {
          moduleId = parseInt(req.body.moduleId);
        }
      }
      
      console.log('Creating course material with data:', {
        courseId,
        title: req.body.title,
        type: req.body.type,
        url,
        order,
        moduleId
      });
      
      const material = await storage.createCourseMaterial({
        courseId,
        title: req.body.title,
        type: req.body.type || 'other', // Default type if none provided
        url,
        order,
        moduleId,
        description: req.body.description || null,
        category: req.body.category || 'general'
      });
      
      res.status(201).json(material);
    } catch (error) {
      console.error('Error creating course material:', error);
      if (error instanceof ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create course material", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Bookmarks
  app.get("/api/bookmarks", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const bookmarks = await storage.getUserBookmarks(req.user.id);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });
  
  app.post("/api/bookmarks", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { materialId } = req.body;
      if (!materialId) {
        return res.status(400).json({ message: "Material ID is required" });
      }
      
      const bookmark = await storage.addBookmark(req.user.id, parseInt(materialId));
      res.status(201).json(bookmark);
    } catch (error) {
      console.error("Error adding bookmark:", error);
      res.status(500).json({ message: "Failed to add bookmark" });
    }
  });
  
  app.delete("/api/bookmarks/:id", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const bookmarkId = parseInt(req.params.id);
      if (isNaN(bookmarkId)) {
        return res.status(400).json({ message: "Invalid bookmark ID" });
      }
      
      await storage.removeBookmark(bookmarkId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing bookmark:", error);
      res.status(500).json({ message: "Failed to remove bookmark" });
    }
  });

  // Role switching (Demo only)
  app.post("/api/switch-role", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { role } = req.body;
      if (!role || !["student", "instructor", "admin"].includes(role)) {
        return res.status(400).json({ message: "Invalid role specified" });
      }
      
      // Note: In a real application, this would require admin privileges
      // This is implemented for demo/testing purposes only
      console.log(`User ${req.user.id} switching role from ${req.user.role} to ${role}`);
      
      // Update the user's role in the database 
      const updatedUser = await storage.updateUserRole(req.user.id, role);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user role in database" });
      }
      
      // Update the user's role in the session
      req.user.role = role;
      
      // Save the updated session
      req.session.save((err) => {
        if (err) {
          console.error("Error saving session:", err);
          return res.status(500).json({ message: "Failed to save session" });
        }
        
        // Return the updated user object so client can update its state
        res.json({ 
          success: true,
          user: req.user
        });
      });
    } catch (error) {
      console.error("Error switching role:", error);
      res.status(500).json({ message: "Failed to switch role" });
    }
  });

  // Contact form route - doesn't require authentication to use
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      
      // Basic validation
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ 
          success: false, 
          message: "Missing required fields" 
        });
      }
      
      if (!email.includes('@') || !email.includes('.')) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid email address" 
        });
      }
      
      // Process the contact form
      const contactData: ContactFormData = {
        name,
        email,
        subject,
        message
      };
      
      const emailSent = await sendContactFormEmail(contactData);
      
      if (emailSent) {
        log(`Contact form from ${email} processed successfully`, 'email');
        res.status(200).json({ 
          success: true, 
          message: "Your message has been sent successfully" 
        });
      } else {
        throw new Error("Failed to send email");
      }
    } catch (error) {
      console.error("Contact form error:", error);
      log(`Contact form error: ${error}`, 'email');
      res.status(500).json({ 
        success: false, 
        message: "Failed to process your message. Please try again later." 
      });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
