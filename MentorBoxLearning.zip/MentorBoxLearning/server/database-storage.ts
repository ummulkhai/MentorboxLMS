import { 
  User, InsertUser, Course, InsertCourse, 
  CourseMaterial, InsertCourseMaterial, 
  CourseModule, InsertCourseModule,
  UserCourse, InsertUserCourse,
  SelfLearningMaterial, InsertSelfLearningMaterial,
  Fact, InsertFact, UserBookmark, InsertUserBookmark,
  Quiz, InsertQuiz, QuizQuestion, InsertQuizQuestion,
  QuizAttempt, InsertQuizAttempt, QuizAnswer, InsertQuizAnswer,
  users, courses, courseModules, courseMaterials, 
  userCourses, selfLearningMaterials, facts, userBookmarks,
  quizzes, quizQuestions, quizAttempts, quizAnswers
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, gte, asc, sql } from "drizzle-orm";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Create the session store with the pool from the db connection
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async updateUserRole(id: number, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role })
      .where(eq(users.id, id))
      .returning();
    console.log(`Updated user ${id} role to ${role} in database`);
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure required fields are present
    const userToInsert = {
      ...insertUser,
      role: insertUser.role || "student" // Set a default role if not provided
    };
    const [user] = await db.insert(users).values(userToInsert).returning();
    return user;
  }
  
  // Course operations
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }
  
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    // Ensure required fields are present with their default values
    const courseToInsert = {
      ...insertCourse,
      timezone: insertCourse.timezone || "EST", // Provide default timezone
      type: insertCourse.type || "online", // Provide default type
      isEditable: insertCourse.isEditable === undefined ? true : insertCourse.isEditable // Default to editable
    };
    
    // Validate date fields
    if (typeof courseToInsert.startDate === 'string') {
      courseToInsert.startDate = new Date(courseToInsert.startDate);
    }
    
    if (typeof courseToInsert.endDate === 'string') {
      courseToInsert.endDate = new Date(courseToInsert.endDate);
    }
    
    const [course] = await db.insert(courses).values(courseToInsert).returning();
    return course;
  }
  
  // Course module operations
  async getCourseModules(courseId: number): Promise<CourseModule[]> {
    return await db
      .select()
      .from(courseModules)
      .where(eq(courseModules.courseId, courseId))
      .orderBy(courseModules.order);
  }
  
  async createCourseModule(insertModule: InsertCourseModule): Promise<CourseModule> {
    const [module] = await db.insert(courseModules).values(insertModule).returning();
    return module;
  }
  
  // Course material operations
  async getCourseMaterials(courseId: number): Promise<CourseMaterial[]> {
    return await db
      .select()
      .from(courseMaterials)
      .where(eq(courseMaterials.courseId, courseId))
      .orderBy(courseMaterials.order);
  }
  
  async createCourseMaterial(insertMaterial: InsertCourseMaterial): Promise<CourseMaterial> {
    // Ensure moduleId is handled properly (null instead of undefined)
    const materialToInsert = {
      ...insertMaterial,
      moduleId: insertMaterial.moduleId === undefined ? null : insertMaterial.moduleId
    };
    const [material] = await db.insert(courseMaterials).values(materialToInsert).returning();
    return material;
  }
  
  // User course operations
  async getUserCourses(userId: number): Promise<Course[]> {
    return await db
      .select({
        id: courses.id,
        title: courses.title,
        description: courses.description,
        accessPassword: courses.accessPassword,
        startDate: courses.startDate,
        endDate: courses.endDate,
        timeStart: courses.timeStart,
        timeEnd: courses.timeEnd,
        timezone: courses.timezone,
        type: courses.type,
        thumbnail: courses.thumbnail,
        instructorId: courses.instructorId,
        category: courses.category,
        isEditable: courses.isEditable
      })
      .from(userCourses)
      .innerJoin(courses, eq(userCourses.courseId, courses.id))
      .where(eq(userCourses.userId, userId));
  }
  
  async recordCourseAccess(userId: number, courseId: number): Promise<void> {
    const existingEntry = await db
      .select()
      .from(userCourses)
      .where(and(
        eq(userCourses.userId, userId),
        eq(userCourses.courseId, courseId)
      ));
    
    if (existingEntry.length > 0) {
      // Update the existing record
      await db
        .update(userCourses)
        .set({ lastAccessed: new Date() })
        .where(and(
          eq(userCourses.userId, userId),
          eq(userCourses.courseId, courseId)
        ));
    } else {
      // Create a new record
      await db.insert(userCourses).values({
        userId,
        courseId,
        progress: 0,
        lastAccessed: new Date(),
        enrolled: true,
        enrollmentDate: new Date()
      });
    }
  }
  
  async getCourseProgress(userId: number, courseId: number): Promise<number> {
    const [entry] = await db
      .select({ progress: userCourses.progress })
      .from(userCourses)
      .where(and(
        eq(userCourses.userId, userId),
        eq(userCourses.courseId, courseId)
      ));
    
    return entry ? entry.progress : 0;
  }
  
  async updateCourseProgress(userId: number, courseId: number, progress: number): Promise<void> {
    const existingEntry = await db
      .select()
      .from(userCourses)
      .where(and(
        eq(userCourses.userId, userId),
        eq(userCourses.courseId, courseId)
      ));
    
    if (existingEntry.length > 0) {
      // Update the existing record
      await db
        .update(userCourses)
        .set({ 
          progress, 
          lastAccessed: new Date() 
        })
        .where(and(
          eq(userCourses.userId, userId),
          eq(userCourses.courseId, courseId)
        ));
    } else {
      // Create a new record
      await db.insert(userCourses).values({
        userId,
        courseId,
        progress,
        lastAccessed: new Date(),
        enrolled: true,
        enrollmentDate: new Date()
      });
    }
  }
  
  async getUpcomingClasses(userId: number): Promise<any[]> {
    const userCourses = await this.getUserCourses(userId);
    const now = new Date();
    
    const upcomingClasses: any[] = [];
    
    for (const course of userCourses) {
      if (new Date(course.endDate) >= now) {
        const modules = await this.getCourseModules(course.id);
        
        for (let i = 0; i < modules.length; i++) {
          const module = modules[i];
          // Calculate class date (just for demo - in real app would use actual scheduled dates)
          const startDate = new Date(course.startDate);
          const classDate = new Date(startDate);
          classDate.setDate(startDate.getDate() + i);
          
          upcomingClasses.push({
            id: module.id,
            title: `${course.title}: ${module.title}`,
            date: classDate,
            timeStart: course.timeStart,
            timeEnd: course.timeEnd,
            timezone: course.timezone,
            type: course.type,
            icon: i % 3 === 0 ? 'chalkboard-teacher' : i % 3 === 1 ? 'video' : 'users'
          });
        }
      }
    }
    
    // Sort by date and take only 5
    return upcomingClasses
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .slice(0, 5);
  }
  
  // Self-learning materials operations
  async getSelfLearningMaterials(): Promise<SelfLearningMaterial[]> {
    return await db.select().from(selfLearningMaterials);
  }
  
  async createSelfLearningMaterial(insertMaterial: InsertSelfLearningMaterial): Promise<SelfLearningMaterial> {
    const [material] = await db.insert(selfLearningMaterials).values(insertMaterial).returning();
    return material;
  }
  
  // Facts operations
  async getFacts(): Promise<Fact[]> {
    return await db.select().from(facts);
  }
  
  async createFact(insertFact: InsertFact): Promise<Fact> {
    // Ensure category is handled properly (null instead of undefined)
    const factToInsert = {
      ...insertFact,
      category: insertFact.category === undefined ? null : insertFact.category
    };
    const [fact] = await db.insert(facts).values(factToInsert).returning();
    return fact;
  }
  
  // User operations extensions
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.name);
  }
  
  // Enrollment operations
  async getAllEnrollments(): Promise<any[]> {
    const enrollments = await db
      .select({
        id: userCourses.id,
        userId: userCourses.userId,
        courseId: userCourses.courseId,
        progress: userCourses.progress,
        lastAccessed: userCourses.lastAccessed,
        enrolled: userCourses.enrolled,
        enrollmentDate: userCourses.enrollmentDate
      })
      .from(userCourses)
      .where(eq(userCourses.enrolled, true));
    
    const result = [];
    
    for (const enrollment of enrollments) {
      const user = await this.getUser(enrollment.userId);
      const course = await this.getCourse(enrollment.courseId);
      
      if (user && course) {
        result.push({
          id: enrollment.id,
          user,
          course,
          progress: enrollment.progress,
          lastAccessed: enrollment.lastAccessed,
          enrollmentDate: enrollment.enrollmentDate
        });
      }
    }
    
    return result;
  }
  
  async createEnrollment(userId: number, courseId: number): Promise<UserCourse> {
    // Check if enrollment already exists
    const existingEntries = await db
      .select()
      .from(userCourses)
      .where(and(
        eq(userCourses.userId, userId),
        eq(userCourses.courseId, courseId)
      ));
    
    if (existingEntries.length > 0) {
      const existingEntry = existingEntries[0];
      
      // If exists but not enrolled, update it
      if (!existingEntry.enrolled) {
        const [updatedEntry] = await db
          .update(userCourses)
          .set({ 
            enrolled: true,
            enrollmentDate: new Date()
          })
          .where(eq(userCourses.id, existingEntry.id))
          .returning();
        
        return updatedEntry;
      }
      
      return existingEntry;
    }
    
    // Create new enrollment
    const [enrollment] = await db
      .insert(userCourses)
      .values({
        userId,
        courseId,
        progress: 0,
        lastAccessed: null,
        enrolled: true,
        enrollmentDate: new Date()
      })
      .returning();
    
    return enrollment;
  }
  
  async removeEnrollment(enrollmentId: number): Promise<void> {
    await db
      .update(userCourses)
      .set({ enrolled: false })
      .where(eq(userCourses.id, enrollmentId));
  }
  
  async getUserEnrolledCourses(userId: number): Promise<Course[]> {
    return await db
      .select({
        id: courses.id,
        title: courses.title,
        description: courses.description,
        accessPassword: courses.accessPassword,
        startDate: courses.startDate,
        endDate: courses.endDate,
        timeStart: courses.timeStart,
        timeEnd: courses.timeEnd,
        timezone: courses.timezone,
        type: courses.type,
        thumbnail: courses.thumbnail,
        instructorId: courses.instructorId,
        category: courses.category,
        isEditable: courses.isEditable
      })
      .from(userCourses)
      .innerJoin(courses, eq(userCourses.courseId, courses.id))
      .where(and(
        eq(userCourses.userId, userId),
        eq(userCourses.enrolled, true)
      ));
  }
  
  // Bookmark operations
  async getUserBookmarks(userId: number): Promise<any[]> {
    const bookmarks = await db
      .select()
      .from(userBookmarks)
      .where(eq(userBookmarks.userId, userId));
      
    const result = [];
    
    for (const bookmark of bookmarks) {
      const [material] = await db
        .select()
        .from(courseMaterials)
        .where(eq(courseMaterials.id, bookmark.materialId));
      
      if (material) {
        result.push({
          id: bookmark.id,
          material,
          createdAt: bookmark.createdAt
        });
      }
    }
    
    return result;
  }
  
  async addBookmark(userId: number, materialId: number): Promise<UserBookmark> {
    // Check if bookmark already exists
    const existingBookmarks = await db
      .select()
      .from(userBookmarks)
      .where(and(
        eq(userBookmarks.userId, userId),
        eq(userBookmarks.materialId, materialId)
      ));
    
    if (existingBookmarks.length > 0) {
      return existingBookmarks[0];
    }
    
    // Create new bookmark
    const [bookmark] = await db
      .insert(userBookmarks)
      .values({
        userId,
        materialId
      })
      .returning();
    
    return bookmark;
  }
  
  async removeBookmark(bookmarkId: number): Promise<void> {
    await db
      .delete(userBookmarks)
      .where(eq(userBookmarks.id, bookmarkId));
  }

  // Quiz operations
  async getQuizzes(courseId?: number): Promise<Quiz[]> {
    if (courseId !== undefined) {
      return await db
        .select()
        .from(quizzes)
        .where(eq(quizzes.courseId, courseId))
        .orderBy(quizzes.createdAt);
    }
    return await db.select().from(quizzes).orderBy(quizzes.createdAt);
  }
  
  async getQuiz(id: number): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }
  
  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const [quiz] = await db.insert(quizzes).values(insertQuiz).returning();
    return quiz;
  }
  
  async updateQuiz(id: number, quizData: Partial<InsertQuiz>): Promise<Quiz | undefined> {
    const [updatedQuiz] = await db
      .update(quizzes)
      .set({
        ...quizData, 
        updatedAt: new Date()
      })
      .where(eq(quizzes.id, id))
      .returning();
    
    return updatedQuiz;
  }
  
  // Quiz question operations
  async getQuizQuestions(quizId: number): Promise<QuizQuestion[]> {
    return await db
      .select()
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quizId))
      .orderBy(quizQuestions.order);
  }
  
  async getQuizQuestion(id: number): Promise<QuizQuestion | undefined> {
    const [question] = await db.select().from(quizQuestions).where(eq(quizQuestions.id, id));
    return question;
  }
  
  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const [question] = await db.insert(quizQuestions).values(insertQuestion).returning();
    return question;
  }
  
  async updateQuizQuestion(id: number, questionData: Partial<InsertQuizQuestion>): Promise<QuizQuestion | undefined> {
    const [updatedQuestion] = await db
      .update(quizQuestions)
      .set(questionData)
      .where(eq(quizQuestions.id, id))
      .returning();
    
    return updatedQuestion;
  }
  
  // Quiz attempt operations
  async getQuizAttempts(quizId: number, userId?: number): Promise<QuizAttempt[]> {
    if (userId !== undefined) {
      return await db
        .select()
        .from(quizAttempts)
        .where(and(
          eq(quizAttempts.quizId, quizId),
          eq(quizAttempts.userId, userId)
        ))
        .orderBy(sql`${quizAttempts.startedAt} DESC`);
    }
    
    return await db
      .select()
      .from(quizAttempts)
      .where(eq(quizAttempts.quizId, quizId))
      .orderBy(sql`${quizAttempts.startedAt} DESC`);
  }
  
  async getQuizAttempt(id: number): Promise<QuizAttempt | undefined> {
    const [attempt] = await db.select().from(quizAttempts).where(eq(quizAttempts.id, id));
    return attempt;
  }
  
  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    // Get the attempt number
    const existingAttempts = await db
      .select()
      .from(quizAttempts)
      .where(and(
        eq(quizAttempts.quizId, insertAttempt.quizId),
        eq(quizAttempts.userId, insertAttempt.userId)
      ));
    
    const attemptNumber = existingAttempts.length + 1;
    
    const [attempt] = await db
      .insert(quizAttempts)
      .values({
        ...insertAttempt,
        attemptNumber
      })
      .returning();
    
    return attempt;
  }
  
  async completeQuizAttempt(id: number, score: number, passed: boolean): Promise<QuizAttempt | undefined> {
    const [attempt] = await db.select().from(quizAttempts).where(eq(quizAttempts.id, id));
    
    if (!attempt) {
      return undefined;
    }
    
    const now = new Date();
    const startTime = new Date(attempt.startedAt);
    const timeSpent = Math.floor((now.getTime() - startTime.getTime()) / 1000); // in seconds
    
    const [completedAttempt] = await db
      .update(quizAttempts)
      .set({
        completedAt: now,
        score,
        passed,
        timeSpent: timeSpent.toString() // Convert to string as per schema
      })
      .where(eq(quizAttempts.id, id))
      .returning();
    
    return completedAttempt;
  }
  
  // Quiz answer operations
  async getQuizAnswers(attemptId: number): Promise<QuizAnswer[]> {
    return await db
      .select()
      .from(quizAnswers)
      .where(eq(quizAnswers.attemptId, attemptId));
  }
  
  async createQuizAnswer(insertAnswer: InsertQuizAnswer): Promise<QuizAnswer> {
    const [answer] = await db
      .insert(quizAnswers)
      .values(insertAnswer)
      .returning();
    
    return answer;
  }
  
  async gradeQuizAnswer(id: number, isCorrect: boolean, pointsEarned: number, feedback?: string): Promise<QuizAnswer | undefined> {
    const [answer] = await db.select().from(quizAnswers).where(eq(quizAnswers.id, id));
    
    if (!answer) {
      return undefined;
    }
    
    const [gradedAnswer] = await db
      .update(quizAnswers)
      .set({
        isCorrect,
        pointsEarned: pointsEarned.toString(), // Convert to string as per schema
        gradedAt: new Date(),
        feedback: feedback || null
      })
      .where(eq(quizAnswers.id, id))
      .returning();
    
    return gradedAnswer;
  }
}