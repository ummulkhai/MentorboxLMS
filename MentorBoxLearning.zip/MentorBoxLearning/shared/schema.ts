import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").default("student").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const courseTypeEnum = pgEnum("course_type", ["online", "offline"]);

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  accessPassword: text("access_password").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  timeStart: text("time_start").notNull(),
  timeEnd: text("time_end").notNull(),
  timezone: text("timezone").default("WIB").notNull(),
  type: courseTypeEnum("type").default("online").notNull(),
  thumbnail: text("thumbnail").notNull(),
  instructorId: integer("instructor_id").references(() => users.id).notNull(),
  category: text("category").notNull(),
  isEditable: boolean("is_editable").default(true).notNull(),
});

export const materialCategoryEnum = pgEnum("material_category", ["lecture_notes", "assignment", "reference", "supplementary", "exam", "other"]);

export const courseMaterials = pgTable("course_materials", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull(), // video, pdf, ppt, etc.
  url: text("url").notNull(),
  order: integer("order").notNull(),
  moduleId: integer("module_id").references(() => courseModules.id),
  category: materialCategoryEnum("category").default("other"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const courseModules = pgTable("course_modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  title: text("title").notNull(),
  order: integer("order").notNull(),
});

export const userCourses = pgTable("user_courses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  progress: integer("progress").default(0).notNull(),
  lastAccessed: timestamp("last_accessed"),
  enrolled: boolean("enrolled").default(true).notNull(),
  enrollmentDate: timestamp("enrollment_date").defaultNow().notNull(),
});

export const selfLearningMaterials = pgTable("self_learning_materials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // reading, video, quiz
  url: text("url").notNull(),
  duration: text("duration").notNull(),
  category: text("category").notNull(),
  icon: text("icon").notNull(),
});

export const facts = pgTable("facts", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  category: text("category"),
});

export const userBookmarks = pgTable("user_bookmarks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  materialId: integer("material_id").references(() => courseMaterials.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz types
export const quizTypeEnum = pgEnum("quiz_type", ["multiple_choice", "true_false", "short_answer", "essay", "matching"]);

// Quizzes table
export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  moduleId: integer("module_id").references(() => courseModules.id),
  timeLimit: integer("time_limit"), // in minutes, null means no time limit
  passingScore: integer("passing_score").default(60).notNull(), // percentage required to pass
  attemptsAllowed: integer("attempts_allowed").default(1), // null means unlimited
  randomizeQuestions: boolean("randomize_questions").default(false),
  showCorrectAnswers: boolean("show_correct_answers").default(true),
  isActive: boolean("is_active").default(true),
  dueDate: timestamp("due_date"), // null means no due date
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Quiz questions table
export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id").references(() => quizzes.id).notNull(),
  questionText: text("question_text").notNull(),
  questionType: quizTypeEnum("question_type").default("multiple_choice").notNull(),
  points: integer("points").default(1).notNull(),
  order: integer("order").notNull(),
  options: jsonb("options"), // For multiple choice, matching, etc.
  correctAnswer: jsonb("correct_answer").notNull(), // Store as JSON to handle different answer types
  explanation: text("explanation"), // Explanation for the correct answer
});

// User quiz attempts table
export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id").references(() => quizzes.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  score: decimal("score", { precision: 5, scale: 2 }), // Percentage score
  passed: boolean("passed"),
  timeSpent: integer("time_spent"), // in seconds
  attemptNumber: integer("attempt_number").notNull(),
});

// User answers to quiz questions
export const quizAnswers = pgTable("quiz_answers", {
  id: serial("id").primaryKey(),
  attemptId: integer("attempt_id").references(() => quizAttempts.id).notNull(),
  questionId: integer("question_id").references(() => quizQuestions.id).notNull(),
  userAnswer: jsonb("user_answer").notNull(),
  isCorrect: boolean("is_correct"),
  pointsEarned: decimal("points_earned", { precision: 5, scale: 2 }),
  gradedAt: timestamp("graded_at"),
  gradedBy: integer("graded_by").references(() => users.id), // For manually graded questions
  feedback: text("feedback"), // Instructor feedback
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true });
export const insertCourseMaterialSchema = createInsertSchema(courseMaterials).omit({ id: true, createdAt: true });
export const insertCourseModuleSchema = createInsertSchema(courseModules).omit({ id: true });
export const insertUserCourseSchema = createInsertSchema(userCourses).omit({ id: true });
export const insertSelfLearningMaterialSchema = createInsertSchema(selfLearningMaterials).omit({ id: true });
export const insertFactSchema = createInsertSchema(facts).omit({ id: true });
export const insertUserBookmarkSchema = createInsertSchema(userBookmarks).omit({ id: true, createdAt: true });

// Quiz schemas
export const insertQuizSchema = createInsertSchema(quizzes).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({ 
  id: true 
});

export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).omit({ 
  id: true, 
  startedAt: true,
  completedAt: true 
});

export const insertQuizAnswerSchema = createInsertSchema(quizAnswers).omit({ 
  id: true, 
  gradedAt: true 
});

// Login Schema
export const loginSchema = z.object({
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" }),
});

// Course Access Schema
export const courseAccessSchema = z.object({
  courseId: z.number(),
  password: z.string().min(1, { message: "Password is required" }),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertCourseMaterial = z.infer<typeof insertCourseMaterialSchema>;
export type CourseMaterial = typeof courseMaterials.$inferSelect;
export type InsertCourseModule = z.infer<typeof insertCourseModuleSchema>;
export type CourseModule = typeof courseModules.$inferSelect;
export type InsertUserCourse = z.infer<typeof insertUserCourseSchema>;
export type UserCourse = typeof userCourses.$inferSelect;
export type InsertSelfLearningMaterial = z.infer<typeof insertSelfLearningMaterialSchema>;
export type SelfLearningMaterial = typeof selfLearningMaterials.$inferSelect;
export type InsertFact = z.infer<typeof insertFactSchema>;
export type Fact = typeof facts.$inferSelect;
export type InsertUserBookmark = z.infer<typeof insertUserBookmarkSchema>;
export type UserBookmark = typeof userBookmarks.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type CourseAccess = z.infer<typeof courseAccessSchema>;

// Quiz types
export type InsertQuiz = z.infer<typeof insertQuizSchema>;
export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAnswer = z.infer<typeof insertQuizAnswerSchema>;
export type QuizAnswer = typeof quizAnswers.$inferSelect;
