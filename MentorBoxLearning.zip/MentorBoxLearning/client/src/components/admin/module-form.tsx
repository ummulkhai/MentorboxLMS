import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertCourseModuleSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Extend the insert schema with validations
const moduleSchema = insertCourseModuleSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  courseId: z.number().min(1, "Please select a course"),
  order: z.number().min(1, "Order must be at least 1"),
});

type ModuleFormValues = z.infer<typeof moduleSchema>;

interface Course {
  id: number;
  title: string;
}

interface ModuleFormProps {
  courses: Course[];
  onModuleCreated?: () => void;
}

export function ModuleForm({ courses, onModuleCreated }: ModuleFormProps) {
  const { toast } = useToast();

  // Set up form with default values
  const form = useForm<ModuleFormValues>({
    resolver: zodResolver(moduleSchema),
    defaultValues: {
      title: "",
      courseId: 0,
      order: 1,
    },
  });

  // Create module mutation
  const createModuleMutation = useMutation({
    mutationFn: async (data: ModuleFormValues) => {
      const res = await apiRequest("POST", "/api/modules", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Module created",
        description: "Your module has been created successfully.",
      });
      form.reset();
      // Refresh modules data
      queryClient.invalidateQueries({ queryKey: ["/api/modules"] });
      
      if (onModuleCreated) {
        onModuleCreated();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create module",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: ModuleFormValues) {
    createModuleMutation.mutate(data);
  }

  // Sort courses alphabetically
  const sortedCourses = [...courses].sort((a, b) => 
    a.title.localeCompare(b.title)
  );

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="courseId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Select Course</FormLabel>
              <Select
                onValueChange={(value) => field.onChange(parseInt(value))}
                value={field.value ? field.value.toString() : undefined}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a course" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {sortedCourses.map((course) => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormDescription>
                Choose the course this module belongs to
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Title</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Introduction to the Course" {...field} />
              </FormControl>
              <FormDescription>
                Give a clear name to help students understand the module content
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="order"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Order</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  min={1} 
                  placeholder="1" 
                  {...field} 
                  onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                />
              </FormControl>
              <FormDescription>
                Set the display order of this module in the course
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full"
          disabled={createModuleMutation.isPending}
        >
          {createModuleMutation.isPending ? "Creating..." : "Create Module"}
        </Button>
      </form>
    </Form>
  );
}