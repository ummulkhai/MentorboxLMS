import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertCourseMaterialSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Loader2, ExternalLink, FileUp } from "lucide-react";

// Google Drive URL schema - extends the insert schema specifically for Google Drive embeds
const googleDriveSchema = insertCourseMaterialSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  type: z.literal("google-drive"),
  courseId: z.number().min(1, "Please select a course"),
  moduleId: z.number().min(1, "Please select a module"),
  url: z.string().url("Please enter a valid URL"),
  order: z.number().min(1, "Order must be at least 1"),
});

// File upload schema - extends the insert schema specifically for file uploads
const fileUploadSchema = insertCourseMaterialSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  type: z.literal("file"),
  courseId: z.number().min(1, "Please select a course"),
  moduleId: z.number().min(1, "Please select a module"),
  url: z.string(), // Will be populated after file upload
  order: z.number().min(1, "Order must be at least 1"),
});

type GoogleDriveFormValues = z.infer<typeof googleDriveSchema>;
type FileUploadFormValues = z.infer<typeof fileUploadSchema>;

interface CourseModule {
  id: number;
  title: string;
}

interface Course {
  id: number;
  title: string;
  modules: CourseModule[];
}

interface MaterialUploadFormProps {
  courses: Course[];
  minimized?: boolean;
}

export function MaterialUploadForm({ courses, minimized = false }: MaterialUploadFormProps) {
  const { toast } = useToast();
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  const [fileSelected, setFileSelected] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Set up Google Drive form
  const googleDriveForm = useForm<GoogleDriveFormValues>({
    resolver: zodResolver(googleDriveSchema),
    defaultValues: {
      title: "",
      type: "google-drive",
      url: "",
      courseId: 0,
      moduleId: 0,
      order: 1,
    },
  });

  // Set up file upload form
  const fileUploadForm = useForm<FileUploadFormValues>({
    resolver: zodResolver(fileUploadSchema),
    defaultValues: {
      title: "",
      type: "file",
      url: "",
      courseId: 0,
      moduleId: 0,
      order: 1,
    },
  });

  // Handle Google Drive URL submission
  const googleDriveMutation = useMutation({
    mutationFn: async (data: GoogleDriveFormValues) => {
      // Transform Google Drive URL if needed
      data.url = formatGoogleDriveUrl(data.url);
      
      const res = await apiRequest("POST", "/api/materials", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Google Drive content added",
        description: "The content has been successfully linked to the course.",
      });
      googleDriveForm.reset();
      // Refresh materials data
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add Google Drive content",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle file upload submission
  const fileUploadMutation = useMutation({
    mutationFn: async (data: FileUploadFormValues) => {
      // If there's a file selected, upload it first
      if (fileSelected) {
        setIsUploading(true);
        
        // Create a FormData to send the file
        const formData = new FormData();
        formData.append('file', fileSelected);
        
        try {
          // Upload the file first
          const uploadRes = await fetch('/api/upload', {
            method: 'POST',
            body: formData,
          });
          
          if (!uploadRes.ok) {
            throw new Error('File upload failed');
          }
          
          const { url } = await uploadRes.json();
          
          // Set the returned URL to the form data
          data.url = url;
          
          // Now create the material with the file URL
          const res = await apiRequest("POST", "/api/materials", data);
          return await res.json();
        } finally {
          setIsUploading(false);
        }
      } else {
        throw new Error('No file selected');
      }
    },
    onSuccess: () => {
      toast({
        title: "File uploaded",
        description: "The file has been successfully uploaded and linked to the course.",
      });
      fileUploadForm.reset();
      setFileSelected(null);
      // Refresh materials data
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to upload file",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onGoogleDriveSubmit(data: GoogleDriveFormValues) {
    googleDriveMutation.mutate(data);
  }

  function onFileUploadSubmit(data: FileUploadFormValues) {
    fileUploadMutation.mutate(data);
  }

  // Helper function to transform Google Drive URLs into embedded format
  function formatGoogleDriveUrl(url: string): string {
    // Check if it's a Google Drive file link
    if (url.includes('drive.google.com/file/d/')) {
      // Extract file ID from the URL
      const fileIdMatch = url.match(/\/d\/([^/]+)/);
      if (fileIdMatch && fileIdMatch[1]) {
        return `https://drive.google.com/file/d/${fileIdMatch[1]}/preview`;
      }
    }
    
    // Check if it's a Google Docs link
    if (url.includes('docs.google.com/document/d/')) {
      // Extract document ID from the URL
      const docIdMatch = url.match(/\/d\/([^/]+)/);
      if (docIdMatch && docIdMatch[1]) {
        return `https://docs.google.com/document/d/${docIdMatch[1]}/preview`;
      }
    }
    
    // Check if it's a Google Sheets link
    if (url.includes('docs.google.com/spreadsheets/d/')) {
      // Extract spreadsheet ID from the URL
      const sheetIdMatch = url.match(/\/d\/([^/]+)/);
      if (sheetIdMatch && sheetIdMatch[1]) {
        return `https://docs.google.com/spreadsheets/d/${sheetIdMatch[1]}/preview`;
      }
    }
    
    // Check if it's a Google Slides link
    if (url.includes('docs.google.com/presentation/d/')) {
      // Extract presentation ID from the URL
      const presentationIdMatch = url.match(/\/d\/([^/]+)/);
      if (presentationIdMatch && presentationIdMatch[1]) {
        return `https://docs.google.com/presentation/d/${presentationIdMatch[1]}/preview`;
      }
    }
    
    // If it's already in an embed format or not recognizable, return as is
    return url;
  }

  // Get modules for the selected course
  const filteredModules = selectedCourseId 
    ? courses.find(c => c.id === selectedCourseId)?.modules || []
    : [];

  return (
    <Tabs defaultValue="google-drive" className="w-full">
      <TabsList className="grid grid-cols-2 w-full max-w-md mb-6">
        <TabsTrigger value="google-drive" className="flex items-center gap-2">
          <ExternalLink className="h-4 w-4" />
          <span>Google Drive</span>
        </TabsTrigger>
        <TabsTrigger value="file-upload" className="flex items-center gap-2">
          <FileUp className="h-4 w-4" />
          <span>File Upload</span>
        </TabsTrigger>
      </TabsList>
      
      {/* Google Drive embedding form */}
      <TabsContent value="google-drive">
        <div className="border rounded-lg p-6">
          <h3 className="text-lg font-medium mb-4">Add Google Drive Content</h3>
          <Form {...googleDriveForm}>
            <form onSubmit={googleDriveForm.handleSubmit(onGoogleDriveSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={googleDriveForm.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Course</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          const courseId = parseInt(value);
                          field.onChange(courseId);
                          setSelectedCourseId(courseId);
                          // Reset module selection
                          googleDriveForm.setValue("moduleId", 0);
                        }}
                        value={field.value ? field.value.toString() : undefined}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {courses.map((course) => (
                            <SelectItem key={course.id} value={course.id.toString()}>
                              {course.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={googleDriveForm.control}
                  name="moduleId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Module</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value ? field.value.toString() : undefined}
                        disabled={!selectedCourseId || filteredModules.length === 0}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a module" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {filteredModules.map((module) => (
                            <SelectItem key={module.id} value={module.id.toString()}>
                              {module.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        {filteredModules.length === 0 && selectedCourseId 
                          ? "No modules available for this course. Create a module first." 
                          : "Select the module this material belongs to"}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={googleDriveForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Material Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Introduction Slides" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={googleDriveForm.control}
                name="url"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Google Drive URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://drive.google.com/file/d/..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Paste the share link from Google Drive. We support Docs, Sheets, Slides, and Files.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={googleDriveForm.control}
                name="order"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Display Order</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={1} 
                        placeholder="1" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                      />
                    </FormControl>
                    <FormDescription>
                      The order in which this material appears in the module
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                disabled={googleDriveMutation.isPending}
              >
                {googleDriveMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  "Add Google Drive Content"
                )}
              </Button>
            </form>
          </Form>
        </div>
      </TabsContent>
      
      {/* File upload form */}
      <TabsContent value="file-upload">
        <div className="border rounded-lg p-6">
          <h3 className="text-lg font-medium mb-4">Upload File</h3>
          <Form {...fileUploadForm}>
            <form onSubmit={fileUploadForm.handleSubmit(onFileUploadSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={fileUploadForm.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Course</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          const courseId = parseInt(value);
                          field.onChange(courseId);
                          setSelectedCourseId(courseId);
                          // Reset module selection
                          fileUploadForm.setValue("moduleId", 0);
                        }}
                        value={field.value ? field.value.toString() : undefined}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {courses.map((course) => (
                            <SelectItem key={course.id} value={course.id.toString()}>
                              {course.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={fileUploadForm.control}
                  name="moduleId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Module</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value ? field.value.toString() : undefined}
                        disabled={!selectedCourseId || filteredModules.length === 0}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a module" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {filteredModules.map((module) => (
                            <SelectItem key={module.id} value={module.id.toString()}>
                              {module.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        {filteredModules.length === 0 && selectedCourseId 
                          ? "No modules available for this course. Create a module first." 
                          : "Select the module this material belongs to"}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={fileUploadForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Material Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Assignment PDF" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* File upload field */}
              <FormItem>
                <FormLabel>Upload File</FormLabel>
                <FormControl>
                  <Input
                    type="file"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setFileSelected(file);
                        // You can set the title to the filename if it's empty
                        if (!fileUploadForm.getValues("title")) {
                          fileUploadForm.setValue("title", file.name);
                        }
                      }
                    }}
                  />
                </FormControl>
                <FormDescription>
                  Select a file to upload (PDF, DOCX, JPG, etc.)
                </FormDescription>
                {fileSelected && (
                  <p className="text-sm text-green-600 mt-1">
                    Selected: {fileSelected.name} ({(fileSelected.size / 1024 / 1024).toFixed(2)} MB)
                  </p>
                )}
              </FormItem>

              <FormField
                control={fileUploadForm.control}
                name="order"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Display Order</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={1} 
                        placeholder="1" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                      />
                    </FormControl>
                    <FormDescription>
                      The order in which this material appears in the module
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                disabled={fileUploadMutation.isPending || isUploading || !fileSelected}
              >
                {fileUploadMutation.isPending || isUploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  "Upload File"
                )}
              </Button>
            </form>
          </Form>
        </div>
      </TabsContent>
    </Tabs>
  );
}