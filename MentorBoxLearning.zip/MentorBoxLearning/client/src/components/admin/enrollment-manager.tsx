import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User, Course } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Loader2, Search, UserPlus, CheckCircle2, XCircle } from "lucide-react";

const enrollmentSchema = z.object({
  userId: z.string().min(1, "User is required"),
  courseId: z.string().min(1, "Course is required"),
});

type EnrollmentFormValues = z.infer<typeof enrollmentSchema>;

interface EnrollmentManagerProps {
  minimized?: boolean;
}

export function EnrollmentManager({ minimized = false }: EnrollmentManagerProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [enrollmentDialogOpen, setEnrollmentDialogOpen] = useState(false);
  
  // Query for all courses
  const { 
    data: courses = [], 
    isLoading: isLoadingCourses 
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Query for all users
  const { 
    data: users = [], 
    isLoading: isLoadingUsers 
  } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Query for all enrollments
  const { 
    data: enrollments = [], 
    isLoading: isLoadingEnrollments,
    refetch: refetchEnrollments
  } = useQuery<any[]>({
    queryKey: ["/api/enrollments"],
  });

  // Set up enrollment form
  const form = useForm<EnrollmentFormValues>({
    resolver: zodResolver(enrollmentSchema),
    defaultValues: {
      userId: "",
      courseId: "",
    },
  });

  // Create enrollment mutation
  const createEnrollmentMutation = useMutation({
    mutationFn: async (data: EnrollmentFormValues) => {
      const res = await apiRequest("POST", "/api/enrollments", {
        userId: parseInt(data.userId),
        courseId: parseInt(data.courseId)
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Enrollment created",
        description: "The student has been successfully enrolled in the course.",
      });
      form.reset();
      setEnrollmentDialogOpen(false);
      refetchEnrollments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create enrollment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Remove enrollment mutation
  const removeEnrollmentMutation = useMutation({
    mutationFn: async (enrollmentId: number) => {
      const res = await apiRequest("DELETE", `/api/enrollments/${enrollmentId}`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Enrollment removed",
        description: "The student has been unenrolled from the course.",
      });
      refetchEnrollments();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to remove enrollment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: EnrollmentFormValues) {
    createEnrollmentMutation.mutate(data);
  }

  // Filter enrollments based on search term
  const filteredEnrollments = enrollments.filter(enrollment => {
    const userMatch = enrollment.user?.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                     enrollment.user?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const courseMatch = enrollment.course?.title?.toLowerCase().includes(searchTerm.toLowerCase());
    return userMatch || courseMatch;
  });

  // Sort users alphabetically for the dropdown
  const sortedUsers = [...users].sort((a, b) => a.name.localeCompare(b.name));
  // Sort courses alphabetically for the dropdown
  const sortedCourses = [...courses].sort((a, b) => a.title.localeCompare(b.title));

  // For minimized mode, show a simplified version of the form
  if (minimized) {
    return (
      <div className="space-y-4">
        <Dialog>
          <DialogTrigger asChild>
            <Button className="w-full">
              <UserPlus className="h-4 w-4 mr-2" />
              Add New Enrollment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Enroll Student in Course</DialogTitle>
              <DialogDescription>
                Select a student and a course to create an enrollment.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="userId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Student</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a student" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sortedUsers
                            .filter(user => user.role === 'student')
                            .map((user) => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.name || user.username}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sortedCourses.map((course) => (
                            <SelectItem key={course.id} value={course.id.toString()}>
                              {course.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="submit" disabled={createEnrollmentMutation.isPending}>
                    {createEnrollmentMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enrolling...
                      </>
                    ) : (
                      "Enroll Student"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        {isLoadingEnrollments ? (
          <div className="flex justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="text-sm text-muted-foreground">
            {enrollments.length} total enrollments
          </div>
        )}
      </div>
    );
  }

  // Regular full view
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search enrollments..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Dialog open={enrollmentDialogOpen} onOpenChange={setEnrollmentDialogOpen}>
          <DialogTrigger asChild>
            <Button className="whitespace-nowrap">
              <UserPlus className="h-4 w-4 mr-2" />
              Enroll Student
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Enroll Student in Course</DialogTitle>
              <DialogDescription>
                Select a student and a course to create an enrollment.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="userId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Student</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a student" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sortedUsers
                            .filter(user => user.role === 'student')
                            .map((user) => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.name} ({user.email})
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sortedCourses.map((course) => (
                            <SelectItem key={course.id} value={course.id.toString()}>
                              {course.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="submit" disabled={createEnrollmentMutation.isPending}>
                    {createEnrollmentMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enrolling...
                      </>
                    ) : (
                      "Enroll Student"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      {isLoadingEnrollments ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableCaption>Manage student enrollments in courses</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Enrollment Date</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEnrollments.length > 0 ? (
                filteredEnrollments.map((enrollment) => (
                  <TableRow key={enrollment.id}>
                    <TableCell className="font-medium">
                      {enrollment.user?.name}
                      <div className="text-xs text-muted-foreground">{enrollment.user?.email}</div>
                    </TableCell>
                    <TableCell>{enrollment.course?.title}</TableCell>
                    <TableCell>{new Date(enrollment.enrollmentDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="w-full bg-secondary rounded-full h-2.5 dark:bg-secondary">
                        <div 
                          className="bg-primary h-2.5 rounded-full" 
                          style={{ width: `${enrollment.progress}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-right mt-1">{enrollment.progress}%</div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeEnrollmentMutation.mutate(enrollment.id)}
                        disabled={removeEnrollmentMutation.isPending}
                      >
                        <XCircle className="h-4 w-4 text-destructive" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                    {searchTerm ? "No enrollments match your search" : "No enrollments found"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}