import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CourseModule, CourseMaterial } from "@shared/schema";
import { Check, Play, X } from "lucide-react";

interface CourseContentModalProps {
  courseTitle: string;
  module: CourseModule;
  currentModuleIndex: number;
  totalModules: number;
  materials: CourseMaterial[];
  progress: number;
  onClose: () => void;
  onNext: () => void;
  onPrevious: () => void;
}

export function CourseContentModal({
  courseTitle,
  module,
  currentModuleIndex,
  totalModules,
  materials,
  progress,
  onClose,
  onNext,
  onPrevious,
}: CourseContentModalProps) {
  const videoMaterial = materials.find(m => m.type === 'video');
  const documentMaterials = materials.filter(m => m.type !== 'video');

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl">
        <div className="absolute top-0 right-0 pt-4 pr-4">
          <button 
            type="button" 
            onClick={onClose}
            className="bg-white rounded-md text-neutral-400 hover:text-neutral-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            <span className="sr-only">Close</span>
            <X className="h-5 w-5" />
          </button>
        </div>
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-neutral-900">{courseTitle}</DialogTitle>
          <p className="mt-1 text-sm text-neutral-600">Module {currentModuleIndex + 1}: {module.title}</p>
        </DialogHeader>
        
        <div className="mt-6">
          {videoMaterial && (
            <div className="video-container mb-6 bg-neutral-100 rounded-lg">
              <div className="aspect-video relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <button className="bg-primary-dark bg-opacity-90 text-white rounded-full w-16 h-16 flex items-center justify-center">
                    <Play className="h-6 w-6" />
                  </button>
                </div>
                <iframe 
                  src={videoMaterial.url} 
                  className="w-full h-full" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <div className="prose max-w-none">
                <h3>Lesson Overview</h3>
                <p>In this lesson, you will learn the fundamental principles related to this module and how to apply them in practical scenarios.</p>
                
                <h4>Key Learning Points:</h4>
                <ul>
                  <li>Understanding core concepts</li>
                  <li>Practical application techniques</li>
                  <li>Best practices and strategies</li>
                  <li>Real-world examples</li>
                  <li>Performance metrics and analysis</li>
                </ul>
                
                <h4>Resources:</h4>
                <div className="mt-4 space-y-3 not-prose">
                  {documentMaterials.map((material) => (
                    <a 
                      key={material.id} 
                      href={material.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center p-3 border border-neutral-200 rounded-md hover:bg-neutral-50"
                    >
                      <span className="flex-shrink-0 h-10 w-10 bg-neutral-100 rounded-md flex items-center justify-center">
                        <i className={`fas fa-${material.type === 'pdf' ? 'file-pdf text-red-500' : material.type === 'ppt' ? 'file-powerpoint text-orange-500' : 'file-excel text-green-500'}`}></i>
                      </span>
                      <div className="ml-3">
                        <h5 className="text-sm font-medium text-neutral-900">{material.title}</h5>
                        <p className="text-xs text-neutral-500">{material.type.toUpperCase()}</p>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="md:col-span-1">
              <div className="bg-neutral-50 p-4 rounded-md">
                <h3 className="text-lg font-medium text-neutral-900 mb-4">Module Contents</h3>
                <ul className="space-y-3">
                  {Array.from({ length: totalModules }).map((_, index) => {
                    const isCurrent = index === currentModuleIndex;
                    const isCompleted = index < currentModuleIndex;
                    
                    return (
                      <li key={index} className={`flex items-center ${isCurrent ? 'font-medium text-primary-dark' : isCompleted ? 'text-neutral-700' : 'text-neutral-400'}`}>
                        <span className={`flex-shrink-0 h-6 w-6 rounded-full flex items-center justify-center mr-2 ${
                          isCompleted ? 'bg-green-100 text-green-600' : 
                          isCurrent ? 'bg-primary-light text-primary-dark' : 
                          'bg-neutral-200 text-neutral-400'
                        }`}>
                          {isCompleted ? (
                            <Check className="h-3 w-3" />
                          ) : (
                            <span className="text-xs">{index + 1}</span>
                          )}
                        </span>
                        <span className="text-sm">{index + 1}. {isCurrent ? module.title : `Module ${index + 1}`}</span>
                      </li>
                    );
                  })}
                </ul>
                
                <div className="mt-6">
                  <h4 className="text-sm font-medium text-neutral-900 mb-2">Your Progress</h4>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full" style={{ width: `${progress}%` }}></div>
                  </div>
                  <div className="mt-1 text-xs text-neutral-500 text-right">{progress}% complete</div>
                </div>
                
                <div className="mt-6 flex justify-between">
                  <Button
                    variant="outline"
                    disabled={currentModuleIndex === 0}
                    onClick={onPrevious}
                    className="text-sm"
                  >
                    <i className="fas fa-arrow-left mr-1"></i> Previous
                  </Button>
                  <Button
                    disabled={currentModuleIndex === totalModules - 1}
                    onClick={onNext}
                    className="text-sm"
                  >
                    Next <i className="fas fa-arrow-right ml-1"></i>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
