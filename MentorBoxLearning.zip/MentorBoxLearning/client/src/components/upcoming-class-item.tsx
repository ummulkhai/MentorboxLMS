import { format } from "date-fns";
import { Calendar, Clock, Video, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type ClassType = "online" | "offline";

interface UpcomingClassItemProps {
  id: number;
  title: string;
  date: Date;
  timeStart: string;
  timeEnd: string;
  timezone: string;
  type: ClassType;
  icon: string;
}

export function UpcomingClassItem({
  id,
  title,
  date,
  timeStart,
  timeEnd,
  timezone,
  type,
  icon,
}: UpcomingClassItemProps) {
  const isOnline = type === "online";
  
  const formattedDate = format(date, "EEEE, MMMM d, yyyy");
  const timeDisplay = `${timeStart} - ${timeEnd} ${timezone}`;
  
  return (
    <li className="py-4 px-4 sm:px-6 hover:bg-neutral-50">
      <div className="flex items-start sm:items-center flex-col sm:flex-row gap-4">
        <div className="flex-shrink-0 rounded-md bg-primary/10 p-2 sm:p-3">
          {isOnline ? (
            <Video className="h-5 w-5 text-primary" />
          ) : (
            <MapPin className="h-5 w-5 text-primary" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-medium text-neutral-900 truncate">{title}</h3>
          <div className="mt-1 flex flex-col sm:flex-row sm:items-center sm:gap-3 text-sm text-neutral-500">
            <div className="flex items-center">
              <Calendar className="mr-1 h-4 w-4" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center mt-1 sm:mt-0">
              <Clock className="mr-1 h-4 w-4" />
              <span>{timeDisplay}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 pt-2 sm:pt-0">
          <Badge variant={isOnline ? "default" : "outline"}>
            {isOnline ? "Online" : "In-person"}
          </Badge>
          <Button 
            variant="outline" 
            size="sm" 
            className={isOnline ? "" : "hidden"}
          >
            Join
          </Button>
        </div>
      </div>
    </li>
  );
}