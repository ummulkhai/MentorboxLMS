import { BookOpen, Clock, ExternalLink } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface SelfLearningCardProps {
  id: number;
  title: string;
  description: string;
  icon: string;
  type: string;
  duration: string;
  category: string;
  onStart: (id: number) => void;
}

export function SelfLearningCard({
  id,
  title,
  description,
  icon,
  type,
  duration,
  category,
  onStart
}: SelfLearningCardProps) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2 flex items-start gap-4">
        <div className="rounded-full bg-primary/10 p-2">
          <BookOpen className="h-4 w-4 text-primary" />
        </div>
        <div className="space-y-1 flex-1">
          <CardTitle className="text-lg font-semibold text-neutral-900">
            {title}
          </CardTitle>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="text-xs">
              {type}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {category}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-0 pt-2 flex-1">
        <p className="text-sm text-neutral-600 line-clamp-3">{description}</p>
      </CardContent>
      <CardFooter className="flex items-center justify-between pt-4">
        <div className="flex items-center text-sm text-neutral-500">
          <Clock className="mr-1 h-3 w-3" />
          <span>{duration}</span>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => onStart(id)}
          className="ml-auto"
        >
          Start <ExternalLink className="ml-1 h-3 w-3" />
        </Button>
      </CardFooter>
    </Card>
  );
}