import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Fact } from "@shared/schema";
import { Lightbulb, ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Define a type that matches the returned data structure
interface FactWithSource extends Fact {
  source?: string;
}

export function FactSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const { data: facts, isLoading } = useQuery<FactWithSource[]>({
    queryKey: ["/api/facts"],
  });
  
  if (isLoading || !facts || facts.length === 0) {
    return null;
  }

  const nextFact = () => {
    setCurrentIndex((prev) => (prev + 1) % facts.length);
  };

  const prevFact = () => {
    setCurrentIndex((prev) => (prev - 1 + facts.length) % facts.length);
  };

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold text-neutral-900 mb-6">Did You Know?</h2>
      
      <Card className="border border-neutral-200 bg-neutral-50">
        <CardContent className="pt-6 px-6 pb-4">
          <div className="flex gap-4 items-start">
            <div className="rounded-full bg-primary/10 p-2 flex-shrink-0">
              <Lightbulb className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-neutral-700">{facts[currentIndex].content}</p>
              {facts[currentIndex].source && (
                <p className="text-sm text-neutral-500 mt-2">Source: {facts[currentIndex].source}</p>
              )}
              {facts[currentIndex].category && (
                <p className="text-sm text-neutral-500 mt-2">Category: {facts[currentIndex].category}</p>
              )}
            </div>
          </div>
          
          {facts.length > 1 && (
            <div className="flex justify-between items-center mt-4">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={prevFact}
                className="text-neutral-500 hover:text-neutral-900"
              >
                <ChevronLeft className="h-4 w-4 mr-1" /> Previous
              </Button>
              <span className="text-sm text-neutral-500">
                {currentIndex + 1} of {facts.length}
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={nextFact}
                className="text-neutral-500 hover:text-neutral-900"
              >
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}