import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { PasswordModal } from "./password-modal";
import { Course } from "@shared/schema";
import { format } from "date-fns";

interface CourseCardProps {
  course: Course;
}

export function CourseCard({ course }: CourseCardProps) {
  const [, navigate] = useLocation();
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  const validateCourseMutation = useMutation({
    mutationFn: async (password: string) => {
      const res = await apiRequest("POST", "/api/courses/access", { courseId: course.id, password });
      return await res.json();
    },
    onSuccess: () => {
      setIsPasswordModalOpen(false);
      navigate(`/course/${course.id}`);
    },
  });

  const handleContinueLearning = () => {
    setIsPasswordModalOpen(true);
  };

  const handlePasswordSubmit = (password: string) => {
    validateCourseMutation.mutate(password);
  };

  const startDate = new Date(course.startDate);
  const endDate = new Date(course.endDate);
  const formattedDateRange = `${format(startDate, "MMM d")} - ${format(endDate, "MMM d, yyyy")}`;

  return (
    <>
      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-neutral-200 hover:shadow-md transition-shadow duration-300 course-card">
        <div className="relative">
          <div className="aspect-video bg-neutral-200">
            <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
          </div>
          <div className="absolute top-2 right-2 bg-secondary text-white text-xs font-semibold px-2 py-1 rounded-full">
            {course.type === "online" ? "Online Class" : "Offline Workshop"}
          </div>
          <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 transition-opacity hover:opacity-100 course-hover-info flex items-center justify-center">
            <button 
              className="bg-white text-primary font-medium py-2 px-4 rounded-md hover:bg-neutral-100"
              onClick={handleContinueLearning}
            >
              Continue Learning
            </button>
          </div>
        </div>
        <div className="p-5">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-neutral-900">{course.title}</h3>
            <span className="bg-primary-light bg-opacity-20 text-primary-dark text-xs px-2 py-1 rounded-full">In Progress</span>
          </div>
          <p className="mt-2 text-sm text-neutral-600">{course.description}</p>
          <div className="mt-3">
            <div className="flex items-center text-sm text-neutral-500">
              <i className="fas fa-calendar-alt mr-2"></i>
              {formattedDateRange}
            </div>
            <div className="mt-1 flex items-center text-sm text-neutral-500">
              <i className="fas fa-clock mr-2"></i>
              {course.timeStart} - {course.timeEnd} ({course.timezone})
            </div>
          </div>
          <div className="mt-4">
            <div className="w-full bg-neutral-200 rounded-full h-2">
              <div className="bg-primary h-2 rounded-full" style={{ width: "65%" }}></div>
            </div>
            <div className="mt-1 text-xs text-neutral-500 text-right">65% complete</div>
          </div>
        </div>
      </div>
      
      {isPasswordModalOpen && (
        <PasswordModal 
          courseId={course.id} 
          courseTitle={course.title}
          onSubmit={handlePasswordSubmit}
          onClose={() => setIsPasswordModalOpen(false)}
          isPending={validateCourseMutation.isPending}
          error={validateCourseMutation.error?.message}
        />
      )}
    </>
  );
}
