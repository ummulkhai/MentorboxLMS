import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";

interface PasswordModalProps {
  courseId: number;
  courseTitle: string;
  onSubmit: (password: string) => void;
  onClose: () => void;
  isPending: boolean;
  error?: string;
}

export function PasswordModal({
  courseId,
  courseTitle,
  onSubmit,
  onClose,
  isPending,
  error,
}: PasswordModalProps) {
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(password);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-start gap-4">
            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-primary-light bg-opacity-20 sm:mx-0 sm:h-10 sm:w-10">
              <Lock className="h-5 w-5 text-primary" />
            </div>
            <div>
              <DialogTitle>Course Access</DialogTitle>
              <DialogDescription>
                This course is password protected. Please enter the password provided by your instructor to access the course materials.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="mt-4">
            <label htmlFor="course-password" className="block text-sm font-medium text-neutral-700">
              Password
            </label>
            <Input
              type="password"
              id="course-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter course password"
              className={error ? "border-red-500" : ""}
            />
            {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
          </div>
          <div className="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3">
            <Button
              type="submit"
              disabled={isPending || !password}
              className="sm:col-start-2"
            >
              {isPending ? "Verifying..." : "Access Course"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="mt-3 sm:col-start-1 sm:mt-0"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
