import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LogOut } from "lucide-react";

interface SidebarProps {
  isMobile: boolean;
  isSidebarOpen: boolean;
}

export function Sidebar({ isMobile, isSidebarOpen }: SidebarProps) {
  const [location] = useLocation();
  const [classes, setClasses] = useState("");
  const { user, logoutMutation } = useAuth();

  useEffect(() => {
    if (isMobile) {
      setClasses(isSidebarOpen ? "translate-x-0" : "-translate-x-full");
    } else {
      setClasses("translate-x-0");
    }
  }, [isMobile, isSidebarOpen]);

  const isActive = (path: string) => {
    // Check for exact path match or subpath match
    return location === path || location.startsWith(`${path}/`);
  };

  const defaultClasses = "group flex items-center px-2 py-2 text-sm font-medium rounded-md text-neutral-700 hover:bg-neutral-100";
  const activeClasses = "group flex items-center px-2 py-2 text-sm font-medium rounded-md bg-primary-light bg-opacity-10 text-primary-dark";

  // Determine user role for rendering appropriate navigation items
  const userRole = user?.role || "student";

  return (
    <aside 
      className={`sidebar-menu bg-white w-64 border-r border-neutral-200 flex-shrink-0 overflow-y-auto h-[calc(100vh-4rem)] fixed md:sticky top-0 z-10 transition-transform duration-300 ${classes}`}
    >
      <nav className="py-6 px-4">
        <div className="flex flex-col h-full">
          {/* LMS Logo/Title */}
          <div className="flex items-center justify-center h-12 mb-6">
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
              Mentorbox LMS
            </h1>
          </div>

          {/* Navigation sections based on role */}
          <div className="space-y-8 flex-grow">
            {/* Admin Navigation */}
            {userRole === "admin" && (
              <>
                <div>
                  <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Administration</h3>
                  <div className="mt-2 space-y-1">
                    <Link href="/admin/dashboard" className={isActive("/admin/dashboard") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-tachometer-alt mr-3 ${isActive("/admin/dashboard") ? "text-primary" : "text-neutral-500"}`}></i>
                      Dashboard
                    </Link>
                    <Link href="/admin/users" className={isActive("/admin/users") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-users mr-3 ${isActive("/admin/users") ? "text-primary" : "text-neutral-500"}`}></i>
                      Manage Users
                    </Link>
                    <Link href="/admin/courses" className={isActive("/admin/courses") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-book mr-3 ${isActive("/admin/courses") ? "text-primary" : "text-neutral-500"}`}></i>
                      Manage Courses
                    </Link>
                    <Link href="/admin/enrollments" className={isActive("/admin/enrollments") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-user-graduate mr-3 ${isActive("/admin/enrollments") ? "text-primary" : "text-neutral-500"}`}></i>
                      Manage Enrollments
                    </Link>
                  </div>
                </div>
              </>
            )}

            {/* Instructor Navigation */}
            {userRole === "instructor" && (
              <>
                <div>
                  <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Instructor</h3>
                  <div className="mt-2 space-y-1">
                    <Link href="/instructor/dashboard" className={isActive("/instructor/dashboard") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-tachometer-alt mr-3 ${isActive("/instructor/dashboard") ? "text-primary" : "text-neutral-500"}`}></i>
                      Dashboard
                    </Link>
                    <Link href="/instructor/courses" className={isActive("/instructor/courses") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-book mr-3 ${isActive("/instructor/courses") ? "text-primary" : "text-neutral-500"}`}></i>
                      My Courses
                    </Link>
                    <Link href="/instructor/materials" className={isActive("/instructor/materials") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-file-upload mr-3 ${isActive("/instructor/materials") ? "text-primary" : "text-neutral-500"}`}></i>
                      Upload Materials
                    </Link>
                    <Link href="/instructor/students" className={isActive("/instructor/students") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-user-graduate mr-3 ${isActive("/instructor/students") ? "text-primary" : "text-neutral-500"}`}></i>
                      My Students
                    </Link>
                    <Link href="/instructor/quizzes" className={isActive("/instructor/quizzes") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-tasks mr-3 ${isActive("/instructor/quizzes") ? "text-primary" : "text-neutral-500"}`}></i>
                      Quizzes & Assessments
                    </Link>
                  </div>
                </div>
              </>
            )}

            {/* Student Navigation */}
            {userRole === "student" && (
              <>
                <div>
                  <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Dashboard</h3>
                  <div className="mt-2 space-y-1">
                    <Link href="/student/dashboard" className={isActive("/student/dashboard") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-home mr-3 ${isActive("/student/dashboard") ? "text-primary" : "text-neutral-500"}`}></i>
                      Home
                    </Link>
                    <Link href="/student/schedule" className={isActive("/student/schedule") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-calendar-alt mr-3 ${isActive("/student/schedule") ? "text-primary" : "text-neutral-500"}`}></i>
                      My Schedule
                    </Link>
                    <Link href="/student/courses" className={isActive("/student/courses") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-book-open mr-3 ${isActive("/student/courses") ? "text-primary" : "text-neutral-500"}`}></i>
                      My Courses
                    </Link>
                  </div>
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Learning</h3>
                  <div className="mt-2 space-y-1">
                    <Link href="/student/quizzes" className={isActive("/student/quizzes") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-tasks mr-3 ${isActive("/student/quizzes") ? "text-primary" : "text-neutral-500"}`}></i>
                      Quizzes
                    </Link>
                    <Link href="/student/video-lessons" className={isActive("/student/video-lessons") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-play-circle mr-3 ${isActive("/student/video-lessons") ? "text-primary" : "text-neutral-500"}`}></i>
                      Video Lessons
                    </Link>
                    <Link href="/student/resources" className={isActive("/student/resources") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-file-alt mr-3 ${isActive("/student/resources") ? "text-primary" : "text-neutral-500"}`}></i>
                      Resources
                    </Link>
                    <Link href="/student/self-learning" className={isActive("/student/self-learning") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-tasks mr-3 ${isActive("/student/self-learning") ? "text-primary" : "text-neutral-500"}`}></i>
                      Self-Learning
                    </Link>
                    <Link href="/student/bookmarks" className={isActive("/student/bookmarks") ? activeClasses : defaultClasses}>
                      <i className={`fas fa-bookmark mr-3 ${isActive("/student/bookmarks") ? "text-primary" : "text-neutral-500"}`}></i>
                      My Bookmarks
                    </Link>
                  </div>
                </div>
              </>
            )}

            {/* Support Section (visible to all users) */}
            <div>
              <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Support</h3>
              <div className="mt-2 space-y-1">
                <Link href="/help-center" className={isActive("/help-center") ? activeClasses : defaultClasses}>
                  <i className={`fas fa-question-circle mr-3 ${isActive("/help-center") ? "text-primary" : "text-neutral-500"}`}></i>
                  Help Center
                </Link>
                <Link href="/contact-us" className={isActive("/contact-us") ? activeClasses : defaultClasses}>
                  <i className={`fas fa-comment-alt mr-3 ${isActive("/contact-us") ? "text-primary" : "text-neutral-500"}`}></i>
                  Contact Us
                </Link>
              </div>
            </div>
            
            {/* Demo Tools (visible to all users) - For development/testing only */}
            <div>
              <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Demo Tools</h3>
              <div className="mt-2 space-y-1">
                <Link href="/role-switcher" className={isActive("/role-switcher") ? activeClasses : defaultClasses}>
                  <i className={`fas fa-exchange-alt mr-3 ${isActive("/role-switcher") ? "text-primary" : "text-neutral-500"}`}></i>
                  Switch Role
                </Link>
              </div>
            </div>
          </div>

          {/* User info and logout */}
          <div className="mt-auto pt-4 border-t border-neutral-200">
            <div className="mb-3">
              <p className="text-sm font-medium">{user?.username || 'User'}</p>
              <p className="text-xs text-neutral-500 capitalize">{userRole}</p>
            </div>
            <button
              onClick={() => logoutMutation.mutate()}
              className="flex items-center w-full px-2 py-2 text-sm font-medium rounded-md text-neutral-700 hover:bg-neutral-100"
            >
              <LogOut className="mr-3 h-4 w-4" />
              Sign Out
            </button>
          </div>
        </div>
      </nav>
    </aside>
  );
}
