import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Bell, 
  HelpCircle, 
  LogOut, 
  Menu, 
  Settings, 
  User as UserIcon
} from "lucide-react";
import { User } from "@shared/schema";

interface HeaderProps {
  onToggleSidebar: () => void;
}

export function Header({ onToggleSidebar }: HeaderProps) {
  const { user, logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const getInitials = () => {
    if (!user) return "U";
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <button 
              className="mr-4 md:hidden text-neutral-500"
              onClick={onToggleSidebar}
            >
              <Menu className="h-6 w-6" />
            </button>
            <Link href="/" className="flex items-center">
              <div className="h-10 w-10 rounded-md bg-primary flex items-center justify-center text-white font-bold">
                MB
              </div>
              <span className="ml-2 text-xl font-semibold text-neutral-900">MentorBox</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/help-center">
              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                <HelpCircle className="h-5 w-5" />
                <span className="hidden md:block">Help</span>
              </Button>
            </Link>
            <Link href="/contact-us">
              <Button variant="ghost" size="sm" className="hidden md:flex items-center gap-1">
                <span>Contact</span>
              </Button>
            </Link>
            {user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative rounded-full p-0">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline ml-2 text-sm font-medium">
                      {user.name || user.username}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end">
                  <div className="flex flex-col space-y-1 p-2">
                    <p className="text-sm font-medium text-foreground">
                      {user.name || user.username}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {user.email || user.username}
                    </p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {user.role} Account
                    </p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center cursor-pointer w-full">
                      <UserIcon className="mr-2 h-4 w-4" />
                      <span>My Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings" className="flex items-center cursor-pointer w-full">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  {user.role === 'admin' && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard" className="flex items-center cursor-pointer w-full">
                        <span>Admin Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  {user.role === 'instructor' && (
                    <DropdownMenuItem asChild>
                      <Link href="/instructor/dashboard" className="flex items-center cursor-pointer w-full">
                        <span>Instructor Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={handleLogout} 
                    className="flex items-center cursor-pointer"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
