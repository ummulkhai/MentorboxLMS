import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import CoursePage from "@/pages/course-page";
import AdminDashboard from "@/pages/admin-dashboard";
import NotAuthorized from "@/pages/not-authorized";
import RoleSwitcher from "@/pages/role-switcher";
import Profile from "@/pages/profile";
import Settings from "@/pages/settings";
import HelpCenter from "@/pages/help-center";
import ContactUs from "@/pages/contact-us";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { AdminRoute } from "@/lib/admin-route";
import { InstructorRoute } from "@/lib/instructor-route";
import { StudentRoute } from "@/lib/student-route";
import RoleBasedRedirect from "./pages/role-based-redirect";

// Student pages
import StudentDashboardPage from "@/pages/student/dashboard-page";
import CoursesPage from "@/pages/student/courses-page";
import VideoLessonsPage from "@/pages/student/video-lessons-page";
import SelfLearningPage from "@/pages/student/self-learning-page";
import ResourcesPage from "@/pages/student/resources-page";
import BookmarksPage from "@/pages/student/bookmarks-page";
import SchedulePage from "@/pages/student/schedule-page";
import SettingsPage from "@/pages/student/settings-page";
import QuizzesPage from "@/pages/student/quizzes-page";
import TakeQuizPage from "@/pages/student/take-quiz-page";
import QuizResultsPage from "@/pages/student/quiz-results-page";

// Instructor pages
import InstructorDashboard from "@/pages/instructor/dashboard-page";
import InstructorCoursesPage from "@/pages/instructor/courses-page";
import InstructorMaterialsPage from "@/pages/instructor/materials-page";
import InstructorStudentsPage from "@/pages/instructor/students-page";
import InstructorQuizzesPage from "@/pages/instructor/quizzes-page";
import CreateEditQuizPage from "@/pages/instructor/create-edit-quiz-page";
import QuizReportsPage from "@/pages/instructor/quiz-reports-page";

function Router() {
  return (
    <Switch>
      <Route path="/" component={RoleBasedRedirect} />
      
      <ProtectedRoute path="/course/:id" component={CoursePage} />
      
      {/* Admin routes */}
      <AdminRoute path="/admin" component={AdminDashboard} />
      <AdminRoute path="/admin/dashboard" component={AdminDashboard} />
      <AdminRoute path="/admin/users" component={AdminDashboard} />
      <AdminRoute path="/admin/courses" component={AdminDashboard} />
      <AdminRoute path="/admin/enrollments" component={AdminDashboard} />
      
      {/* Instructor routes */}
      <InstructorRoute path="/instructor" component={InstructorDashboard} />
      <InstructorRoute path="/instructor/dashboard" component={InstructorDashboard} />
      <InstructorRoute path="/instructor/courses" component={InstructorCoursesPage} />
      <InstructorRoute path="/instructor/materials" component={InstructorMaterialsPage} />
      <InstructorRoute path="/instructor/students" component={InstructorStudentsPage} />
      <InstructorRoute path="/instructor/quizzes" component={InstructorQuizzesPage} />
      <InstructorRoute path="/instructor/quizzes/create" component={CreateEditQuizPage} />
      <InstructorRoute path="/instructor/quizzes/edit/:id" component={CreateEditQuizPage} />
      <InstructorRoute path="/instructor/quizzes/reports/:id" component={QuizReportsPage} />
      
      {/* Student routes */}
      <StudentRoute path="/student" component={StudentDashboardPage} />
      <StudentRoute path="/student/dashboard" component={StudentDashboardPage} />
      <StudentRoute path="/student/courses" component={CoursesPage} />
      <StudentRoute path="/student/video-lessons" component={VideoLessonsPage} />
      <StudentRoute path="/student/resources" component={ResourcesPage} />
      <StudentRoute path="/student/self-learning" component={SelfLearningPage} />
      <StudentRoute path="/student/bookmarks" component={BookmarksPage} />
      <StudentRoute path="/student/schedule" component={SchedulePage} />
      <StudentRoute path="/student/settings" component={SettingsPage} />
      <StudentRoute path="/student/quizzes" component={QuizzesPage} />
      <StudentRoute path="/student/quizzes/:id" component={TakeQuizPage} />
      <StudentRoute path="/student/quiz-results/:id" component={QuizResultsPage} />
      
      {/* Aliases for old routes - redirecting to student path versions */}
      <ProtectedRoute path="/my-courses" component={() => <Redirect to="/student/courses" />} />
      <ProtectedRoute path="/self-learning" component={() => <Redirect to="/student/self-learning" />} />
      <ProtectedRoute path="/video-lessons" component={() => <Redirect to="/student/video-lessons" />} />
      <ProtectedRoute path="/resources" component={() => <Redirect to="/student/resources" />} />
      <ProtectedRoute path="/bookmarks" component={() => <Redirect to="/student/bookmarks" />} />
      
      {/* Auth route */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Not Authorized route */}
      <Route path="/not-authorized" component={NotAuthorized} />
      
      {/* Role Switcher (Demo) */}
      <ProtectedRoute path="/role-switcher" component={RoleSwitcher} />
      
      {/* Shared routes */}
      <ProtectedRoute path="/profile" component={Profile} />
      <ProtectedRoute path="/settings" component={Settings} />
      <Route path="/help-center" component={HelpCenter} />
      <Route path="/contact-us" component={ContactUs} />
      
      {/* 404 route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
