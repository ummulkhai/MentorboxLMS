import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ShieldAlert, ArrowLeft, Lock } from "lucide-react";

export default function NotAuthorized() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <div className="max-w-md w-full mx-auto p-8 text-center">
        <div className="mb-6 flex justify-center">
          <div className="p-4 bg-destructive/10 rounded-full">
            <ShieldAlert className="h-12 w-12 text-destructive" />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold tracking-tighter mb-3">Access Denied</h1>
        <p className="text-muted-foreground mb-6">
          You don't have permission to access this page. This area is restricted to users with 
          different role permissions.
        </p>
        
        <div className="p-4 bg-muted rounded-lg mb-6">
          <div className="flex items-center mb-2">
            <Lock className="h-4 w-4 mr-2 text-muted-foreground" />
            <h3 className="text-sm font-medium">Why am I seeing this?</h3>
          </div>
          <p className="text-sm text-muted-foreground text-left">
            Mentorbox LMS has different areas for students, instructors, and administrators. 
            Your current role doesn't have permission to view this content.
          </p>
        </div>
        
        <Link href="/">
          <Button className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Return to Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}