import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Loader2, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  ArrowLeft, 
  Save, 
  Copy
} from "lucide-react";
import { AppLayout as Layout } from "@/layout/app-layout";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertQuizSchema, insertQuizQuestionSchema, Quiz, QuizQuestion } from "@shared/schema";

// Extended schema for validation
const createQuizSchema = insertQuizSchema.extend({
  title: z.string().min(1, "Title is required"),
  courseId: z.number({
    required_error: "Course is required",
    invalid_type_error: "Please select a course"
  }),
  passingScore: z.number({
    required_error: "Passing score is required",
    invalid_type_error: "Please enter a valid number"
  }).min(0).max(100),
});

type CreateQuizFormValues = z.infer<typeof createQuizSchema>;

// Schema for quiz questions
const createQuestionSchema = z.object({
  questionText: z.string().min(1, "Question text is required"),
  questionType: z.enum(["multiple_choice", "true_false", "short_answer", "essay", "matching"], {
    required_error: "Question type is required"
  }),
  points: z.number({
    required_error: "Points are required",
    invalid_type_error: "Please enter a valid number"
  }).min(1),
  correctAnswer: z.any().optional(),
  options: z.any().optional(),
  explanation: z.string().optional(),
});

type CreateQuestionFormValues = z.infer<typeof createQuestionSchema>;

export default function CreateEditQuizPage() {
  const { id } = useParams();
  const isEditMode = !!id;
  const quizId = isEditMode ? parseInt(id) : undefined;
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("details");
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<CreateQuestionFormValues | null>(null);
  const [isEditingQuestion, setIsEditingQuestion] = useState(false);
  const [editingQuestionIndex, setEditingQuestionIndex] = useState<number | null>(null);
  
  // Fetch quiz details if in edit mode
  const { data: quiz, isLoading: isLoadingQuiz } = useQuery<Quiz>({
    queryKey: [`/api/quizzes/${quizId}`],
    enabled: isEditMode && !!quizId && !!user
  });
  
  // Fetch quiz questions if in edit mode
  const { data: existingQuestions, isLoading: isLoadingQuestions } = useQuery<QuizQuestion[]>({
    queryKey: [`/api/quizzes/${quizId}/questions`],
    enabled: isEditMode && !!quizId && !!user,
    onSuccess: (data) => {
      setQuestions(data || []);
    }
  });
  
  // Fetch all courses
  const { data: courses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ["/api/courses"],
    enabled: !!user
  });
  
  // Create a new quiz
  const createQuizMutation = useMutation({
    mutationFn: async (data: CreateQuizFormValues) => {
      const res = await apiRequest("POST", "/api/quizzes", data);
      return await res.json() as Quiz;
    },
    onSuccess: (quiz) => {
      toast({
        title: "Quiz created",
        description: "Your quiz has been created successfully."
      });
      
      // Now add questions if any
      if (questions.length > 0) {
        addQuestionsToQuiz(quiz.id);
      } else {
        navigate("/instructor/quizzes");
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to create quiz",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  });
  
  // Update an existing quiz
  const updateQuizMutation = useMutation({
    mutationFn: async (data: CreateQuizFormValues) => {
      const res = await apiRequest("PATCH", `/api/quizzes/${quizId}`, data);
      return await res.json() as Quiz;
    },
    onSuccess: () => {
      toast({
        title: "Quiz updated",
        description: "Your quiz has been updated successfully."
      });
      queryClient.invalidateQueries({ queryKey: [`/api/quizzes/${quizId}`] });
      navigate("/instructor/quizzes");
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update quiz",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  });
  
  // Add a question to the quiz
  const addQuestionMutation = useMutation({
    mutationFn: async ({ quizId, questionData }: { quizId: number, questionData: any }) => {
      const res = await apiRequest("POST", `/api/quizzes/${quizId}/questions`, questionData);
      return await res.json() as QuizQuestion;
    }
  });
  
  // Update a question
  const updateQuestionMutation = useMutation({
    mutationFn: async ({ questionId, questionData }: { questionId: number, questionData: any }) => {
      const res = await apiRequest("PATCH", `/api/quiz-questions/${questionId}`, questionData);
      return await res.json() as QuizQuestion;
    }
  });
  
  // Form for creating/editing a quiz
  const form = useForm<CreateQuizFormValues>({
    resolver: zodResolver(createQuizSchema),
    defaultValues: {
      title: "",
      description: "",
      courseId: 0,
      moduleId: null,
      passingScore: 70,
      attemptsAllowed: null,
      timeLimit: null,
      dueDate: null
    }
  });
  
  // Form for creating/editing a question
  const questionForm = useForm<CreateQuestionFormValues>({
    resolver: zodResolver(createQuestionSchema),
    defaultValues: {
      questionText: "",
      questionType: "multiple_choice",
      points: 1,
      options: ["", "", "", ""],
      correctAnswer: ""
    }
  });
  
  // Set form values when quiz data is loaded
  useEffect(() => {
    if (quiz) {
      form.reset({
        title: quiz.title,
        description: quiz.description || "",
        courseId: quiz.courseId,
        moduleId: quiz.moduleId,
        passingScore: quiz.passingScore,
        attemptsAllowed: quiz.attemptsAllowed,
        timeLimit: quiz.timeLimit,
        dueDate: quiz.dueDate ? new Date(quiz.dueDate) : null
      });
    }
  }, [quiz, form]);
  
  const handleQuizSubmit = (data: CreateQuizFormValues) => {
    if (isEditMode && quizId) {
      updateQuizMutation.mutate(data);
    } else {
      createQuizMutation.mutate(data);
    }
  };
  
  const addQuestionsToQuiz = async (quizId: number) => {
    // Add questions one by one
    try {
      for (const question of questions) {
        const questionData = {
          ...question,
          quizId
        };
        
        delete questionData.id; // Remove id when creating a new question
        
        await addQuestionMutation.mutateAsync({ quizId, questionData });
      }
      
      toast({
        title: "Questions added",
        description: `${questions.length} questions have been added to the quiz.`
      });
      
      navigate("/instructor/quizzes");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to add questions",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  };
  
  const handleQuestionSubmit = (data: CreateQuestionFormValues) => {
    let processedData = { ...data };
    
    // Format correct answer based on question type
    if (data.questionType === "multiple_choice") {
      processedData.correctAnswer = data.correctAnswer;
    } else if (data.questionType === "true_false") {
      processedData.correctAnswer = data.correctAnswer === "true";
    }
    
    if (isEditingQuestion && editingQuestionIndex !== null) {
      // Update existing question
      const updatedQuestions = [...questions];
      updatedQuestions[editingQuestionIndex] = {
        ...updatedQuestions[editingQuestionIndex],
        ...processedData
      };
      setQuestions(updatedQuestions);
      
      // If in edit mode, update the question on the server
      if (isEditMode && updatedQuestions[editingQuestionIndex].id) {
        updateQuestionMutation.mutate({
          questionId: updatedQuestions[editingQuestionIndex].id,
          questionData: processedData
        });
      }
    } else {
      // Add new question
      setQuestions([...questions, { 
        ...processedData, 
        id: Math.floor(Math.random() * -1000), // Temporary negative ID for new questions
        quizId: quizId || 0,
        order: questions.length + 1
      } as QuizQuestion]);
    }
    
    // Reset form and state
    questionForm.reset({
      questionText: "",
      questionType: "multiple_choice",
      points: 1,
      options: ["", "", "", ""],
      correctAnswer: ""
    });
    setIsEditingQuestion(false);
    setEditingQuestionIndex(null);
    setCurrentQuestion(null);
  };
  
  const handleEditQuestion = (index: number) => {
    const question = questions[index];
    setCurrentQuestion(question);
    setIsEditingQuestion(true);
    setEditingQuestionIndex(index);
    
    questionForm.reset({
      questionText: question.questionText,
      questionType: question.questionType,
      points: question.points,
      options: question.options || ["", "", "", ""],
      correctAnswer: question.correctAnswer,
      explanation: question.explanation || ""
    });
  };
  
  const handleDeleteQuestion = (index: number) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    
    // Update order of remaining questions
    updatedQuestions.forEach((q, i) => {
      q.order = i + 1;
    });
    
    setQuestions(updatedQuestions);
  };
  
  const handleDuplicateQuestion = (index: number) => {
    const questionToDuplicate = questions[index];
    
    setQuestions([
      ...questions, 
      { 
        ...questionToDuplicate,
        id: Math.floor(Math.random() * -1000), // Temporary negative ID
        order: questions.length + 1
      }
    ]);
  };
  
  const isLoading = isLoadingQuiz || isLoadingQuestions || isLoadingCourses;
  const isSubmitting = createQuizMutation.isPending || updateQuizMutation.isPending;
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
              <h2 className="text-xl font-semibold">Loading...</h2>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto py-6 max-w-4xl">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={() => navigate("/instructor/quizzes")} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">{isEditMode ? "Edit Quiz" : "Create Quiz"}</h1>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="details">Quiz Details</TabsTrigger>
            <TabsTrigger value="questions">Questions</TabsTrigger>
          </TabsList>
          
          <TabsContent value="details">
            <Card>
              <CardHeader>
                <CardTitle>Quiz Information</CardTitle>
                <CardDescription>
                  Set up the basic information for your quiz
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form className="space-y-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quiz Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter quiz title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter quiz description" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="courseId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Course</FormLabel>
                            <Select 
                              value={field.value.toString()} 
                              onValueChange={(value) => field.onChange(parseInt(value))}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a course" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {courses?.map((course) => (
                                  <SelectItem key={course.id} value={course.id.toString()}>
                                    {course.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="moduleId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Module (Optional)</FormLabel>
                            <Select 
                              value={field.value?.toString() || ""} 
                              onValueChange={(value) => field.onChange(value ? parseInt(value) : null)}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a module" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="">None</SelectItem>
                                {/* We would add modules here based on selected course */}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="passingScore"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Passing Score (%)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0" 
                                max="100" 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="timeLimit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Time Limit (minutes)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0"
                                placeholder="No limit"
                                {...field}
                                value={field.value || ""}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  field.onChange(value ? parseInt(value) : null);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="attemptsAllowed"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Attempts Allowed</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0"
                                placeholder="Unlimited"
                                {...field}
                                value={field.value || ""}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  field.onChange(value ? parseInt(value) : null);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Due Date (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              type="datetime-local" 
                              {...field}
                              value={field.value ? new Date(field.value).toISOString().slice(0, 16) : ""}
                              onChange={(e) => {
                                const value = e.target.value;
                                field.onChange(value ? new Date(value) : null);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </form>
                </Form>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => navigate("/instructor/quizzes")}>
                  Cancel
                </Button>
                <Button onClick={() => setActiveTab("questions")} disabled={!form.formState.isValid}>
                  Continue to Questions
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="questions">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Quiz Questions</CardTitle>
                <CardDescription>
                  {questions.length > 0 
                    ? `${questions.length} question${questions.length > 1 ? 's' : ''} added to this quiz` 
                    : "Add questions to your quiz"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {questions.length === 0 ? (
                  <div className="bg-muted rounded-lg p-6 text-center">
                    <p className="text-muted-foreground mb-4">
                      No questions added yet. Add your first question below.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={index} className="relative overflow-hidden">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between">
                            <CardTitle className="text-base">Question {index + 1}</CardTitle>
                            <Badge>
                              {question.questionType === "multiple_choice" ? "Multiple Choice" : 
                               question.questionType === "true_false" ? "True/False" :
                               question.questionType === "short_answer" ? "Short Answer" :
                               question.questionType === "essay" ? "Essay" : "Matching"}
                               {" • "}{question.points} {question.points === 1 ? "point" : "points"}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <p className="font-medium mb-2">{question.questionText}</p>
                          
                          {question.questionType === "multiple_choice" && Array.isArray(question.options) && (
                            <div className="ml-4 space-y-1">
                              {question.options.map((option, i) => (
                                <div key={i} className="flex items-center gap-2">
                                  <div className={`w-4 h-4 rounded-full border ${
                                    question.correctAnswer === option 
                                      ? "bg-primary border-primary" 
                                      : "border-muted-foreground"
                                  }`}></div>
                                  <span>{option}</span>
                                </div>
                              ))}
                            </div>
                          )}
                          
                          {question.questionType === "true_false" && (
                            <div className="ml-4 space-y-1">
                              <div className="flex items-center gap-2">
                                <div className={`w-4 h-4 rounded-full border ${
                                  question.correctAnswer === true 
                                    ? "bg-primary border-primary" 
                                    : "border-muted-foreground"
                                }`}></div>
                                <span>True</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <div className={`w-4 h-4 rounded-full border ${
                                  question.correctAnswer === false 
                                    ? "bg-primary border-primary" 
                                    : "border-muted-foreground"
                                }`}></div>
                                <span>False</span>
                              </div>
                            </div>
                          )}
                          
                          {(question.questionType === "short_answer" || question.questionType === "essay") && (
                            <div className="ml-4">
                              <p className="text-sm text-muted-foreground">
                                Correct Answer: {question.correctAnswer ? String(question.correctAnswer) : "Manual grading required"}
                              </p>
                            </div>
                          )}
                        </CardContent>
                        <CardFooter className="flex justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDuplicateQuestion(index)}
                            title="Duplicate"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleEditQuestion(index)}
                            title="Edit"
                          >
                            <PenSquare className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleDeleteQuestion(index)}
                            className="text-destructive hover:text-destructive"
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
                
                <Separator className="my-6" />
                
                {currentQuestion === null ? (
                  <Button onClick={() => setCurrentQuestion({} as CreateQuestionFormValues)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Question
                  </Button>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>{isEditingQuestion ? "Edit Question" : "Add Question"}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Form {...questionForm}>
                        <form className="space-y-6">
                          <FormField
                            control={questionForm.control}
                            name="questionText"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Question Text</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Enter your question" 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={questionForm.control}
                              name="questionType"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Question Type</FormLabel>
                                  <Select 
                                    value={field.value} 
                                    onValueChange={(value: any) => {
                                      field.onChange(value);
                                      
                                      // Reset options based on question type
                                      if (value === "multiple_choice") {
                                        questionForm.setValue("options", ["", "", "", ""]);
                                        questionForm.setValue("correctAnswer", "");
                                      } else if (value === "true_false") {
                                        questionForm.setValue("options", null);
                                        questionForm.setValue("correctAnswer", "true");
                                      } else {
                                        questionForm.setValue("options", null);
                                        questionForm.setValue("correctAnswer", "");
                                      }
                                    }}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select question type" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                                      <SelectItem value="true_false">True/False</SelectItem>
                                      <SelectItem value="short_answer">Short Answer</SelectItem>
                                      <SelectItem value="essay">Essay</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={questionForm.control}
                              name="points"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Points</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="number" 
                                      min="1"
                                      {...field}
                                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          {questionForm.watch("questionType") === "multiple_choice" && (
                            <div className="space-y-4">
                              <FormLabel>Answer Options</FormLabel>
                              
                              {questionForm.watch("options")?.map((_, index) => (
                                <div key={index} className="flex gap-2 items-center">
                                  <Input 
                                    placeholder={`Option ${index + 1}`}
                                    value={questionForm.watch(`options.${index}`) || ""}
                                    onChange={(e) => {
                                      const newOptions = [...(questionForm.watch("options") || [])];
                                      newOptions[index] = e.target.value;
                                      questionForm.setValue("options", newOptions);
                                    }}
                                  />
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      const newOptions = [...(questionForm.watch("options") || [])];
                                      newOptions.splice(index, 1);
                                      questionForm.setValue("options", newOptions);
                                    }}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                              
                              <Button
                                type="button"
                                variant="outline"
                                onClick={() => {
                                  const newOptions = [...(questionForm.watch("options") || []), ""];
                                  questionForm.setValue("options", newOptions);
                                }}
                              >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Option
                              </Button>
                              
                              <FormField
                                control={questionForm.control}
                                name="correctAnswer"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Correct Answer</FormLabel>
                                    <Select 
                                      value={field.value} 
                                      onValueChange={field.onChange}
                                    >
                                      <FormControl>
                                        <SelectTrigger>
                                          <SelectValue placeholder="Select correct answer" />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        {questionForm.watch("options")?.map((option, index) => (
                                          <SelectItem key={index} value={option}>
                                            {option || `Option ${index + 1}`}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          )}
                          
                          {questionForm.watch("questionType") === "true_false" && (
                            <FormField
                              control={questionForm.control}
                              name="correctAnswer"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Correct Answer</FormLabel>
                                  <Select 
                                    value={field.value} 
                                    onValueChange={field.onChange}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select correct answer" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="true">True</SelectItem>
                                      <SelectItem value="false">False</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          {(questionForm.watch("questionType") === "short_answer") && (
                            <FormField
                              control={questionForm.control}
                              name="correctAnswer"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Answer Key</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Enter the correct answer" 
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormDescription>
                                    Enter the expected answer for auto-grading
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          {(questionForm.watch("questionType") === "essay") && (
                            <FormField
                              control={questionForm.control}
                              name="correctAnswer"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Grading Guidelines</FormLabel>
                                  <FormControl>
                                    <Textarea 
                                      placeholder="Enter grading guidelines or a model answer" 
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormDescription>
                                    This is only visible to instructors and will help with manual grading.
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          <FormField
                            control={questionForm.control}
                            name="explanation"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Explanation (Optional)</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Explanation of the correct answer" 
                                    {...field} 
                                    value={field.value || ""}
                                  />
                                </FormControl>
                                <FormDescription>
                                  This will be shown to students after they complete the quiz.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </form>
                      </Form>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setCurrentQuestion(null);
                          setIsEditingQuestion(false);
                          setEditingQuestionIndex(null);
                          questionForm.reset();
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => {
                          questionForm.handleSubmit(handleQuestionSubmit)();
                        }}
                      >
                        {isEditingQuestion ? "Update Question" : "Add Question"}
                      </Button>
                    </CardFooter>
                  </Card>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveTab("details")}>
                  Back to Details
                </Button>
                <Button 
                  onClick={() => form.handleSubmit(handleQuizSubmit)()}
                  disabled={questions.length === 0 || isSubmitting}
                >
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isEditMode ? "Update Quiz" : "Create Quiz"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}