import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/layout/app-layout";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Loader2, Plus, FileText, Users, CalendarDays } from "lucide-react";
import { Course } from "@shared/schema";

export default function InstructorCoursesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Query to fetch all courses for this instructor
  const { 
    data: courses = [], 
    isLoading, 
    error 
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });
  
  // Show error if courses couldn't be loaded
  if (error) {
    toast({
      title: "Error",
      description: "Failed to load courses. Please try again later.",
      variant: "destructive",
    });
  }
  
  return (
    <AppLayout>
      <div className="container mx-auto py-6 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">My Courses</h1>
            <p className="text-muted-foreground">
              Manage and monitor all your instructional courses
            </p>
          </div>
          <Button asChild>
            <Link href="/instructor">
              <Plus className="mr-2 h-4 w-4" /> Create Course
            </Link>
          </Button>
        </div>
        
        <Separator className="my-6" />
        
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : courses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Card key={course.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl">{course.title}</CardTitle>
                  <Badge variant="secondary" className="w-fit mt-2">
                    {course.type}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {course.description}
                  </p>
                  
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CalendarDays className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>
                        {new Date(course.startDate).toLocaleDateString()} - 
                        {new Date(course.endDate).toLocaleDateString()}
                      </span>
                    </div>
                    
                    <div className="flex items-center text-sm">
                      <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>10 Modules</span> {/* Would be dynamically populated in a real app */}
                    </div>
                    
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>12 Students Enrolled</span> {/* Would be dynamically populated in a real app */}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="border-t pt-4 flex justify-between">
                  <Button variant="outline" size="sm">View Details</Button>
                  <Button variant="secondary" size="sm">
                    <Link href="/instructor">Manage Content</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border border-dashed rounded-lg">
            <div className="mb-4">
              <FileText className="h-10 w-10 mx-auto text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No courses yet</h3>
            <p className="text-muted-foreground mb-4">
              You haven't created any courses yet. Get started by creating your first course.
            </p>
            <Button asChild>
              <Link href="/instructor">
                <Plus className="mr-2 h-4 w-4" /> Create Your First Course
              </Link>
            </Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}