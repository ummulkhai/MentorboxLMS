import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Loader2, AlertTriangle, ArrowLeft, UserRound, FileText, BarChart } from "lucide-react";
import { AppLayout as Layout } from "@/layout/app-layout";
import { formatDate } from "@/lib/utils";
import { Quiz, QuizAttempt } from "@shared/schema";

export default function QuizReportsPage() {
  const { id } = useParams();
  const quizId = parseInt(id);
  const [, navigate] = useLocation();
  const { user } = useAuth();
  
  // Fetch quiz details
  const { data: quiz, isLoading: isLoadingQuiz } = useQuery<Quiz>({
    queryKey: [`/api/quizzes/${quizId}`],
    enabled: !!quizId && !!user
  });
  
  // Fetch all attempts for this quiz
  const { data: attempts, isLoading: isLoadingAttempts } = useQuery<QuizAttempt[]>({
    queryKey: [`/api/quizzes/${quizId}/attempts`],
    enabled: !!quizId && !!user
  });
  
  // Fetch all users who have taken this quiz
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
    enabled: !!user && user.role !== "student"
  });
  
  const isLoading = isLoadingQuiz || isLoadingAttempts || isLoadingUsers;
  
  // Calculate statistics
  const stats = {
    totalAttempts: attempts?.length || 0,
    uniqueStudents: new Set(attempts?.map(a => a.userId)).size || 0,
    averageScore: attempts?.length 
      ? Math.round(attempts.reduce((sum, a) => sum + parseFloat(a.score || "0"), 0) / attempts.length) 
      : 0,
    passRate: attempts?.length
      ? Math.round((attempts.filter(a => a.passed).length / attempts.length) * 100)
      : 0
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
              <h2 className="text-xl font-semibold">Loading Reports...</h2>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  if (!quiz) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Unable to load quiz report. The quiz may not exist.
            </AlertDescription>
          </Alert>
          <div className="mt-4">
            <Button onClick={() => navigate("/instructor/quizzes")}>
              Back to Quizzes
            </Button>
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto py-6 max-w-5xl">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={() => navigate("/instructor/quizzes")} className="mr-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Quiz Report</h1>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">{quiz.title}</CardTitle>
            <CardDescription>
              {quiz.description || 'No description'} • Course: {quiz.courseId}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardDescription>Total Attempts</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold flex items-center">
                    <FileText className="mr-2 h-5 w-5 text-muted-foreground" />
                    {stats.totalAttempts}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardDescription>Unique Students</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold flex items-center">
                    <UserRound className="mr-2 h-5 w-5 text-muted-foreground" />
                    {stats.uniqueStudents}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardDescription>Average Score</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold flex items-center">
                    <BarChart className="mr-2 h-5 w-5 text-muted-foreground" />
                    {stats.averageScore}%
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardDescription>Pass Rate</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold flex items-center">
                    <BarChart className="mr-2 h-5 w-5 text-muted-foreground" />
                    {stats.passRate}%
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h3 className="text-lg font-semibold mb-4">Student Attempts</h3>
            
            {!attempts || attempts.length === 0 ? (
              <div className="bg-muted rounded-lg p-6 text-center">
                <p className="text-muted-foreground">
                  No attempts have been made on this quiz yet.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Attempt #</TableHead>
                      <TableHead>Completed</TableHead>
                      <TableHead>Time Spent</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attempts.map((attempt) => {
                      const student = users?.find(u => u.id === attempt.userId);
                      
                      return (
                        <TableRow key={attempt.id}>
                          <TableCell className="font-medium">
                            {student?.username || `User ID: ${attempt.userId}`}
                          </TableCell>
                          <TableCell>#{attempt.attemptNumber}</TableCell>
                          <TableCell>
                            {attempt.completedAt 
                              ? formatDate(attempt.completedAt) 
                              : <span className="text-muted-foreground italic">In progress</span>}
                          </TableCell>
                          <TableCell>
                            {attempt.timeSpent 
                              ? `${Math.floor(attempt.timeSpent / 60)}:${(attempt.timeSpent % 60).toString().padStart(2, '0')}` 
                              : '-'}
                          </TableCell>
                          <TableCell>
                            {attempt.score ? `${attempt.score}%` : '-'}
                          </TableCell>
                          <TableCell>
                            {attempt.completedAt ? (
                              <Badge variant={attempt.passed ? "default" : "destructive"}>
                                {attempt.passed ? "Passed" : "Failed"}
                              </Badge>
                            ) : (
                              <Badge variant="outline">Not Submitted</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {attempt.completedAt && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => navigate(`/instructor/quizzes/attempts/${attempt.id}`)}
                              >
                                Review
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}