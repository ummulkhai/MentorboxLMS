import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, Plus, PenSquare, BarChart2, Trash2 } from "lucide-react";
import { AppLayout as Layout } from "@/layout/app-layout";
import { formatDate } from "@/lib/utils";
import { Quiz } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function InstructorQuizzesPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch all quizzes
  const { data: quizzes, isLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
    enabled: !!user
  });
  
  // Fetch the instructor's courses
  const { data: courses } = useQuery({
    queryKey: ["/api/courses"],
    enabled: !!user
  });
  
  // Organize quizzes by course
  const quizzesByCourse = quizzes?.reduce((acc, quiz) => {
    if (!acc[quiz.courseId]) {
      acc[quiz.courseId] = [];
    }
    acc[quiz.courseId].push(quiz);
    return acc;
  }, {} as Record<number, Quiz[]>);
  
  const handleDeleteQuiz = async (quizId: number) => {
    // This is just a placeholder for now, as we don't have a delete endpoint yet
    try {
      await apiRequest("DELETE", `/api/quizzes/${quizId}`);
      
      toast({
        title: "Quiz deleted",
        description: "The quiz has been deleted successfully."
      });
      
      // Invalidate quizzes query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to delete quiz",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">Quizzes & Assessments</h1>
          <Button asChild>
            <Link to="/instructor/quizzes/create">
              <Plus className="mr-2 h-4 w-4" />
              Create Quiz
            </Link>
          </Button>
        </div>
        
        {!quizzes || quizzes.length === 0 ? (
          <div className="bg-muted rounded-lg p-8 text-center">
            <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No quizzes yet</h3>
            <p className="text-muted-foreground mb-6">
              Create your first quiz to assess your students' knowledge.
            </p>
            <Button asChild>
              <Link to="/instructor/quizzes/create">
                <Plus className="mr-2 h-4 w-4" />
                Create Quiz
              </Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.entries(quizzesByCourse || {}).map(([courseId, quizzes]) => {
              const course = courses?.find(c => c.id === parseInt(courseId));
              
              return (
                <div key={courseId}>
                  <h2 className="text-xl font-semibold mb-4">{course?.title || 'Unknown Course'}</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {quizzes.map((quiz) => (
                      <Card key={quiz.id} className="overflow-hidden">
                        <CardHeader className="pb-3">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-xl">{quiz.title}</CardTitle>
                            <Badge variant={getDueDateStatus(quiz.dueDate)}>
                              {getDueDateLabel(quiz.dueDate)}
                            </Badge>
                          </div>
                          <CardDescription>
                            {quiz.description || 'No description'}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <span>Passing: {quiz.passingScore}%</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <span>Time: {quiz.timeLimit ? `${quiz.timeLimit} min` : 'No limit'}</span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <span>Attempts: {quiz.attemptsAllowed || 'Unlimited'}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <span>Created: {formatDate(quiz.createdAt)}</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="grid grid-cols-3 gap-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/instructor/quizzes/edit/${quiz.id}`}>
                              <PenSquare className="h-4 w-4 mr-1" />
                              Edit
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/instructor/quizzes/reports/${quiz.id}`}>
                              <BarChart2 className="h-4 w-4 mr-1" />
                              Reports
                            </Link>
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDeleteQuiz(quiz.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}

function getDueDateStatus(dueDate: Date | null): 'default' | 'secondary' | 'destructive' {
  if (!dueDate) return 'secondary';
  
  const now = new Date();
  const due = new Date(dueDate);
  
  // If past due date
  if (now > due) return 'destructive';
  
  // If due in less than 2 days
  const twoDaysFromNow = new Date();
  twoDaysFromNow.setDate(now.getDate() + 2);
  if (due < twoDaysFromNow) return 'default';
  
  return 'secondary';
}

function getDueDateLabel(dueDate: Date | null): string {
  if (!dueDate) return 'No Due Date';
  
  const now = new Date();
  const due = new Date(dueDate);
  
  // If past due date
  if (now > due) return 'Past Due';
  
  // Get days difference
  const diffTime = Math.abs(due.getTime() - now.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'Due Today';
  if (diffDays === 1) return 'Due Tomorrow';
  
  return `Due in ${diffDays} days`;
}