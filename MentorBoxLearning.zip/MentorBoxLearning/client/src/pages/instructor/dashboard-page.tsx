import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AppLayout } from "@/layout/app-layout";
import { CourseForm } from "@/components/admin/course-form";
import { ModuleForm } from "@/components/admin/module-form";
import { MaterialUploadForm } from "@/components/admin/material-upload-form";
import { Loader2, PlusCircle, Calendar, FolderPlus, Upload, Users } from "lucide-react";
import { Course } from "@shared/schema";

export default function InstructorDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("courses");
  
  // Query to fetch all courses for this instructor
  const { 
    data: courses = [] as Course[], 
    isLoading: isLoadingCourses,
    error: coursesError
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });
  
  // Function to handle error toasts
  const handleError = (message: string) => {
    toast({
      title: "Error",
      description: message,
      variant: "destructive",
    });
  };
  
  // Show error if courses couldn't be loaded
  if (coursesError) {
    handleError("Failed to load courses. Please try again later.");
  }
  
  return (
    <AppLayout>
      <div className="container mx-auto py-6 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Instructor Dashboard</h1>
            <p className="text-muted-foreground">
              Manage courses, modules, and materials for Mentorbox LMS
            </p>
          </div>
          <Badge variant="outline" className="text-sm py-1 px-3">
            {user?.role}
          </Badge>
        </div>
        
        <Separator className="my-6" />
        
        <Tabs
          defaultValue="courses"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 w-full max-w-md mb-8">
            <TabsTrigger value="courses" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>Courses</span>
            </TabsTrigger>
            <TabsTrigger value="modules" className="flex items-center gap-2">
              <FolderPlus className="h-4 w-4" />
              <span>Modules</span>
            </TabsTrigger>
            <TabsTrigger value="materials" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              <span>Materials</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="courses" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="col-span-1 md:col-span-3">
                <h2 className="text-xl font-semibold mb-4">Create New Course</h2>
                <p className="text-muted-foreground mb-6">
                  Add a new course to the 2025 schedule with detailed information.
                </p>
                <CourseForm />
              </div>
              
              <div className="col-span-1 md:col-span-2">
                <h2 className="text-xl font-semibold mb-4">Your Courses</h2>
                {isLoadingCourses ? (
                  <div className="flex items-center justify-center h-48">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : courses.length > 0 ? (
                  <div className="space-y-4">
                    {courses.map((course) => (
                      <div 
                        key={course.id}
                        className="p-4 border rounded-lg hover:border-primary transition-colors"
                      >
                        <h3 className="font-medium">{course.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {new Date(course.startDate).toLocaleDateString()} - {new Date(course.endDate).toLocaleDateString()}
                        </p>
                        <div className="flex justify-between items-center mt-3">
                          <Badge variant="secondary">{course.type}</Badge>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setActiveTab("modules");
                              toast({
                                title: "Course selected",
                                description: `Now create modules for "${course.title}"`,
                              });
                            }}
                          >
                            Add Modules
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8 border border-dashed rounded-lg">
                    <p className="text-muted-foreground">No courses yet</p>
                    <p className="text-sm mt-1">Create your first course to get started</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => setActiveTab("courses")}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add Course
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="modules" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="col-span-1 md:col-span-2">
                <h2 className="text-xl font-semibold mb-4">Create Course Modules</h2>
                <p className="text-muted-foreground mb-6">
                  Add modules to structure your course content.
                </p>
                <ModuleForm 
                  courses={courses} 
                  onModuleCreated={() => {
                    toast({
                      title: "Module created",
                      description: "Now you can add materials to this module.",
                    });
                  }}
                />
              </div>
              
              <div className="col-span-1 md:col-span-3">
                <h2 className="text-xl font-semibold mb-4">Course Structure</h2>
                {isLoadingCourses ? (
                  <div className="flex items-center justify-center h-48">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : courses.length > 0 ? (
                  <div className="space-y-6">
                    {courses.map((course) => (
                      <div key={course.id} className="border rounded-lg p-4">
                        <h3 className="font-medium text-lg">{course.title}</h3>
                        <Separator className="my-3" />
                        
                        {/* Placeholder for modules - In a real app, you'd query and render modules here */}
                        <div className="space-y-2 py-2">
                          <p className="text-sm text-muted-foreground">
                            Select this course in the module form to add modules.
                          </p>
                          
                          {/* This would be replaced with actual module data */}
                          <div className="p-3 bg-secondary/30 rounded-md">
                            <p className="text-sm">Example: Module 1 - Introduction</p>
                          </div>
                          <div className="p-3 bg-secondary/30 rounded-md">
                            <p className="text-sm">Example: Module 2 - Core Concepts</p>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setActiveTab("materials");
                              toast({
                                title: "Course selected",
                                description: `Now add materials to "${course.title}"`,
                              });
                            }}
                          >
                            Add Materials
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8 border border-dashed rounded-lg">
                    <p className="text-muted-foreground">No courses available</p>
                    <p className="text-sm mt-1">Create a course first before adding modules</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => setActiveTab("courses")}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add Course
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="materials" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              <div className="col-span-1 md:col-span-7">
                <h2 className="text-xl font-semibold mb-4">Add Course Materials</h2>
                <p className="text-muted-foreground mb-6">
                  Upload files or embed Google Drive resources for your courses.
                </p>
                <MaterialUploadForm 
                  courses={courses.map((course) => ({
                    ...course,
                    // In a real app, this would be populated with actual module data
                    modules: [
                      { id: 1, title: "Example Module 1" },
                      { id: 2, title: "Example Module 2" },
                    ]
                  }))} 
                />
              </div>
              
              <div className="col-span-1 md:col-span-5">
                <h2 className="text-xl font-semibold mb-4">Material Guidelines</h2>
                <div className="border rounded-lg p-5 space-y-4">
                  <div>
                    <h3 className="font-medium">Google Drive Embedding</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Paste Google Drive share links for videos, documents, or presentations. 
                      The system will automatically convert them to embedded format.
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="font-medium">File Uploads</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Upload PDFs, images, videos, or other documents directly. 
                      Max file size: 50MB.
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="font-medium">Supported Formats</h3>
                    <ul className="text-sm text-muted-foreground mt-1 space-y-1 list-disc list-inside">
                      <li>Documents: PDF, DOCX, TXT</li>
                      <li>Images: JPG, PNG, GIF</li>
                      <li>Videos: MP4, WebM</li>
                      <li>Audio: MP3, WAV</li>
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="font-medium">Best Practices</h3>
                    <ul className="text-sm text-muted-foreground mt-1 space-y-1 list-disc list-inside">
                      <li>Use clear, descriptive titles</li>
                      <li>Organize materials by modules</li>
                      <li>Maintain consistent ordering</li>
                      <li>Ensure material quality and relevance</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}