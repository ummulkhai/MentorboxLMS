import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/layout/app-layout";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  Loader2, 
  Video, 
  FileText, 
  Image, 
  AudioLines, 
  File, 
  ExternalLink,
  MoreHorizontal,
  ArrowUpDown,
  Search,
  Plus
} from "lucide-react";
import { Course, CourseMaterial } from "@shared/schema";
import { MaterialUploadForm } from "@/components/admin/material-upload-form";
import { Input } from "@/components/ui/input";

// Helper function to determine icon based on material type
function getMaterialIcon(type: string) {
  const lowerType = type.toLowerCase();
  if (lowerType.includes('video')) return <Video className="h-5 w-5" />;
  if (lowerType.includes('pdf') || lowerType.includes('document')) return <FileText className="h-5 w-5" />;
  if (lowerType.includes('image')) return <Image className="h-5 w-5" />;
  if (lowerType.includes('audio')) return <AudioLines className="h-5 w-5" />;
  return <File className="h-5 w-5" />;
}

export default function InstructorMaterialsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  // Query to fetch all courses for this instructor
  const { 
    data: courses = [], 
    isLoading: isLoadingCourses 
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });
  
  // Query to fetch materials for selected course
  const {
    data: materials = [],
    isLoading: isLoadingMaterials
  } = useQuery<CourseMaterial[]>({
    queryKey: ["/api/courses", selectedCourseId, "materials"],
    enabled: !!selectedCourseId,
  });
  
  // Filter materials based on search query and active tab
  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab = activeTab === "all" || material.type.toLowerCase().includes(activeTab.toLowerCase());
    return matchesSearch && matchesTab;
  });
  
  return (
    <AppLayout>
      <div className="container mx-auto py-6 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Course Materials</h1>
            <p className="text-muted-foreground">
              Manage learning materials for your courses
            </p>
          </div>
          <Button asChild>
            <Link href="/instructor">
              <Plus className="mr-2 h-4 w-4" /> Upload Material
            </Link>
          </Button>
        </div>
        
        <Separator className="my-6" />
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8">
            <div className="flex flex-col space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="w-full sm:w-1/3">
                  <Select
                    value={selectedCourseId?.toString() || ""}
                    onValueChange={(value) => setSelectedCourseId(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a course" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.id} value={course.id.toString()}>
                          {course.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="relative w-full sm:w-2/3">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search materials..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="video">Videos</TabsTrigger>
                  <TabsTrigger value="document">Documents</TabsTrigger>
                  <TabsTrigger value="image">Images</TabsTrigger>
                  <TabsTrigger value="audio">Audio</TabsTrigger>
                </TabsList>
                
                <TabsContent value="all" className="py-4">
                  {isLoadingMaterials || !selectedCourseId ? (
                    <div className="flex items-center justify-center h-64">
                      {isLoadingMaterials ? (
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      ) : (
                        <div className="text-center">
                          <p className="text-muted-foreground">Select a course to view materials</p>
                        </div>
                      )}
                    </div>
                  ) : filteredMaterials.length > 0 ? (
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm text-muted-foreground mb-2">
                        <div className="flex items-center">
                          <span>Showing {filteredMaterials.length} materials</span>
                        </div>
                        <div className="flex items-center">
                          <ArrowUpDown className="h-4 w-4 mr-1" />
                          <span>Sort by: Order</span>
                        </div>
                      </div>
                      
                      {filteredMaterials.map((material) => (
                        <Card key={material.id} className="overflow-hidden">
                          <CardContent className="p-0">
                            <div className="flex items-start p-4">
                              <div className="bg-secondary/30 rounded p-2 mr-4">
                                {getMaterialIcon(material.type)}
                              </div>
                              <div className="flex-1">
                                <h3 className="font-medium">{material.title}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {material.type} • Module {material.moduleId || 'Unassigned'}
                                </p>
                              </div>
                              <div className="flex space-x-1">
                                <Button variant="ghost" size="icon" asChild>
                                  <a href={material.url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4" />
                                  </a>
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 border border-dashed rounded-lg">
                      <File className="h-10 w-10 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium mb-2">No materials found</h3>
                      <p className="text-muted-foreground mb-4">
                        {searchQuery ? 
                          "No materials match your search criteria." : 
                          "This course doesn't have any materials yet."}
                      </p>
                      <Button asChild>
                        <Link href="/instructor">
                          <Plus className="mr-2 h-4 w-4" /> Upload Material
                        </Link>
                      </Button>
                    </div>
                  )}
                </TabsContent>
                
                {/* The other tab contents would be similar but filtered by type */}
                <TabsContent value="video" className="py-4">
                  {/* Same structure as "all" tab but filtered for videos */}
                </TabsContent>
                <TabsContent value="document" className="py-4">
                  {/* Same structure as "all" tab but filtered for documents */}
                </TabsContent>
                <TabsContent value="image" className="py-4">
                  {/* Same structure as "all" tab but filtered for images */}
                </TabsContent>
                <TabsContent value="audio" className="py-4">
                  {/* Same structure as "all" tab but filtered for audio */}
                </TabsContent>
              </Tabs>
            </div>
          </div>
          
          <div className="lg:col-span-4">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Upload New Material</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  Add a new learning material to one of your courses.
                </p>
                <MaterialUploadForm 
                  courses={courses.map((course) => ({
                    ...course,
                    // In a real app, this would be populated with actual module data
                    modules: [
                      { id: 1, title: "Example Module 1" },
                      { id: 2, title: "Example Module 2" },
                    ]
                  }))}
                  minimized={true} // We could add this prop to show a simplified version
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}