import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/layout/app-layout";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Loader2, Search, UserPlus, UserMinus, MoreHorizontal } from "lucide-react";
import { Course, User } from "@shared/schema";
import { EnrollmentManager } from "@/components/admin/enrollment-manager";

export default function InstructorStudentsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState<string>("all");
  
  // Query to fetch all enrollments
  const { 
    data: enrollments = [], 
    isLoading: isLoadingEnrollments 
  } = useQuery<any[]>({
    queryKey: ["/api/enrollments"],
    enabled: !!user,
  });
  
  // Query to fetch all courses for filtering
  const { 
    data: courses = [], 
    isLoading: isLoadingCourses 
  } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });
  
  // Query to fetch all users for reference
  const { 
    data: users = [], 
    isLoading: isLoadingUsers 
  } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: !!user,
  });
  
  const isLoading = isLoadingEnrollments || isLoadingCourses || isLoadingUsers;
  
  // Filter enrollments based on search and selected course
  const filteredEnrollments = enrollments.filter(enrollment => {
    const student = users.find(u => u.id === enrollment.userId);
    if (!student) return false;
    
    const matchesSearch = 
      student.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (student.name && student.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCourse = selectedCourseId === "all" || enrollment.courseId.toString() === selectedCourseId;
    
    return matchesSearch && matchesCourse;
  });
  
  // Get student name from user id
  const getStudentName = (userId: number) => {
    const student = users.find(u => u.id === userId);
    return student ? (student.name || student.username) : 'Unknown';
  };
  
  // Get course title from course id
  const getCourseTitle = (courseId: number) => {
    const course = courses.find(c => c.id === courseId);
    return course ? course.title : 'Unknown Course';
  };
  
  return (
    <AppLayout>
      <div className="container mx-auto py-6 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Student Management</h1>
            <p className="text-muted-foreground">
              Manage student enrollments in your courses
            </p>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-4">Enrolled Students</h2>
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <div className="relative w-full sm:w-2/3">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search students..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="w-full sm:w-1/3">
                    <Select
                      value={selectedCourseId}
                      onValueChange={setSelectedCourseId}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by course" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Courses</SelectItem>
                        {courses.map((course) => (
                          <SelectItem key={course.id} value={course.id.toString()}>
                            {course.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              {isLoading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredEnrollments.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Course</TableHead>
                        <TableHead>Enrollment Date</TableHead>
                        <TableHead>Progress</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredEnrollments.map((enrollment) => (
                        <TableRow key={enrollment.id}>
                          <TableCell className="font-medium">
                            {getStudentName(enrollment.userId)}
                          </TableCell>
                          <TableCell>{getCourseTitle(enrollment.courseId)}</TableCell>
                          <TableCell>
                            {new Date(enrollment.enrolledAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={enrollment.progress > 75 ? "secondary" : "default"}>
                              {enrollment.progress || 0}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => {
                                  toast({
                                    title: "Contact student",
                                    description: "This feature will be available soon.",
                                  });
                                }}
                              >
                                <UserPlus className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => {
                                  toast({
                                    title: "Warning",
                                    description: "Are you sure you want to remove this student?",
                                    variant: "destructive",
                                  });
                                }}
                              >
                                <UserMinus className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-12 border border-dashed rounded-lg">
                  <UserPlus className="h-10 w-10 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No students found</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchQuery ? 
                      "No students match your search criteria." : 
                      "You don't have any enrolled students yet."}
                  </p>
                </div>
              )}
            </Card>
          </div>
          
          <div className="lg:col-span-1">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Enrollment Management</h2>
              <p className="text-sm text-muted-foreground mb-6">
                Add new students to your courses or manage existing enrollments.
              </p>
              
              <EnrollmentManager minimized={true} />
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}