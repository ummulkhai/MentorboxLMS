import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { 
  Loader2, 
  ShieldAlert, 
  Lock 
} from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// The required password for elevated roles
const ADMIN_PASSWORD = "mentorbox2025POD";

export default function RoleSwitcher() {
  const { user, isLoading } = useAuth();
  const [isPending, setIsPending] = useState(false);
  const [redirectTo, setRedirectTo] = useState<string | null>(null);
  
  // Password dialog state
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [roleToSwitch, setRoleToSwitch] = useState<"instructor" | "admin" | null>(null);

  // Prepare to switch role (open password dialog for instructor/admin)
  const prepareRoleSwitch = (newRole: "student" | "instructor" | "admin") => {
    if (newRole === "student") {
      // No password needed for student role
      performRoleSwitch(newRole);
    } else {
      // Open the password dialog for instructor or admin roles
      setRoleToSwitch(newRole);
      setPassword("");
      setPasswordError("");
      setIsPasswordDialogOpen(true);
    }
  };

  // Verify password and perform role switch if correct
  const verifyPasswordAndSwitch = () => {
    if (!roleToSwitch) return;
    
    if (password === ADMIN_PASSWORD) {
      setIsPasswordDialogOpen(false);
      performRoleSwitch(roleToSwitch);
    } else {
      setPasswordError("Incorrect password. Please try again.");
    }
  };

  // Function to actually switch user role
  const performRoleSwitch = async (newRole: "student" | "instructor" | "admin") => {
    if (!user) return;
    
    setIsPending(true);
    try {
      // Call the API to switch roles
      const res = await apiRequest("POST", "/api/switch-role", { role: newRole });
      if (!res.ok) throw new Error("Failed to switch role");
      
      // Get the response data which contains the updated user
      const data = await res.json();
      
      // Update cached user data with the response from server
      if (data.user) {
        queryClient.setQueryData(["/api/user"], data.user);
      } else {
        // If the server didn't return updated user, update it locally (fallback)
        const updatedUser = { ...user, role: newRole };
        queryClient.setQueryData(["/api/user"], updatedUser);
      }
      
      // Set appropriate redirect based on role
      switch(newRole) {
        case "admin":
          setRedirectTo("/admin/dashboard");
          break;
        case "instructor":
          setRedirectTo("/instructor/dashboard");
          break;
        case "student":
          setRedirectTo("/student/dashboard");
          break;
      }
      
      toast({
        title: "Role Updated",
        description: `Your role has been changed to ${newRole}`,
      });
    } catch (error) {
      toast({
        title: "Role Switch Failed",
        description: "There was an error changing your role. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsPending(false);
    }
  };

  // Redirect after successful role switch
  if (redirectTo) {
    return <Redirect to={redirectTo} />;
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth" />;
  }

  return (
    <>
      <div className="container max-w-4xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold">Role Switcher (Demo Only)</h1>
          <p className="mt-2 text-muted-foreground">This page allows you to test different user roles in the application</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className={user.role === "student" ? "border-primary" : ""}>
            <CardHeader>
              <CardTitle>Student Role</CardTitle>
              <CardDescription>Access learning materials and courses</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm">Students can view enrolled courses, access learning materials, track progress, and bookmark resources.</p>
            </CardContent>
            <CardFooter>
              <Button 
                variant={user.role === "student" ? "default" : "outline"} 
                className="w-full"
                disabled={user.role === "student" || isPending}
                onClick={() => prepareRoleSwitch("student")}
              >
                {isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                {user.role === "student" ? "Current Role" : "Switch to Student"}
              </Button>
            </CardFooter>
          </Card>

          <Card className={user.role === "instructor" ? "border-primary" : ""}>
            <CardHeader className="relative">
              <div className="absolute top-3 right-3">
                <Lock className="h-4 w-4 text-amber-500" />
              </div>
              <CardTitle>Instructor Role</CardTitle>
              <CardDescription>Manage courses and students</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm">Instructors can create courses, upload materials, embed videos, and manage their enrolled students.</p>
            </CardContent>
            <CardFooter>
              <Button 
                variant={user.role === "instructor" ? "default" : "outline"} 
                className="w-full"
                disabled={user.role === "instructor" || isPending}
                onClick={() => prepareRoleSwitch("instructor")}
              >
                {isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                {user.role === "instructor" ? "Current Role" : "Switch to Instructor"}
              </Button>
            </CardFooter>
          </Card>

          <Card className={user.role === "admin" ? "border-primary" : ""}>
            <CardHeader className="relative">
              <div className="absolute top-3 right-3">
                <ShieldAlert className="h-4 w-4 text-red-500" />
              </div>
              <CardTitle>Admin Role</CardTitle>
              <CardDescription>Full system administration</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm">Administrators have full access to manage users, courses, enrollments, and system settings.</p>
            </CardContent>
            <CardFooter>
              <Button 
                variant={user.role === "admin" ? "default" : "outline"} 
                className="w-full"
                disabled={user.role === "admin" || isPending}
                onClick={() => prepareRoleSwitch("admin")}
              >
                {isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                {user.role === "admin" ? "Current Role" : "Switch to Admin"}
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <div className="mt-8 p-4 bg-muted rounded-lg">
          <h3 className="text-sm font-medium mb-2">⚠️ Demo Feature Only</h3>
          <p className="text-sm text-muted-foreground">
            In a production environment, role changes would require proper administrative approval and authentication.
            This page is provided for demonstration purposes to allow testing of different user interfaces.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            <strong>Note:</strong> Switching to Instructor or Admin roles requires a password. For this demo, use: <code className="bg-background px-1 py-0.5 rounded text-xs">mentorbox2025POD</code>
          </p>
        </div>
      </div>

      {/* Password Dialog */}
      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Password Required</DialogTitle>
            <DialogDescription>
              Enter the administrator password to switch to {roleToSwitch} role
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="password" className="sr-only">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={passwordError ? "border-red-300" : ""}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    verifyPasswordAndSwitch();
                  }
                }}
              />
              {passwordError && (
                <p className="text-sm text-red-500">{passwordError}</p>
              )}
            </div>
          </div>
          <DialogFooter className="flex justify-between space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsPasswordDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" onClick={verifyPasswordAndSwitch}>
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}