import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Course, CourseModule, CourseMaterial } from "@shared/schema";
import { AppLayout } from "@/layout/app-layout";
import { CourseContentModal } from "@/components/course-content-modal";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Calendar, Clock, PlayCircle, FileText } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";

export default function CoursePage() {
  const [, params] = useRoute("/course/:id");
  const courseId = params?.id ? parseInt(params.id) : 0;
  
  const [activeTab, setActiveTab] = useState("content");
  const [selectedModuleIndex, setSelectedModuleIndex] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: course, isLoading: isLoadingCourse } = useQuery<Course>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: courseId > 0,
  });

  const { data: modules, isLoading: isLoadingModules } = useQuery<CourseModule[]>({
    queryKey: [`/api/courses/${courseId}/modules`],
    enabled: courseId > 0,
  });

  const { data: materials, isLoading: isLoadingMaterials } = useQuery<CourseMaterial[]>({
    queryKey: [`/api/courses/${courseId}/materials`],
    enabled: courseId > 0,
  });

  const { data: progress } = useQuery<number>({
    queryKey: [`/api/courses/${courseId}/progress`],
    enabled: courseId > 0,
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (newProgress: number) => {
      const res = await apiRequest("POST", `/api/courses/${courseId}/progress`, { progress: newProgress });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}/progress`] });
    },
  });

  const handleModuleSelect = (index: number) => {
    setSelectedModuleIndex(index);
    setIsModalOpen(true);
  };

  const handleNextModule = () => {
    if (modules && selectedModuleIndex < modules.length - 1) {
      setSelectedModuleIndex(selectedModuleIndex + 1);
      // Update progress when moving to the next module
      const newProgress = Math.round(((selectedModuleIndex + 2) / modules.length) * 100);
      updateProgressMutation.mutate(newProgress);
    }
  };

  const handlePreviousModule = () => {
    if (selectedModuleIndex > 0) {
      setSelectedModuleIndex(selectedModuleIndex - 1);
    }
  };

  if (isLoadingCourse || isLoadingModules || isLoadingMaterials) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!course || !modules || !materials) {
    return (
      <AppLayout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-neutral-900 mb-4">Course not found</h2>
          <p className="text-neutral-600">The course you're looking for doesn't exist or you don't have access to it.</p>
        </div>
      </AppLayout>
    );
  }

  const moduleSpecificMaterials = materials.filter(m => m.moduleId === modules[selectedModuleIndex]?.id);
  const startDate = new Date(course.startDate);
  const endDate = new Date(course.endDate);

  return (
    <AppLayout>
      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-neutral-200 mb-8">
        <div className="md:flex">
          <div className="md:flex-shrink-0 md:w-1/3">
            <img 
              className="h-48 w-full object-cover md:h-full" 
              src={course.thumbnail} 
              alt={course.title} 
            />
          </div>
          <div className="p-8">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-neutral-900">{course.title}</h1>
              <span className={`ml-4 px-3 py-1 text-xs font-semibold rounded-full ${
                course.type === "online" ? "bg-blue-100 text-blue-800" : "bg-amber-100 text-amber-800"
              }`}>
                {course.type === "online" ? "Online Class" : "Offline Workshop"}
              </span>
            </div>
            <p className="mt-2 text-neutral-600">{course.description}</p>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center text-neutral-700">
                <Calendar className="h-5 w-5 mr-2 text-neutral-500" />
                <span>{format(startDate, "MMMM d")} - {format(endDate, "MMMM d, yyyy")}</span>
              </div>
              <div className="flex items-center text-neutral-700">
                <Clock className="h-5 w-5 mr-2 text-neutral-500" />
                <span>{course.timeStart} - {course.timeEnd} ({course.timezone})</span>
              </div>
            </div>
            
            <div className="mt-6">
              <div className="w-full bg-neutral-200 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full" 
                  style={{ width: `${progress || 0}%` }}
                ></div>
              </div>
              <div className="mt-1 text-sm text-neutral-500 text-right">{progress || 0}% complete</div>
            </div>
          </div>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
          <TabsTrigger value="content">Course Content</TabsTrigger>
          <TabsTrigger value="materials">Materials</TabsTrigger>
          <TabsTrigger value="discussion">Discussion</TabsTrigger>
        </TabsList>
        
        <TabsContent value="content" className="mt-6">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Course Modules</h2>
              <div className="space-y-4">
                {modules.map((module, index) => (
                  <Card key={module.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <button 
                        className="w-full text-left p-4 flex items-center justify-between"
                        onClick={() => handleModuleSelect(index)}
                      >
                        <div className="flex items-center">
                          <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center mr-4 ${
                            progress && (index + 1) / modules.length * 100 <= progress
                              ? "bg-green-100 text-green-600"
                              : index === selectedModuleIndex
                                ? "bg-primary-light text-primary-dark"
                                : "bg-neutral-100 text-neutral-500"
                          }`}>
                            {progress && (index + 1) / modules.length * 100 <= progress ? (
                              <i className="fas fa-check"></i>
                            ) : (
                              <span>{index + 1}</span>
                            )}
                          </div>
                          <div>
                            <h3 className="font-medium text-neutral-900">{module.title}</h3>
                            <p className="text-sm text-neutral-500">
                              {materials.filter(m => m.moduleId === module.id).length} resources
                            </p>
                          </div>
                        </div>
                        <PlayCircle className="h-5 w-5 text-primary" />
                      </button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="materials" className="mt-6">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Course Materials</h2>
              <div className="space-y-4">
                {materials.map((material) => (
                  <a 
                    key={material.id}
                    href={material.url}
                    target="_blank"
                    rel="noopener noreferrer" 
                    className="flex items-center p-4 border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors"
                  >
                    <div className="flex-shrink-0 h-10 w-10 bg-neutral-100 rounded-md flex items-center justify-center">
                      {material.type === 'video' ? (
                        <PlayCircle className="h-5 w-5 text-primary" />
                      ) : (
                        <FileText className="h-5 w-5 text-orange-500" />
                      )}
                    </div>
                    <div className="ml-4">
                      <h3 className="font-medium text-neutral-900">{material.title}</h3>
                      <p className="text-sm text-neutral-500">{material.type.toUpperCase()}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="discussion" className="mt-6">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
            <div className="p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Discussion Forum</h2>
              <p className="text-neutral-600">
                Join the conversation with your classmates and instructor.
              </p>
              <div className="mt-4 text-center py-10">
                <p className="text-neutral-500">Discussion forum feature coming soon!</p>
                <Button className="mt-4">Notify Me When Available</Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      {isModalOpen && modules[selectedModuleIndex] && (
        <CourseContentModal
          courseTitle={course.title}
          module={modules[selectedModuleIndex]}
          currentModuleIndex={selectedModuleIndex}
          totalModules={modules.length}
          materials={moduleSpecificMaterials}
          progress={progress || 0}
          onClose={() => setIsModalOpen(false)}
          onNext={handleNextModule}
          onPrevious={handlePreviousModule}
        />
      )}
    </AppLayout>
  );
}
