import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/layout/app-layout";
import { Loader2, FileText, Video, File } from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CourseMaterial } from "@shared/schema";

export default function ResourcesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  const { data: materials, isLoading } = useQuery<CourseMaterial[]>({
    queryKey: ["/api/materials/all"],
  });

  const getIconForType = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf':
        return <File className="h-12 w-12 text-red-500" />;
      case 'video':
        return <Video className="h-12 w-12 text-blue-500" />;
      default:
        return <FileText className="h-12 w-12 text-gray-500" />;
    }
  };

  const filteredMaterials = materials?.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTab = activeTab === "all" || material.type.toLowerCase() === activeTab.toLowerCase();
    return matchesSearch && matchesTab;
  }) || [];

  return (
    <AppLayout>
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Learning Resources</h1>
        <p className="text-muted-foreground mb-8">
          Access all learning materials from your courses in one place. 
          Filter by type or search for specific content.
        </p>

        <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-8">
          <Input
            placeholder="Search resources..."
            className="max-w-md"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pdf">Documents</TabsTrigger>
              <TabsTrigger value="video">Videos</TabsTrigger>
              <TabsTrigger value="other">Other</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredMaterials.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map((material) => (
              <Card key={material.id} className="overflow-hidden hover:shadow-md transition-shadow duration-200">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      {getIconForType(material.type)}
                      <div>
                        <CardTitle className="text-lg">{material.title}</CardTitle>
                        <CardDescription>
                          {material.type.toUpperCase()} • Module {material.moduleId}
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <p className="text-sm text-muted-foreground">
                    From {material.courseId ? `Course #${material.courseId}` : 'General Materials'}
                  </p>
                </CardContent>
                <CardFooter>
                  <Button
                    onClick={() => window.open(material.url, '_blank')}
                    variant="default"
                    className="w-full"
                  >
                    View Resource
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border border-dashed rounded-lg">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No resources found</h3>
            <p className="text-muted-foreground mb-4 max-w-md mx-auto">
              {searchTerm 
                ? `No resources matching "${searchTerm}" found. Try a different search term.` 
                : "No resources available yet. Resources will appear here when they are added to your courses."}
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}