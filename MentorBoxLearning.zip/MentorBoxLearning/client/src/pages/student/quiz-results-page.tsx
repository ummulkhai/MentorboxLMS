import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { AppLayout as Layout } from "@/layout/app-layout";
import { formatDate } from "@/lib/utils";
import { QuizAttempt, QuizAnswer, Quiz, QuizQuestion } from "@shared/schema";

export default function QuizResultsPage() {
  const { id } = useParams();
  const attemptId = parseInt(id);
  const [, navigate] = useLocation();
  const { user } = useAuth();
  
  // Fetch the quiz attempt
  const { data: attempt, isLoading: isLoadingAttempt } = useQuery<QuizAttempt>({
    queryKey: [`/api/quiz-attempts/${attemptId}`],
    enabled: !!attemptId && !!user
  });
  
  // Fetch the quiz
  const { data: quiz, isLoading: isLoadingQuiz } = useQuery<Quiz>({
    queryKey: [`/api/quizzes/${attempt?.quizId}`],
    enabled: !!attempt?.quizId
  });
  
  // Fetch the quiz questions
  const { data: questions, isLoading: isLoadingQuestions } = useQuery<QuizQuestion[]>({
    queryKey: [`/api/quizzes/${attempt?.quizId}/questions`],
    enabled: !!attempt?.quizId
  });
  
  // Fetch the quiz answers
  const { data: answers, isLoading: isLoadingAnswers } = useQuery<QuizAnswer[]>({
    queryKey: [`/api/quiz-attempts/${attemptId}/answers`],
    enabled: !!attemptId
  });
  
  const isLoading = isLoadingAttempt || isLoadingQuiz || isLoadingQuestions || isLoadingAnswers;
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
              <h2 className="text-xl font-semibold">Loading Results...</h2>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  if (!attempt || !quiz) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Unable to load quiz results. The attempt may not exist.
            </AlertDescription>
          </Alert>
          <div className="mt-4">
            <Button onClick={() => navigate("/student/quizzes")}>
              Back to Quizzes
            </Button>
          </div>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container mx-auto py-6 max-w-4xl">
        <Card className="shadow-lg mb-8">
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <div>
                <CardTitle className="text-2xl">{quiz.title} - Results</CardTitle>
                <CardDescription>
                  Attempt #{attempt.attemptNumber} • Completed on {formatDate(attempt.updatedAt)}
                </CardDescription>
              </div>
              <Badge 
                variant={attempt.passed ? "default" : "destructive"}
                className="text-sm self-start md:self-auto"
              >
                {attempt.passed ? "Passed" : "Failed"}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="bg-muted/50 rounded-lg p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
                <h3 className="text-lg font-semibold">Score Summary</h3>
                <div className="text-3xl font-bold">
                  {attempt.score}%
                </div>
              </div>
              
              <Progress 
                value={parseInt(attempt.score || "0")} 
                className={`h-3 mb-2 ${attempt.passed ? "[&>div]:bg-green-500" : "[&>div]:bg-red-500"}`}
              />
              
              <div className="flex justify-between text-sm">
                <span>0%</span>
                <span className={`font-medium ${attempt.passed ? "text-green-500" : "text-red-500"}`}>
                  Passing: {quiz.passingScore}%
                </span>
                <span>100%</span>
              </div>
            </div>
            
            {attempt.timeSpent && (
              <div className="flex items-center justify-between px-2">
                <span className="text-sm text-muted-foreground">Time spent</span>
                <span className="font-medium">{Math.floor(attempt.timeSpent / 60)}:{(attempt.timeSpent % 60).toString().padStart(2, '0')}</span>
              </div>
            )}
            
            <Alert variant={attempt.passed ? "default" : "destructive"}>
              {attempt.passed ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <XCircle className="h-4 w-4" />
              )}
              <AlertTitle>
                {attempt.passed 
                  ? "Congratulations!" 
                  : `You didn't reach the passing score of ${quiz.passingScore}%`}
              </AlertTitle>
              <AlertDescription>
                {attempt.passed 
                  ? "You have successfully passed this quiz." 
                  : quiz.attemptsAllowed && attempt.attemptNumber < quiz.attemptsAllowed
                    ? `You can retry this quiz. You have used ${attempt.attemptNumber} of ${quiz.attemptsAllowed} attempts.`
                    : "You have used all your attempts for this quiz."
                }
              </AlertDescription>
            </Alert>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => navigate("/student/quizzes")}>
              Back to Quizzes
            </Button>
            
            {quiz.attemptsAllowed && attempt.attemptNumber < quiz.attemptsAllowed && !attempt.passed && (
              <Button onClick={() => navigate(`/student/quizzes/${quiz.id}`)}>
                Try Again
              </Button>
            )}
          </CardFooter>
        </Card>
        
        <h2 className="text-xl font-bold mb-4">Answer Review</h2>
        
        {questions?.map((question, index) => {
          const answer = answers?.find(a => a.questionId === question.id);
          
          return (
            <Card key={question.id} className="mb-4 overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex justify-between">
                  <CardTitle className="text-base">Question {index + 1}</CardTitle>
                  {answer?.isCorrect !== null && (
                    <Badge variant={answer?.isCorrect ? "default" : "destructive"}>
                      {answer?.isCorrect ? "Correct" : "Incorrect"}
                    </Badge>
                  )}
                </div>
                <CardDescription className="text-muted-foreground text-sm">
                  {question.questionType === "multiple_choice" ? "Multiple Choice" : 
                   question.questionType === "true_false" ? "True/False" :
                   question.questionType === "short_answer" ? "Short Answer" :
                   question.questionType === "essay" ? "Essay" : "Matching"}
                   {" • "}{question.points} points
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pb-3">
                <div className="font-medium mb-3">{question.questionText}</div>
                
                <div className="space-y-4">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground mb-1">Your Answer:</div>
                    <div className="bg-muted/30 p-3 rounded text-sm">
                      {renderAnswer(question.questionType, answer?.userAnswer)}
                    </div>
                  </div>
                  
                  {answer?.isCorrect === false && (
                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-1">Correct Answer:</div>
                      <div className="bg-muted/30 p-3 rounded text-sm">
                        {renderAnswer(question.questionType, question.correctAnswer)}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              
              {answer?.feedback && (
                <>
                  <Separator />
                  <CardFooter className="pt-3">
                    <div className="w-full">
                      <div className="text-sm font-medium text-muted-foreground mb-1">Feedback:</div>
                      <div className="text-sm">{answer.feedback}</div>
                    </div>
                  </CardFooter>
                </>
              )}
            </Card>
          );
        })}
      </div>
    </Layout>
  );
}

function renderAnswer(questionType: string, answer: any): React.ReactNode {
  if (!answer) return <span className="text-muted-foreground italic">No answer provided</span>;
  
  switch (questionType) {
    case "multiple_choice":
      return <span>{answer}</span>;
    case "true_false":
      return <span>{answer === true ? "True" : "False"}</span>;
    case "short_answer":
    case "essay":
      return <span>{answer}</span>;
    case "matching":
      if (typeof answer === "object") {
        return (
          <ul className="list-disc list-inside">
            {Object.entries(answer).map(([term, definition], i) => (
              <li key={i}>
                <span className="font-medium">{term}</span>: {definition}
              </li>
            ))}
          </ul>
        );
      }
      return <span>{JSON.stringify(answer)}</span>;
    default:
      return <span>{JSON.stringify(answer)}</span>;
  }
}