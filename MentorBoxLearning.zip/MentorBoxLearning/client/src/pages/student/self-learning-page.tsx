import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SelfLearningMaterial } from "@shared/schema";
import { AppLayout } from "@/layout/app-layout";
import { SelfLearningCard } from "@/components/self-learning-card";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function SelfLearningPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedMaterial, setSelectedMaterial] = useState<SelfLearningMaterial | null>(null);

  const { data: materials, isLoading } = useQuery<SelfLearningMaterial[]>({
    queryKey: ["/api/self-learning"],
  });

  // Filter materials based on search and type
  const filteredMaterials = materials?.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         material.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "all" || material.type === typeFilter;
    
    return matchesSearch && matchesType;
  });

  // Extract unique types for filter dropdown
  const types = materials ? 
    ["all", ...Array.from(new Set(materials.map(material => material.type)))] : 
    ["all"];

  const handleStartMaterial = (id: number) => {
    const material = materials?.find(m => m.id === id) || null;
    setSelectedMaterial(material);
  };

  return (
    <AppLayout>
      <div className="pb-12">
        {/* Title Section */}
        <div className="border-b pb-5 mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">Self-Learning Materials & Resources</h1>
          <p className="text-neutral-500 mt-2">Explore additional learning resources to enhance your knowledge</p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
            <Input
              placeholder="Search materials..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-48">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                {types.map(type => (
                  <SelectItem key={type} value={type}>
                    {type === "all" ? "All Types" : type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Materials Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center h-60">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : filteredMaterials && filteredMaterials.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map(material => (
              <SelfLearningCard
                key={material.id}
                id={material.id}
                title={material.title}
                description={material.description}
                icon={material.icon}
                type={material.type}
                duration={material.duration}
                category={material.category}
                onStart={handleStartMaterial}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-neutral-200">
            <h3 className="text-lg font-medium text-neutral-900">No materials found</h3>
            <p className="text-neutral-500 mt-2">
              {searchTerm || typeFilter !== "all" 
                ? "Try adjusting your search or filter criteria" 
                : "There are no self-learning materials available yet"}
            </p>
          </div>
        )}
      </div>

      {/* Material Content Dialog */}
      <Dialog open={!!selectedMaterial} onOpenChange={(open) => !open && setSelectedMaterial(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedMaterial?.title}</DialogTitle>
            <DialogDescription>
              {selectedMaterial?.type} • {selectedMaterial?.duration}
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <h3 className="font-medium mb-2">Description</h3>
            <p className="text-neutral-700">{selectedMaterial?.description}</p>
            
            <div className="mt-6 p-4 bg-neutral-50 rounded-lg border border-neutral-200">
              <h3 className="font-medium mb-2">Content</h3>
              {selectedMaterial?.url ? (
                <div className="aspect-video bg-white rounded overflow-hidden border">
                  <iframe
                    src={selectedMaterial.url}
                    className="w-full h-full"
                    allowFullScreen
                    title={selectedMaterial.title}
                  />
                </div>
              ) : (
                <p className="text-neutral-500">Content coming soon...</p>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}