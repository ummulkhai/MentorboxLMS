import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Course, CourseMaterial } from "@shared/schema";
import { AppLayout } from "@/layout/app-layout";
import { Loader2, Search, Play, Clock, FileVideo } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function VideoLessonsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedVideo, setSelectedVideo] = useState<CourseMaterial | null>(null);

  // Fetch enrolled courses
  const { data: courses, isLoading: isLoadingCourses } = useQuery<Course[]>({
    queryKey: ["/api/courses/enrolled"],
  });

  // Fetch all video materials from enrolled courses
  const { data: materials, isLoading: isLoadingMaterials } = useQuery<CourseMaterial[]>({
    queryKey: ["/api/materials/videos"],
    enabled: !!courses?.length,
  });

  const filteredVideos = materials?.filter(material => 
    material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="pb-12">
        {/* Title Section */}
        <div className="border-b pb-5 mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">Video Lessons</h1>
          <p className="text-neutral-500 mt-2">Browse and watch all video content from your courses</p>
        </div>

        {/* Search */}
        <div className="mb-8 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
          <Input
            placeholder="Search video lessons..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Videos Grid */}
        {isLoadingCourses || isLoadingMaterials ? (
          <div className="flex items-center justify-center h-60">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : filteredVideos && filteredVideos.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVideos.map(video => (
              <Card key={video.id} className="overflow-hidden">
                <div 
                  className="relative h-48 bg-neutral-100 cursor-pointer group"
                  onClick={() => setSelectedVideo(video)}
                >
                  <div className="w-full h-full flex items-center justify-center bg-neutral-200">
                    <FileVideo className="h-12 w-12 text-neutral-400" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                      <Play className="h-8 w-8 text-white" />
                    </div>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{video.title}</CardTitle>
                  <CardDescription>
                    {courses?.find(c => c.id === video.courseId)?.title || "Unknown Course"}
                  </CardDescription>
                </CardHeader>
                <CardFooter className="pt-0 text-sm text-neutral-500 flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>15 min</span>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-neutral-200">
            <h3 className="text-lg font-medium text-neutral-900">No video lessons found</h3>
            <p className="text-neutral-500 mt-2">
              {searchTerm 
                ? "Try adjusting your search criteria" 
                : "There are no video lessons available in your enrolled courses"}
            </p>
          </div>
        )}
      </div>

      {/* Video Player Dialog */}
      <Dialog open={!!selectedVideo} onOpenChange={(open) => !open && setSelectedVideo(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedVideo?.title}</DialogTitle>
          </DialogHeader>
          <div className="aspect-video bg-black rounded overflow-hidden">
            {selectedVideo && (
              <iframe
                src={selectedVideo.url}
                className="w-full h-full"
                allowFullScreen
                title={selectedVideo.title}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}