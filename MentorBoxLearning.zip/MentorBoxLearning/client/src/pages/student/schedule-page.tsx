import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from "date-fns";
import { AppLayout } from "@/layout/app-layout";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UpcomingClassItem } from "@/components/upcoming-class-item";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

interface ClassEvent {
  id: number;
  title: string;
  date: string;
  timeStart: string;
  timeEnd: string;
  timezone: string;
  type: "online" | "offline";
  courseId: number;
  icon: string;
}

export default function SchedulePage() {
  const [date, setDate] = useState<Date>(new Date());
  const [month, setMonth] = useState<Date>(new Date());
  
  const { data: events, isLoading } = useQuery<ClassEvent[]>({
    queryKey: ["/api/courses/schedule"],
  });

  // Process events for the calendar
  const eventDates = events ? events.map(event => new Date(event.date)) : [];
  
  // Filter events for the selected date
  const selectedDateEvents = events?.filter(event => 
    isSameDay(new Date(event.date), date)
  ).sort((a, b) => 
    a.timeStart.localeCompare(b.timeStart)
  );

  // Get days in the current month for the calendar
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month)
  });

  const nextMonth = () => {
    setMonth(addMonths(month, 1));
  };

  const prevMonth = () => {
    setMonth(subMonths(month, 1));
  };

  return (
    <AppLayout>
      <div className="pb-12">
        {/* Title Section */}
        <div className="border-b pb-5 mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">Class Schedule</h1>
          <p className="text-neutral-500 mt-2">View and manage your upcoming classes and schedule</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>Calendar</CardTitle>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon" onClick={prevMonth}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium">
                    {format(month, "MMMM yyyy")}
                  </span>
                  <Button variant="outline" size="icon" onClick={nextMonth}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center h-80">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <Calendar 
                    mode="single"
                    selected={date}
                    onSelect={(newDate) => newDate && setDate(newDate)}
                    month={month}
                    onMonthChange={setMonth}
                    className="rounded-md border"
                    modifiers={{
                      event: eventDates
                    }}
                    modifiersStyles={{
                      event: {
                        fontWeight: 'bold',
                        backgroundColor: 'var(--primary)',
                        color: 'white',
                        borderRadius: '100%'
                      }
                    }}
                  />
                )}
              </CardContent>
            </Card>
          </div>

          {/* Events for Selected Day */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>
                  Classes on {format(date, "MMMM d, yyyy")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center h-60">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : selectedDateEvents && selectedDateEvents.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateEvents.map(event => (
                      <UpcomingClassItem
                        key={event.id}
                        id={event.id}
                        title={event.title}
                        date={new Date(event.date)}
                        timeStart={event.timeStart}
                        timeEnd={event.timeEnd}
                        timezone={event.timezone}
                        type={event.type}
                        icon={event.icon}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-10 text-center">
                    <div className="rounded-full p-3 bg-neutral-100">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-500">
                        <rect width="18" height="18" x="3" y="4" rx="2" ry="2"></rect>
                        <line x1="16" x2="16" y1="2" y2="6"></line>
                        <line x1="8" x2="8" y1="2" y2="6"></line>
                        <line x1="3" x2="21" y1="10" y2="10"></line>
                      </svg>
                    </div>
                    <h3 className="mt-4 text-sm font-medium text-neutral-900">No classes scheduled</h3>
                    <p className="mt-1 text-sm text-neutral-500">
                      There are no classes scheduled for this day.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}