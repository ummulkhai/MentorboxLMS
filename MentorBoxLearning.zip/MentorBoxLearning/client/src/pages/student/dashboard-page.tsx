import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Course, SelfLearningMaterial } from "@shared/schema";
import { CourseCard } from "@/components/course-card";
import { UpcomingClassItem } from "@/components/upcoming-class-item";
import { SelfLearningCard } from "@/components/self-learning-card";
import { FactSection } from "@/components/fact-section";
import { AppLayout } from "@/layout/app-layout";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function StudentDashboardPage() {
  const { user } = useAuth();
  const [showSelfLearningModal, setShowSelfLearningModal] = useState(false);
  const [selectedSelfLearningId, setSelectedSelfLearningId] = useState<number | null>(null);

  const { data: courses, isLoading: isLoadingCourses } = useQuery<Course[]>({
    queryKey: ["/api/courses/enrolled"],
  });

  const { data: upcomingClasses, isLoading: isLoadingClasses } = useQuery<any[]>({
    queryKey: ["/api/courses/upcoming"],
  });

  const { data: selfLearningMaterials, isLoading: isLoadingSelfLearning } = useQuery<SelfLearningMaterial[]>({
    queryKey: ["/api/self-learning"],
    queryFn: async () => {
      const res = await fetch("/api/self-learning");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const handleStartSelfLearning = (id: number) => {
    setSelectedSelfLearningId(id);
    setShowSelfLearningModal(true);
  };

  if (isLoadingCourses || isLoadingClasses || isLoadingSelfLearning) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      {/* Title Section */}
      <div className="border-b pb-5 mb-8">
        <h1 className="text-3xl font-bold text-neutral-900">Student Dashboard</h1>
        <p className="text-neutral-500 mt-2">Welcome to your personalized learning dashboard</p>
      </div>
      
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary-dark to-accent-dark rounded-xl shadow-lg overflow-hidden mb-8">
        <div className="md:flex">
          <div className="px-6 py-12 md:p-12 md:w-2/3">
            <h1 className="text-3xl font-bold text-white sm:text-4xl">Welcome back, {user?.name.split(' ')[0]}!</h1>
            <p className="mt-4 text-lg text-white text-opacity-90">
              Continue your learning journey with MentorBox. Track your progress and explore new courses.
            </p>
            <div className="mt-8">
              <Link href="/student/courses">
                <Button variant="secondary" size="lg">
                  Continue Learning
                </Button>
              </Link>
            </div>
          </div>
          <div className="md:w-1/3 flex items-center justify-center p-8 bg-white bg-opacity-10">
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-white bg-opacity-20 text-white">
                <i className="fas fa-graduation-cap text-2xl"></i>
              </div>
              <p className="mt-3 text-white font-medium">Your next class starts in</p>
              <div className="mt-1 text-3xl font-bold text-white">2 days</div>
            </div>
          </div>
        </div>
      </div>

      {/* Current Courses */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-neutral-900">Your Current Courses</h2>
          <Link href="/student/courses" className="text-sm font-medium text-primary hover:text-primary-dark">
            View all courses
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses && courses.length > 0 ? (
            courses.slice(0, 3).map((course) => (
              <CourseCard key={course.id} course={course} />
            ))
          ) : (
            <div className="col-span-full text-center py-8 bg-white rounded-lg shadow-sm border border-neutral-200">
              <h3 className="text-lg font-medium text-neutral-900">No enrolled courses</h3>
              <p className="text-neutral-500 mt-2">
                You don't have any courses yet. Browse available courses to enroll.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Upcoming Classes */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-neutral-900">Upcoming Classes</h2>
          <Link href="/student/schedule" className="text-sm font-medium text-primary hover:text-primary-dark">
            View calendar
          </Link>
        </div>

        <div className="overflow-hidden bg-white shadow sm:rounded-lg border border-neutral-200">
          {upcomingClasses && upcomingClasses.length > 0 ? (
            <ul className="divide-y divide-neutral-200">
              {upcomingClasses.slice(0, 3).map((classItem) => (
                <UpcomingClassItem 
                  key={classItem.id}
                  id={classItem.id}
                  title={classItem.title}
                  date={new Date(classItem.date)}
                  timeStart={classItem.timeStart}
                  timeEnd={classItem.timeEnd}
                  timezone={classItem.timezone}
                  type={classItem.type}
                  icon={classItem.icon}
                />
              ))}
            </ul>
          ) : (
            <div className="text-center py-8">
              <p className="text-neutral-500">No upcoming classes scheduled</p>
            </div>
          )}
        </div>
      </section>

      {/* Self-Learning Materials */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-neutral-900">Self-Learning Materials</h2>
          <Link href="/student/self-learning" className="text-sm font-medium text-primary hover:text-primary-dark">
            Browse all
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {selfLearningMaterials && selfLearningMaterials.length > 0 ? (
            selfLearningMaterials.slice(0, 3).map((material) => (
              <SelfLearningCard
                key={material.id}
                id={material.id}
                title={material.title}
                description={material.description}
                icon={material.icon}
                type={material.type}
                duration={material.duration}
                category={material.category}
                onStart={handleStartSelfLearning}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-8 bg-white rounded-lg shadow-sm border border-neutral-200">
              <p className="text-neutral-500">No self-learning materials available yet</p>
            </div>
          )}
        </div>
      </section>

      {/* Fact Section */}
      <FactSection />
    </AppLayout>
  );
}