import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { FileIcon, VideoIcon, File, BookOpen, FileText, PresentationIcon } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";

interface Bookmark {
  id: number;
  material: {
    id: number;
    title: string;
    description: string | null;
    type: string;
    url: string;
    courseId: number;
    moduleId: number | null;
    order: number;
    category: string | null;
    createdAt: string | null;
  };
  createdAt: string;
}

export default function BookmarksPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "alphabetical">("newest");
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const { data: bookmarks = [], isLoading } = useQuery<Bookmark[]>({
    queryKey: ["/api/bookmarks"],
    queryFn: async () => {
      const res = await fetch("/api/bookmarks");
      if (!res.ok) throw new Error("Failed to fetch bookmarks");
      return res.json();
    }
  });

  const removeBookmarkMutation = useMutation({
    mutationFn: async (bookmarkId: number) => {
      await apiRequest("DELETE", `/api/bookmarks/${bookmarkId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: "Bookmark removed",
        description: "The bookmark has been successfully removed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error removing bookmark",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter bookmarks based on search term and type
  const filteredBookmarks = bookmarks.filter(bookmark => {
    const matchesSearch = bookmark.material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (bookmark.material.description && bookmark.material.description.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesType = selectedType === null || bookmark.material.type === selectedType;
    
    return matchesSearch && matchesType;
  });

  // Sort bookmarks
  const sortedBookmarks = [...filteredBookmarks].sort((a, b) => {
    if (sortBy === "newest") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sortBy === "oldest") {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    } else {
      return a.material.title.localeCompare(b.material.title);
    }
  });

  const getMaterialIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'video':
        return <VideoIcon className="h-5 w-5 text-blue-500" />;
      case 'pdf':
        return <FileText className="h-5 w-5 text-red-500" />;
      case 'doc':
      case 'docx':
        return <File className="h-5 w-5 text-blue-600" />;
      case 'ppt':
      case 'pptx':
        return <PresentationIcon className="h-5 w-5 text-orange-500" />;
      case 'xlsx':
      case 'xls':
      case 'excel':
        return <FileIcon className="h-5 w-5 text-green-500" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };

  const getUniqueTypes = () => {
    const types = new Set<string>();
    bookmarks.forEach(bookmark => {
      types.add(bookmark.material.type);
    });
    return Array.from(types);
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col">
        <h1 className="text-3xl font-bold mb-2">My Bookmarks</h1>
        <p className="text-muted-foreground mb-6">Access your saved learning materials</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search bookmarks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        <div className="flex gap-2">
          <Select
            value={sortBy}
            onValueChange={(value) => setSortBy(value as "newest" | "oldest" | "alphabetical")}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="alphabetical">Alphabetical</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={selectedType || ""}
            onValueChange={(value) => setSelectedType(value || null)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Types</SelectItem>
              {getUniqueTypes().map(type => (
                <SelectItem key={type} value={type}>{type.charAt(0).toUpperCase() + type.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-48">
          <div className="text-2xl text-muted-foreground">Loading bookmarks...</div>
        </div>
      ) : sortedBookmarks.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 bg-muted/50 rounded-lg">
          <h3 className="text-xl font-medium mb-2">No bookmarks found</h3>
          {searchTerm || selectedType ? (
            <p className="text-muted-foreground">Try adjusting your filters</p>
          ) : (
            <p className="text-muted-foreground">You haven't bookmarked any materials yet</p>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedBookmarks.map((bookmark) => (
            <Card key={bookmark.id} className="flex flex-col h-full">
              <CardHeader className="flex-row items-start gap-4 pb-2">
                <div className="p-2 bg-primary/10 rounded-lg">
                  {getMaterialIcon(bookmark.material.type)}
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg text-pretty">{bookmark.material.title}</CardTitle>
                  <CardDescription className="text-xs">
                    Bookmarked on {format(new Date(bookmark.createdAt), "MMM d, yyyy")}
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                  {bookmark.material.description || "No description available"}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="text-xs px-2 py-1 bg-primary/10 rounded-full text-primary">
                    {bookmark.material.type.toUpperCase()}
                  </div>
                  {bookmark.material.category && (
                    <div className="text-xs px-2 py-1 bg-secondary/10 rounded-full text-secondary">
                      {bookmark.material.category}
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-2 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                >
                  <a href={bookmark.material.url} target="_blank" rel="noopener noreferrer">
                    View Material
                  </a>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeBookmarkMutation.mutate(bookmark.id)}
                  disabled={removeBookmarkMutation.isPending}
                >
                  Remove
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}