import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Loader2, Clock, AlertTriangle, CheckCircle2 } from "lucide-react";
import { AppLayout as Layout } from "@/layout/app-layout";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Quiz, QuizQuestion, QuizAttempt, QuizAnswer } from "@shared/schema";

export default function TakeQuizPage() {
  const { id } = useParams();
  const quizId = parseInt(id);
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, any>>({});
  const [attemptId, setAttemptId] = useState<number | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  
  // Fetch quiz details
  const { data: quiz, isLoading: isLoadingQuiz } = useQuery<Quiz>({
    queryKey: [`/api/quizzes/${quizId}`],
    enabled: !!quizId && !!user,
    onSuccess: (quiz) => {
      // Set timer if there's a time limit
      if (quiz.timeLimit) {
        setTimeRemaining(quiz.timeLimit * 60); // Convert minutes to seconds
      }
    }
  });
  
  // Fetch quiz questions
  const { data: questions, isLoading: isLoadingQuestions } = useQuery<QuizQuestion[]>({
    queryKey: [`/api/quizzes/${quizId}/questions`],
    enabled: !!quizId && !!user
  });
  
  // Create a new quiz attempt
  const createAttemptMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/quizzes/${quizId}/attempts`);
      return await res.json() as QuizAttempt;
    },
    onSuccess: (attempt) => {
      setAttemptId(attempt.id);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to start quiz",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
      navigate("/student/quizzes");
    }
  });
  
  // Submit an answer
  const submitAnswerMutation = useMutation({
    mutationFn: async ({ questionId, userAnswer }: { questionId: number; userAnswer: any }) => {
      if (!attemptId) throw new Error("No active attempt");
      
      const res = await apiRequest("POST", `/api/quiz-attempts/${attemptId}/answers`, {
        questionId,
        userAnswer
      });
      return await res.json() as QuizAnswer;
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to submit answer",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  });
  
  // Complete the quiz attempt
  const completeAttemptMutation = useMutation({
    mutationFn: async ({ score, passed }: { score: number, passed: boolean }) => {
      if (!attemptId) throw new Error("No active attempt");
      
      const res = await apiRequest("POST", `/api/quiz-attempts/${attemptId}/complete`, {
        score,
        passed
      });
      return await res.json() as QuizAttempt;
    },
    onSuccess: (attempt) => {
      setQuizSubmitted(true);
      
      toast({
        title: "Quiz submitted",
        description: `Your score: ${attempt.score}%${attempt.passed ? ' (Passed)' : ' (Failed)'}`,
        variant: attempt.passed ? "default" : "destructive"
      });
      
      // Navigate to results page after a short delay
      setTimeout(() => {
        navigate(`/student/quiz-results/${attempt.id}`);
      }, 2000);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to submit quiz",
        description: error instanceof Error ? error.message : "An unexpected error occurred."
      });
    }
  });
  
  // Timer effect
  useEffect(() => {
    if (timeRemaining === null || quizSubmitted) return;
    
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev === null || prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [timeRemaining, quizSubmitted]);
  
  // Auto-submit when time is up
  useEffect(() => {
    if (timeRemaining === 0 && !quizSubmitted) {
      handleSubmitQuiz();
    }
  }, [timeRemaining, quizSubmitted]);
  
  // Start the quiz attempt when the page loads
  useEffect(() => {
    if (quiz && questions && !attemptId && !createAttemptMutation.isPending) {
      createAttemptMutation.mutate();
    }
  }, [quiz, questions, attemptId]);
  
  const isLoading = isLoadingQuiz || isLoadingQuestions || createAttemptMutation.isPending;
  
  const handleAnswerChange = (questionId: number, value: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };
  
  const handleNextQuestion = async () => {
    const currentQuestion = questions?.[currentQuestionIndex];
    if (!currentQuestion || !attemptId) return;
    
    const userAnswer = answers[currentQuestion.id];
    
    // Submit the answer to the server
    await submitAnswerMutation.mutateAsync({
      questionId: currentQuestion.id,
      userAnswer
    });
    
    // If there are more questions, move to the next one
    if (currentQuestionIndex < (questions?.length || 0) - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };
  
  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };
  
  const handleSubmitQuiz = async () => {
    // Submit any remaining answers
    const currentQuestion = questions?.[currentQuestionIndex];
    if (currentQuestion && !quizSubmitted) {
      const userAnswer = answers[currentQuestion.id];
      if (userAnswer) {
        await submitAnswerMutation.mutateAsync({
          questionId: currentQuestion.id,
          userAnswer
        });
      }
    }
    
    // Calculate score (for auto-graded questions)
    const totalPoints = questions?.reduce((sum, q) => sum + (q.points || 0), 0) || 0;
    
    // In a real system, we would calculate the actual score based on the user's answers
    // For now, we'll use a random score for demonstration
    const earnedPoints = Math.floor(Math.random() * totalPoints);
    const score = Math.round((earnedPoints / totalPoints) * 100);
    const passed = score >= (quiz?.passingScore || 0);
    
    await completeAttemptMutation.mutateAsync({ score, passed });
  };
  
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
              <h2 className="text-xl font-semibold">Loading Quiz...</h2>
              <p className="text-muted-foreground">Please wait while we prepare your quiz.</p>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  if (!quiz || !questions || questions.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Unable to load quiz. The quiz may not exist or has no questions.
            </AlertDescription>
          </Alert>
          <div className="mt-4">
            <Button onClick={() => navigate("/student/quizzes")}>
              Back to Quizzes
            </Button>
          </div>
        </div>
      </Layout>
    );
  }
  
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  
  return (
    <Layout>
      <div className="container mx-auto py-6 max-w-4xl">
        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl">{quiz.title}</CardTitle>
                <CardDescription>
                  Question {currentQuestionIndex + 1} of {questions.length}
                </CardDescription>
              </div>
              {timeRemaining !== null && (
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <Badge variant={timeRemaining < 60 ? "destructive" : "outline"} className="text-sm">
                    {formatTime(timeRemaining)}
                  </Badge>
                </div>
              )}
            </div>
            
            <Progress value={progress} className="mt-2" />
          </CardHeader>
          
          <CardContent className="pt-6">
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">{currentQuestion.questionText}</h3>
                
                {currentQuestion.questionType === "multiple_choice" && (
                  <RadioGroup 
                    value={answers[currentQuestion.id] || ""}
                    onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
                    className="space-y-3"
                  >
                    {Array.isArray(currentQuestion.options) && currentQuestion.options.map((option: string, index: number) => (
                      <div key={index} className="flex items-center space-x-2">
                        <RadioGroupItem value={option} id={`option-${index}`} />
                        <Label htmlFor={`option-${index}`} className="font-normal">{option}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
                
                {currentQuestion.questionType === "true_false" && (
                  <RadioGroup 
                    value={answers[currentQuestion.id] || ""}
                    onValueChange={(value) => handleAnswerChange(currentQuestion.id, value === "true")}
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="true" id="true" />
                      <Label htmlFor="true" className="font-normal">True</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="false" id="false" />
                      <Label htmlFor="false" className="font-normal">False</Label>
                    </div>
                  </RadioGroup>
                )}
                
                {currentQuestion.questionType === "short_answer" && (
                  <Input
                    placeholder="Your answer"
                    value={answers[currentQuestion.id] || ""}
                    onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                    className="w-full"
                  />
                )}
                
                {currentQuestion.questionType === "essay" && (
                  <Textarea
                    placeholder="Write your answer here..."
                    value={answers[currentQuestion.id] || ""}
                    onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                    className="min-h-32"
                  />
                )}
                
                {currentQuestion.questionType === "matching" && (
                  <div className="space-y-4">
                    {Array.isArray(currentQuestion.options) && currentQuestion.options.map((item: any, index: number) => (
                      <div key={index} className="grid grid-cols-2 gap-4 items-center">
                        <div className="font-medium">{item.term}</div>
                        <Input
                          placeholder="Matching definition"
                          value={(answers[currentQuestion.id] || {})[item.term] || ""}
                          onChange={(e) => {
                            const currentMatches = answers[currentQuestion.id] || {};
                            handleAnswerChange(currentQuestion.id, {
                              ...currentMatches,
                              [item.term]: e.target.value
                            });
                          }}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
          
          <Separator />
          
          <CardFooter className="justify-between pt-6">
            <Button
              variant="outline"
              onClick={handlePrevQuestion}
              disabled={currentQuestionIndex === 0 || submitAnswerMutation.isPending}
            >
              Previous
            </Button>
            
            <div className="flex gap-2">
              {currentQuestionIndex < questions.length - 1 ? (
                <Button 
                  onClick={handleNextQuestion}
                  disabled={!answers[currentQuestion.id] || submitAnswerMutation.isPending}
                >
                  {submitAnswerMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Next
                </Button>
              ) : (
                <Button
                  onClick={handleSubmitQuiz}
                  disabled={!answers[currentQuestion.id] || quizSubmitted || completeAttemptMutation.isPending}
                >
                  {completeAttemptMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : quizSubmitted ? (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Submitted
                    </>
                  ) : (
                    "Submit Quiz"
                  )}
                </Button>
              )}
            </div>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
}