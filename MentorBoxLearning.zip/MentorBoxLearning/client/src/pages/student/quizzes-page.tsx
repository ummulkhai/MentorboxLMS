import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { CalendarClock, Check, Clock, FileText, Tags } from "lucide-react";
import { AppLayout } from "@/layout/app-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";

export default function QuizzesPage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("available");

  const { data: quizzes, isLoading: isLoadingQuizzes } = useQuery({
    queryKey: ['/api/quizzes'],
    select: (data) => data || [],
  });

  const { data: enrolledCourses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ['/api/courses/enrolled'],
    select: (data) => data || [],
  });

  const { data: attempts, isLoading: isLoadingAttempts } = useQuery({
    queryKey: ['/api/quiz-attempts/my'],
    select: (data) => data || [],
  });

  // Filter quizzes based on enrolled courses
  const availableQuizzes = Array.isArray(quizzes) ? quizzes.filter((quiz: any) => 
    Array.isArray(enrolledCourses) && enrolledCourses.some((course: any) => course.id === quiz.courseId)
  ) : [];

  // Filter quizzes that have been attempted
  const completedQuizzes = Array.isArray(availableQuizzes) ? availableQuizzes.filter((quiz: any) => 
    Array.isArray(attempts) && attempts.some((attempt: any) => attempt.quizId === quiz.id && attempt.completedAt !== null)
  ) : [];

  const pendingQuizzes = Array.isArray(availableQuizzes) ? availableQuizzes.filter((quiz: any) => 
    !Array.isArray(attempts) || !attempts.some((attempt: any) => attempt.quizId === quiz.id && attempt.completedAt !== null)
  ) : [];

  const handleStartQuiz = (quizId: number) => {
    navigate(`/student/quizzes/${quizId}`);
  };

  const handleViewResults = (attemptId: number) => {
    navigate(`/student/quiz-results/${attemptId}`);
  };

  const getCourseName = (courseId: number) => {
    if (!Array.isArray(enrolledCourses)) return "Unknown Course";
    const course = enrolledCourses.find((c: any) => c.id === courseId);
    return course?.title || "Unknown Course";
  };

  const getLatestAttempt = (quizId: number) => {
    if (!Array.isArray(attempts)) return null;
    
    const quizAttempts = attempts.filter((a: any) => a.quizId === quizId && a.completedAt);
    if (quizAttempts.length === 0) return null;
    
    // Sort by completedAt in descending order (most recent first)
    return quizAttempts.sort((a: any, b: any) => 
      new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
    )[0];
  };

  return (
    <AppLayout>
      <div className="container py-6 max-w-5xl">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">My Quizzes</h1>
        </div>

        <Tabs 
          defaultValue="available" 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="mb-8"
        >
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="available">Available ({pendingQuizzes?.length || 0})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completedQuizzes?.length || 0})</TabsTrigger>
            <TabsTrigger value="all">All Quizzes ({availableQuizzes?.length || 0})</TabsTrigger>
          </TabsList>

          {/* Available Quizzes */}
          <TabsContent value="available">
            {isLoadingQuizzes || isLoadingCourses || isLoadingAttempts ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-9 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : pendingQuizzes?.length === 0 ? (
              <div className="text-center my-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Available Quizzes</h3>
                <p className="text-muted-foreground mt-2">
                  You have completed all available quizzes. Check the Completed tab to see your results.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {pendingQuizzes?.map(quiz => (
                  <Card key={quiz.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{quiz.title}</CardTitle>
                        <Badge variant="outline" className="font-normal">
                          {getCourseName(quiz.courseId)}
                        </Badge>
                      </div>
                      <CardDescription>
                        {quiz.description || "No description provided"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="text-sm space-y-2">
                      <div className="flex items-center text-muted-foreground">
                        <Clock className="h-4 w-4 mr-2" />
                        {quiz.timeLimit ? `${quiz.timeLimit} minutes` : "No time limit"}
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Check className="h-4 w-4 mr-2" />
                        Passing Score: {quiz.passingScore}%
                      </div>
                      {quiz.dueDate && (
                        <div className="flex items-center text-muted-foreground">
                          <CalendarClock className="h-4 w-4 mr-2" />
                          Due: {formatDate(quiz.dueDate)}
                        </div>
                      )}
                      {quiz.attemptsAllowed && (
                        <div className="flex items-center text-muted-foreground">
                          <Tags className="h-4 w-4 mr-2" />
                          Attempts Allowed: {quiz.attemptsAllowed}
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full" 
                        onClick={() => handleStartQuiz(quiz.id)}
                      >
                        Start Quiz
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Completed Quizzes */}
          <TabsContent value="completed">
            {isLoadingQuizzes || isLoadingCourses || isLoadingAttempts ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-9 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : completedQuizzes?.length === 0 ? (
              <div className="text-center my-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Completed Quizzes</h3>
                <p className="text-muted-foreground mt-2">
                  You haven't completed any quizzes yet. Check the Available tab to see quizzes you can take.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {completedQuizzes?.map(quiz => {
                  const latestAttempt = getLatestAttempt(quiz.id);
                  const passed = latestAttempt?.passed;
                  const score = latestAttempt?.score;
                  
                  return (
                    <Card key={quiz.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{quiz.title}</CardTitle>
                          <Badge variant={passed ? "default" : "destructive"}>
                            {passed ? "Passed" : "Failed"}
                          </Badge>
                        </div>
                        <CardDescription>
                          {getCourseName(quiz.courseId)}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="text-sm space-y-2">
                        <div className="flex items-center">
                          <span className="font-medium">Score:</span>
                          <span className="ml-2">{score}%</span>
                        </div>
                        
                        {latestAttempt?.completedAt && (
                          <div className="flex items-center text-muted-foreground">
                            <CalendarClock className="h-4 w-4 mr-2" />
                            Completed: {formatDate(latestAttempt.completedAt)}
                          </div>
                        )}
                        
                        {quiz.attemptsAllowed && latestAttempt && (
                          <div className="flex items-center text-muted-foreground">
                            <Tags className="h-4 w-4 mr-2" />
                            Attempt {latestAttempt.attemptNumber} of {quiz.attemptsAllowed}
                          </div>
                        )}
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <Button 
                          variant="outline" 
                          className="w-1/2 mr-2"
                          onClick={() => latestAttempt && handleViewResults(latestAttempt.id)}
                        >
                          View Results
                        </Button>
                        
                        {quiz.attemptsAllowed && 
                         latestAttempt && 
                         latestAttempt.attemptNumber < quiz.attemptsAllowed && 
                         !passed && (
                          <Button 
                            className="w-1/2 ml-2"
                            onClick={() => handleStartQuiz(quiz.id)}
                          >
                            Try Again
                          </Button>
                        )}
                        
                        {(!quiz.attemptsAllowed || 
                          (latestAttempt && 
                           latestAttempt.attemptNumber >= quiz.attemptsAllowed) || 
                          passed) && (
                          <Button 
                            variant="secondary"
                            className="w-1/2 ml-2"
                            disabled
                          >
                            {passed ? "Passed" : "No Attempts Left"}
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* All Quizzes */}
          <TabsContent value="all">
            {isLoadingQuizzes || isLoadingCourses || isLoadingAttempts ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-9 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : availableQuizzes?.length === 0 ? (
              <div className="text-center my-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Quizzes Available</h3>
                <p className="text-muted-foreground mt-2">
                  There are no quizzes available for your enrolled courses.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {availableQuizzes?.map(quiz => {
                  const latestAttempt = getLatestAttempt(quiz.id);
                  const hasCompleted = !!latestAttempt;
                  const passed = latestAttempt?.passed;
                  const score = latestAttempt?.score;
                  
                  return (
                    <Card key={quiz.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{quiz.title}</CardTitle>
                          {hasCompleted ? (
                            <Badge variant={passed ? "default" : "destructive"}>
                              {passed ? "Passed" : "Failed"}
                            </Badge>
                          ) : (
                            <Badge variant="outline">Not Attempted</Badge>
                          )}
                        </div>
                        <CardDescription>
                          {getCourseName(quiz.courseId)}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="text-sm space-y-2">
                        {hasCompleted ? (
                          <>
                            <div className="flex items-center">
                              <span className="font-medium">Score:</span>
                              <span className="ml-2">{score}%</span>
                            </div>
                            
                            {latestAttempt?.completedAt && (
                              <div className="flex items-center text-muted-foreground">
                                <CalendarClock className="h-4 w-4 mr-2" />
                                Completed: {formatDate(latestAttempt.completedAt)}
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            <div className="flex items-center text-muted-foreground">
                              <Clock className="h-4 w-4 mr-2" />
                              {quiz.timeLimit ? `${quiz.timeLimit} minutes` : "No time limit"}
                            </div>
                            <div className="flex items-center text-muted-foreground">
                              <Check className="h-4 w-4 mr-2" />
                              Passing Score: {quiz.passingScore}%
                            </div>
                          </>
                        )}
                        
                        {quiz.attemptsAllowed && latestAttempt && (
                          <div className="flex items-center text-muted-foreground">
                            <Tags className="h-4 w-4 mr-2" />
                            Attempt {latestAttempt.attemptNumber} of {quiz.attemptsAllowed}
                          </div>
                        )}
                      </CardContent>
                      <CardFooter>
                        {hasCompleted ? (
                          <div className="flex w-full">
                            <Button 
                              variant="outline" 
                              className="w-1/2 mr-2"
                              onClick={() => latestAttempt && handleViewResults(latestAttempt.id)}
                            >
                              View Results
                            </Button>
                            
                            {quiz.attemptsAllowed && 
                             latestAttempt && 
                             latestAttempt.attemptNumber < quiz.attemptsAllowed && 
                             !passed ? (
                              <Button 
                                className="w-1/2 ml-2"
                                onClick={() => handleStartQuiz(quiz.id)}
                              >
                                Try Again
                              </Button>
                            ) : (
                              <Button 
                                variant="secondary"
                                className="w-1/2 ml-2"
                                disabled
                              >
                                {passed ? "Passed" : "No Attempts Left"}
                              </Button>
                            )}
                          </div>
                        ) : (
                          <Button 
                            className="w-full" 
                            onClick={() => handleStartQuiz(quiz.id)}
                          >
                            Start Quiz
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}