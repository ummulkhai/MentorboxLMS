import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { AppLayout } from "@/layout/app-layout";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, CalendarRange, Clock, FileText, LayoutGrid, Settings } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";

export default function Profile() {
  const { user } = useAuth();
  const [overallProgress, setOverallProgress] = useState(0);
  
  // Fetch user's enrolled courses
  const { data: enrolledCourses = [] } = useQuery({
    queryKey: ["/api/courses/enrolled"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/courses/enrolled");
        if (!res.ok) throw new Error("Failed to fetch enrolled courses");
        return await res.json();
      } catch (error) {
        console.error("Error fetching enrolled courses:", error);
        return [];
      }
    }
  });
  
  // Calculate overall progress across all courses
  useEffect(() => {
    if (enrolledCourses.length > 0) {
      const calculateProgress = async () => {
        let totalProgress = 0;
        
        for (const course of enrolledCourses) {
          try {
            const res = await apiRequest("GET", `/api/courses/${course.id}/progress`);
            if (res.ok) {
              const progress = await res.json();
              totalProgress += progress;
            }
          } catch (error) {
            console.error("Error fetching course progress:", error);
          }
        }
        
        // Calculate average progress
        const avgProgress = enrolledCourses.length > 0 
          ? Math.round(totalProgress / enrolledCourses.length) 
          : 0;
          
        setOverallProgress(avgProgress);
      };
      
      calculateProgress();
    }
  }, [enrolledCourses]);
  
  // Get initials for avatar
  const getInitials = () => {
    if (!user) return "U";
    return user.username.substring(0, 2).toUpperCase();
  };
  
  return (
    <AppLayout>
      <div className="container max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">My Profile</h1>
          <Link href="/settings">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Edit Profile
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="" alt={user?.username || "User"} />
                    <AvatarFallback className="text-xl">{getInitials()}</AvatarFallback>
                  </Avatar>
                </div>
                <CardTitle>{user?.name || user?.username}</CardTitle>
                <CardDescription className="flex justify-center gap-2">
                  <Badge variant="outline" className="capitalize">{user?.role}</Badge>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Username</h3>
                    <p>{user?.username}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Email</h3>
                    <p>{user?.email || "Not set"}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Joined</h3>
                    <p>{user?.createdAt 
                        ? new Date(user.createdAt).toLocaleDateString() 
                        : "Not available"}</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="w-full space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Learning Progress</span>
                    <span className="text-sm font-medium">{overallProgress}%</span>
                  </div>
                  <Progress value={overallProgress} className="h-2" />
                </div>
              </CardFooter>
            </Card>
          </div>
          
          <div className="md:col-span-2">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Course Enrollment
                  </CardTitle>
                  <CardDescription>
                    {enrolledCourses.length} course{enrolledCourses.length !== 1 ? 's' : ''} enrolled
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {enrolledCourses.length > 0 ? (
                    <div className="space-y-4">
                      {enrolledCourses.map((course: any) => (
                        <div key={course.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                          <div className="flex items-center gap-3">
                            <div className="bg-primary/10 p-2 rounded-md">
                              <LayoutGrid className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium">{course.title}</h4>
                              <p className="text-sm text-muted-foreground">{course.category || "General"}</p>
                            </div>
                          </div>
                          <Link href={`/course/${course.id}`}>
                            <Button variant="ghost" size="sm">View Course</Button>
                          </Link>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Enrolled Courses</h3>
                      <p className="text-muted-foreground mb-4">You haven't enrolled in any courses yet.</p>
                      <Link href="/student/courses">
                        <Button>Browse Courses</Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Recent Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-50 p-1 rounded-full">
                          <FileText className="h-4 w-4 text-blue-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Accessed Course Materials</p>
                          <p className="text-xs text-muted-foreground">Just now</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <div className="bg-green-50 p-1 rounded-full">
                          <BookOpen className="h-4 w-4 text-green-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Completed a Lesson</p>
                          <p className="text-xs text-muted-foreground">1 day ago</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-50 p-1 rounded-full">
                          <LayoutGrid className="h-4 w-4 text-purple-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Started a New Course</p>
                          <p className="text-xs text-muted-foreground">3 days ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CalendarRange className="h-5 w-5" />
                      Upcoming Deadlines
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-amber-50 p-1 rounded-full">
                          <Clock className="h-4 w-4 text-amber-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Assignment Due</p>
                          <p className="text-xs text-muted-foreground">Tomorrow at 11:59 PM</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <div className="bg-red-50 p-1 rounded-full">
                          <FileText className="h-4 w-4 text-red-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Final Project</p>
                          <p className="text-xs text-muted-foreground">In 5 days</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-50 p-1 rounded-full">
                          <LayoutGrid className="h-4 w-4 text-blue-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Course Completion</p>
                          <p className="text-xs text-muted-foreground">In 2 weeks</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}