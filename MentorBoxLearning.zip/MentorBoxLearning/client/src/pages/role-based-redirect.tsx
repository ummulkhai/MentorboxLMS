import { useEffect } from "react";
import { Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function RoleBasedRedirect() {
  const { user, isLoading } = useAuth();

  useEffect(() => {
    // Log the current user's role for debugging
    if (user) {
      console.log(`User role: ${user.role}`);
    }
  }, [user]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // If not logged in, redirect to auth page
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Redirect based on user role
  switch (user.role) {
    case "admin":
      return <Redirect to="/admin/dashboard" />;
      
    case "instructor":
      return <Redirect to="/instructor/dashboard" />;
      
    case "student":
      return <Redirect to="/student/dashboard" />;
      
    default:
      // If role is not recognized, default to student and show a warning
      setTimeout(() => {
        toast({
          title: "Role not recognized",
          description: `Unknown role: "${user.role}". Defaulting to student view.`,
          variant: "destructive",
        });
      }, 100);
      
      console.warn(`Unknown role: ${user.role}, defaulting to student view`);
      return <Redirect to="/student/dashboard" />;
  }
}