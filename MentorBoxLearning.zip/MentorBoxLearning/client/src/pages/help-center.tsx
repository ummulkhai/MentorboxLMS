import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AppLayout } from "@/layout/app-layout";
import { Clock, HelpCircle, Wrench, AlertTriangle } from "lucide-react";

export default function HelpCenter() {
  return (
    <AppLayout>
      <div className="container max-w-6xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Help Center</h1>
          <p className="text-muted-foreground mt-2">
            Find answers to your questions about using Mentorbox LMS
          </p>
        </div>

        <Alert className="mb-8 bg-amber-50 border-amber-200">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <AlertTitle className="text-amber-800">Under Maintenance</AlertTitle>
          <AlertDescription className="text-amber-700">
            Our comprehensive help documentation is currently under maintenance. We're working to provide you with detailed guides and tutorials soon.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Getting Started</CardTitle>
              <CardDescription>Learn the basics of the Mentorbox LMS platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-32 bg-muted/50 rounded-md border border-dashed">
                <div className="flex flex-col items-center text-muted-foreground">
                  <Wrench className="h-6 w-6 mb-2" />
                  <p>Coming Soon</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Course Access</CardTitle>
              <CardDescription>How to access and make the most of your courses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-32 bg-muted/50 rounded-md border border-dashed">
                <div className="flex flex-col items-center text-muted-foreground">
                  <Wrench className="h-6 w-6 mb-2" />
                  <p>Coming Soon</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Common questions about using the platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-32 bg-muted/50 rounded-md border border-dashed">
                <div className="flex flex-col items-center text-muted-foreground">
                  <Wrench className="h-6 w-6 mb-2" />
                  <p>Coming Soon</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Technical Support</CardTitle>
              <CardDescription>Get help with technical issues</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-32 bg-muted/50 rounded-md border border-dashed">
                <div className="flex flex-col items-center text-muted-foreground">
                  <Wrench className="h-6 w-6 mb-2" />
                  <p>Coming Soon</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-muted p-6 rounded-lg">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-semibold mb-2">Need immediate assistance?</h2>
              <p className="text-muted-foreground">
                Please reach out to us through our contact page for direct support.
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Response within 24 hours</span>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}